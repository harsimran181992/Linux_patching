from __future__ import annotations

import re

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+asyncpg://aeda:aeda@localhost:5432/aeda"
    REDIS_URL: str = "redis://localhost:6379/0"
    LOG_LEVEL: str = "INFO"
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    SLACK_WEBHOOK_URL: str = ""

    # Anthropic / Azure AI Foundry (Anthropic-compatible endpoint)
    ANTHROPIC_API_KEY: str = ""
    ANTHROPIC_BASE_URL: str = ""   # leave empty for direct Anthropic; set to Azure endpoint for Azure
    ANTHROPIC_MODEL: str = "claude-opus-4-7"  # default model; override per rule action if needed

    RUN_MIGRATIONS: bool = False

    @property
    def SYNC_DATABASE_URL(self) -> str:
        """psycopg2 URL for Alembic (sync migrations only)."""
        return re.sub(r"^postgresql\+asyncpg", "postgresql+psycopg2", self.DATABASE_URL)

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


settings = Settings()
