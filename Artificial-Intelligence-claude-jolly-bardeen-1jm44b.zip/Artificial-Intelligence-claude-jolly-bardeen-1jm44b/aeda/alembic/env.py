from __future__ import annotations

import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from alembic import context
from sqlalchemy import engine_from_config, pool

from config import settings
from aeda.db.base import Base
import aeda.db.orm  # noqa: F401 — registers all ORM models with Base.metadata

config = context.config
target_metadata = Base.metadata


def get_sync_url() -> str:
    return re.sub(r"^postgresql\+asyncpg", "postgresql+psycopg2", settings.DATABASE_URL)


def run_migrations_offline() -> None:
    context.configure(
        url=get_sync_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    cfg = config.get_section(config.config_ini_section, {})
    cfg["sqlalchemy.url"] = get_sync_url()
    connectable = engine_from_config(cfg, prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
