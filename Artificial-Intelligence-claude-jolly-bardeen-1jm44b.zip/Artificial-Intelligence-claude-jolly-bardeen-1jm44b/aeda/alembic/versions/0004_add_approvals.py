"""Add approvals table for human-in-the-loop AI actions

Revision ID: 0004
Revises: 0003
Create Date: 2026-05-25
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "approvals",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("event_id", sa.String(64), nullable=True),
        sa.Column("event_title", sa.Text, nullable=False),
        sa.Column("rule_name", sa.String(256), nullable=False),
        sa.Column("tool_name", sa.String(64), nullable=False),
        sa.Column("tool_params", JSONB, nullable=False, server_default="{}"),
        sa.Column("tool_defaults", JSONB, nullable=False, server_default="{}"),
        sa.Column("reason", sa.Text, nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="pending"),
        sa.Column("result", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_approvals_status", "approvals", ["status"])
    op.create_index("ix_approvals_created_at", "approvals", ["created_at"])


def downgrade() -> None:
    op.drop_table("approvals")
