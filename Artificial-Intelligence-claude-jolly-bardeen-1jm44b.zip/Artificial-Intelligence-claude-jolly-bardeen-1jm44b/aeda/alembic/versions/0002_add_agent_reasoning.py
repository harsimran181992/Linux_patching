"""Add reasoning JSONB column to audit_entries for AI agent turn storage

Revision ID: 0002
Revises: 0001
Create Date: 2026-05-22
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "audit_entries",
        sa.Column("reasoning", JSONB, nullable=True),
    )


def downgrade() -> None:
    op.drop_column("audit_entries", "reasoning")
