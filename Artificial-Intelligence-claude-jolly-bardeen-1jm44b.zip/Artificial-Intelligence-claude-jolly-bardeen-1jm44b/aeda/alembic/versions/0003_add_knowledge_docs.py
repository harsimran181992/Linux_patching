"""Add knowledge_docs table for RAG-based SOP storage

Revision ID: 0003
Revises: 0002
Create Date: 2026-05-25
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB, UUID

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_VECTOR_DIM = 384  # BAAI/bge-small-en-v1.5


def upgrade() -> None:
    # Enable pgvector extension — requires the pgvector/pgvector postgres image.
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    op.create_table(
        "knowledge_docs",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("title", sa.String(256), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("tags", JSONB, nullable=False, server_default="[]"),
        sa.Column("action_hints", JSONB, nullable=False, server_default="{}"),
        sa.Column(
            "embedding",
            sa.Text,  # stored as text by pgvector.sqlalchemy; actual DB type is vector(384)
            nullable=True,
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # Replace the Text placeholder with the real vector type.
    op.execute(
        f"ALTER TABLE knowledge_docs ALTER COLUMN embedding TYPE vector({_VECTOR_DIM}) "
        f"USING embedding::vector({_VECTOR_DIM})"
    )

    op.create_index("ix_knowledge_docs_title", "knowledge_docs", ["title"])


def downgrade() -> None:
    op.drop_table("knowledge_docs")
