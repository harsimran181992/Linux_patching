# AEDA User Guide
## AI-Enhanced Event-Driven Automation

**Version:** 1.0  
**Audience:** DevOps Engineers, SREs, Platform Engineers

---

## Table of Contents

1. [Getting Started](#1-getting-started)
2. [Dashboard](#2-dashboard)
3. [Managing Sources](#3-managing-sources)
4. [Managing Rules](#4-managing-rules)
5. [Claude AI Rules](#5-claude-ai-rules)
6. [Knowledge Base](#6-knowledge-base)
7. [Approvals](#7-approvals)
8. [Integrating Monitoring Tools](#8-integrating-monitoring-tools)
9. [Events](#9-events)
10. [Audit Log](#10-audit-log)
11. [Webhook Tester](#11-webhook-tester)
12. [Rule Conditions Reference](#12-rule-conditions-reference)
13. [Troubleshooting](#13-troubleshooting)

---

## 1. Getting Started

### Prerequisites

Before deploying AEDA, ensure the following are available on your host:

- **Docker** 24.0+ and **Docker Compose** v2.20+
- An **Anthropic API key** (required only for Claude AI action type)
  - Direct: `sk-ant-...` from [console.anthropic.com](https://console.anthropic.com)
  - Azure AI Foundry: an Azure-issued API key and an Anthropic-compatible endpoint URL
- A **Slack Incoming Webhook URL** (required only for Slack action type)
- Open ports: **8000** (AEDA UI/API) and **3001** (Uptime Kuma, if used)

### Installation

**Step 1.** Clone or copy the AEDA project directory to your host machine.

**Step 2.** Create your environment file from the example template:

```bash
cp .env.example .env
```

**Step 3.** Edit `.env` and fill in your credentials:

```dotenv
# PostgreSQL password (change before production use)
POSTGRES_PASSWORD=your_strong_password_here

# Slack notifications (optional)
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL

# Claude AI — choose one of the two options below:

# Option A: Direct Anthropic
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_BASE_URL=
ANTHROPIC_MODEL=claude-opus-4-7

# Option B: Azure AI Foundry (Anthropic-compatible endpoint)
ANTHROPIC_API_KEY=<your-azure-api-key>
ANTHROPIC_BASE_URL=https://<resource>.services.ai.azure.com/anthropic
ANTHROPIC_MODEL=claude-sonnet-4-6
```

**Step 4.** Start all services:

```bash
docker-compose up -d
```

Docker Compose starts four containers: `postgres` (pgvector/pg16), `redis` (7-alpine), `api` (AEDA application), and `uptime-kuma`. The API container automatically runs database migrations on first startup.

**Step 5.** Verify the stack is healthy:

```bash
docker-compose ps
```

All four services should show status `Up` (or `healthy`). The AEDA API performs a startup health check; if postgres is not yet ready, the API will restart automatically — this is expected on first run.

**Step 6.** Open the AEDA UI:

```
http://localhost:8000
```

You should see the Dashboard with zero events and no rules yet.

### First Startup Checklist

- [ ] All four containers are running
- [ ] Dashboard loads at `http://localhost:8000`
- [ ] Uptime Kuma loads at `http://localhost:3001`
- [ ] No errors in `docker-compose logs api`

---

## 2. Dashboard

The Dashboard is the main landing page. It provides a real-time summary of system activity.

### Metric Cards

| Card | Description |
|------|-------------|
| **Total Events** | Cumulative count of all events ingested since startup. Includes events from all sources. |
| **Rules Active** | Number of rules currently enabled. Disabled rules do not count. |
| **Actions Run** | Total number of action executions recorded in the audit log, across all rule types. |
| **Pending Approvals** | Number of human-in-the-loop approval requests waiting for operator review. A non-zero value here requires your attention — navigate to the Approvals page. |

### Recent Events Table

The dashboard shows the 10 most recent events. Each row displays:

- **Time** — when the event was ingested (local time)
- **Source** — which source sent the event (e.g., `uptime-kuma`, `prometheus`, `github`)
- **Title** — the normalized event title
- **Severity** — colour-coded badge: critical (red), warning (yellow), info (blue)

Click any row to open the event detail modal with full payload and labels.

### Interpreting the Dashboard at a Glance

- **High event count, zero actions:** Rules may not be matching, or all rules use `log` only. Check the Rules page.
- **Pending Approvals > 0:** Claude has proposed remediation actions that require your review. Navigate to Approvals immediately.
- **Zero active rules:** No automation is running. Create your first rule to start processing events.

---

## 3. Managing Sources

### What Is a Source?

A **Source** represents an origin system that sends events to AEDA. Each source has:

- A unique **name** (slug, e.g., `uptime-kuma`, `prometheus-prod`)
- A **source type** that determines how incoming payloads are parsed
- A **webhook URL** that you configure in the sending system

AEDA includes four built-in source types:

| Source Type | Description | Webhook URL |
|-------------|-------------|-------------|
| `webhook_generic` | Any system sending JSON payloads | `/sources/webhook/{name}` |
| `webhook_prometheus` | Prometheus Alertmanager format | `/sources/webhook/prometheus` |
| `webhook_github` | GitHub webhook events | `/sources/webhook/github` |
| `manual` | Manual/API-injected events | No URL (API only) |

### Creating a Source

1. Navigate to **Sources** in the left sidebar.
2. Click **Add Source**.
3. Fill in the form:
   - **Name**: A unique slug (lowercase, hyphens allowed). This becomes part of the webhook URL. Example: `prometheus-prod`
   - **Display Name**: Human-readable label. Example: `Prometheus (Production)`
   - **Source Type**: Select from the dropdown. For Uptime Kuma, use `webhook_generic` — AEDA auto-detects Uptime Kuma payloads at the dedicated endpoint.
   - **Description**: Optional. Describe what this source monitors.
   - **Enabled**: Toggle off to stop processing events from this source without deleting it.
4. Click **Save**. The source card will display the generated webhook URL.

### Reading the Webhook URL

Once created, the Source page shows the webhook URL. Example:

```
http://your-aeda-host:8000/sources/webhook/prometheus-prod
```

Copy this URL and paste it into the alerting system you are connecting (Prometheus Alertmanager, Uptime Kuma, GitHub, etc.). See Section 8 for step-by-step integration guides.

### Uptime Kuma Source

For Uptime Kuma, AEDA exposes a dedicated normalizer at:

```
http://your-aeda-host:8000/sources/webhook/uptime-kuma
```

This endpoint parses Uptime Kuma's `heartbeat`/`monitor` payload format and extracts monitor tags as event labels automatically. You do not need to create a separate source for Uptime Kuma — the endpoint is built-in. However, you may create a source record named `uptime-kuma` to document it in the Sources page.

---

## 4. Managing Rules

Rules are the core of AEDA automation. Each rule defines:

1. **Which sources** it listens to (or `*` for all)
2. **Conditions** that must all be true (AND logic) for the rule to fire
3. **Actions** to execute when the rule matches

### Creating a Rule

1. Navigate to **Rules** in the left sidebar.
2. Click **Add Rule**.
3. Fill in the form fields:
   - **Name**: Unique identifier for this rule. Used in audit logs and approvals.
   - **Description**: Optional human-readable explanation.
   - **Enabled**: Toggle off to disable without deleting.
   - **Priority**: Integer. Higher values run first when multiple rules match. Default is 0.
   - **Sources**: Comma-separated list of source names, or `*` for all sources.
   - **Conditions**: One Python expression per line (see Section 12 for full reference).
   - **Actions**: JSON array of action objects (see examples below).
4. Click **Save**.

### Action Types

AEDA supports six action types. Each is configured as a JSON object with a `type` field.

---

#### 4.1 Log Action

Writes a message to the AEDA application log. Useful for debugging or as a lightweight audit trail.

```json
{
  "type": "log",
  "level": "info",
  "message": "Alert received: $event_title from $event_source"
}
```

**Fields:**

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `message` | No | Auto-generated | Message text. Supports `$variable` placeholders. |
| `level` | No | `info` | Log level: `debug`, `info`, `warning`, `error` |

**Available `$` placeholders in all action types:**

| Placeholder | Value |
|-------------|-------|
| `$event_id` | Unique event UUID |
| `$event_title` | Normalized event title |
| `$event_source` | Source name |
| `$event_type` | Event type string |
| `$event_severity` | Severity: `info`, `warning`, `critical` |
| `$event_timestamp` | ISO timestamp |
| `$payload_raw` | Full payload as JSON string |
| `$labels_raw` | Full labels as JSON string |
| `$payload_<key>` | Any top-level payload field by key name |
| `$label_<key>` | Any label by key name |

---

#### 4.2 HTTP Action

Sends an HTTP request to any external URL. Use for calling REST APIs, triggering external webhooks, or posting to management endpoints.

```json
{
  "type": "http",
  "url": "https://incident-system.example.com/api/incidents",
  "method": "POST",
  "headers": {
    "Authorization": "Bearer my-token",
    "Content-Type": "application/json"
  },
  "body": {
    "title": "$event_title",
    "severity": "$event_severity",
    "source": "$event_source",
    "timestamp": "$event_timestamp"
  },
  "timeout": 30
}
```

**Fields:**

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `url` | Yes | — | Target URL. Supports `$` placeholders. |
| `method` | No | `POST` | HTTP method: `GET`, `POST`, `PUT`, `PATCH`, `DELETE` |
| `headers` | No | `{}` | Key/value headers object |
| `body` | No | `null` | JSON body object. Supports `$` placeholders in values. |
| `timeout` | No | `30` | Request timeout in seconds |

---

#### 4.3 Slack Action

Posts a message to a Slack channel via an Incoming Webhook.

```json
{
  "type": "slack",
  "message": ":rotating_light: *CRITICAL*: $event_title\nSource: `$event_source`\nSeverity: `$event_severity`",
  "channel": "#alerts-prod",
  "webhook_url": "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
}
```

**Fields:**

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `message` | No | Auto-generated | Message text (Slack markdown supported). Supports `$` placeholders. |
| `channel` | No | Webhook default | Override the target channel. |
| `webhook_url` | No | `SLACK_WEBHOOK_URL` env var | Slack Incoming Webhook URL. If omitted, uses the global `SLACK_WEBHOOK_URL` environment variable set in `.env`. |

**Tip:** If all rules post to the same Slack channel, set `SLACK_WEBHOOK_URL` in `.env` and omit `webhook_url` from each rule.

---

#### 4.4 Ansible Action

Launches an Ansible AWX or AAP (Automation Controller) job template via the REST API.

```json
{
  "type": "ansible",
  "url": "https://awx.example.com",
  "token": "your-awx-oauth2-token",
  "template_id": 42,
  "extra_vars": {
    "target_host": "$label_hostname",
    "alert_title": "$event_title",
    "severity": "$event_severity"
  },
  "limit": "webservers",
  "wait": true,
  "poll_interval": 5,
  "timeout": 300,
  "verify_ssl": true
}
```

**Fields:**

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `url` | Yes | — | AWX/AAP base URL (no trailing slash) |
| `token` | Yes* | — | OAuth2 bearer token. *Use `token` OR `username`+`password`. |
| `username` | Yes* | — | Basic auth username (alternative to `token`) |
| `password` | Yes* | — | Basic auth password (alternative to `token`) |
| `template_id` | Yes | — | Numeric job template ID from AWX |
| `workflow` | No | `false` | Set `true` to launch a workflow job template |
| `extra_vars` | No | `{}` | Extra variables passed to the playbook. Supports `$` placeholders. |
| `limit` | No | `""` | Inventory host-pattern limit |
| `wait` | No | `false` | Poll until the job reaches a terminal state |
| `poll_interval` | No | `5` | Seconds between status polls (only when `wait: true`) |
| `timeout` | No | `300` | Maximum wait time in seconds before failing |
| `verify_ssl` | No | `true` | Set `false` to skip TLS certificate verification |

**Finding your template_id:** In the AWX UI, navigate to Templates. The numeric ID appears in the URL when you click a template: `.../templates/job_template/42/details`.

---

#### 4.5 Shell Action

Executes a shell command inside the AEDA container. Use with care — the command runs as the container's process user.

```json
{
  "type": "shell",
  "command": "echo '$event_title severity=$event_severity' >> /tmp/aeda_alerts.log",
  "timeout": 60
}
```

**Fields:**

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `command` | Yes | — | Shell command string. Supports `$` placeholders. |
| `timeout` | No | `60` | Timeout in seconds before the command is killed |

**Warning:** Shell actions execute inside the Docker container. Avoid commands that could affect container stability. For production use, prefer Ansible over shell actions.

---

#### 4.6 Claude AI Action

Delegates decision-making to Claude AI. The agent receives the event context, optionally searches the Knowledge Base for SOPs, and uses tools to take remediation actions. This is the most powerful action type.

See **Section 5** for a full reference on Claude AI rules.

```json
{
  "type": "claude",
  "use_knowledge_base": true,
  "require_approval": true,
  "tool_defaults": {
    "run_ansible": {
      "url": "https://awx.example.com",
      "token": "your-awx-token"
    },
    "send_slack": {
      "webhook_url": "https://hooks.slack.com/services/..."
    }
  }
}
```

---

### Full Rule Example: Critical Alert with Slack + Log

```json
{
  "name": "critical-to-slack",
  "description": "Notify Slack on any critical event",
  "enabled": true,
  "sources": ["*"],
  "conditions": [
    "event.severity == 'critical'"
  ],
  "actions": [
    {
      "type": "slack",
      "message": ":rotating_light: *CRITICAL*: $event_title (source: `$event_source`)"
    },
    {
      "type": "log",
      "level": "warning",
      "message": "Slack notified for: $event_title"
    }
  ]
}
```

### Full Rule Example: Production Environment Escalation

```json
{
  "name": "prod-critical-escalation",
  "description": "Escalate production critical alerts via HTTP",
  "enabled": true,
  "sources": ["uptime-kuma", "prometheus"],
  "conditions": [
    "event.severity == 'critical'",
    "labels.get('env') == 'prod'"
  ],
  "actions": [
    {
      "type": "http",
      "url": "https://pagerduty.example.com/api/v2/enqueue",
      "method": "POST",
      "headers": {"Authorization": "Token token=YOUR_KEY"},
      "body": {
        "routing_key": "YOUR_ROUTING_KEY",
        "event_action": "trigger",
        "payload": {
          "summary": "$event_title",
          "severity": "$event_severity",
          "source": "$event_source"
        }
      }
    }
  ]
}
```

---

## 5. Claude AI Rules

Claude AI rules let the AI agent receive an alert, reason about it, and autonomously (or with approval) execute remediation actions. This section covers all configuration options.

### Minimal Configuration

The simplest Claude rule requires only the action type. AEDA fills in defaults for everything else:

```json
{
  "type": "claude"
}
```

With no other options, Claude will:
1. Receive the full event context (title, severity, source, labels, payload)
2. Call `query_ansible_templates` to discover available AWX playbooks
3. Choose the most relevant playbook and call `run_ansible`
4. Summarize what it did

### Full Configuration Reference

```json
{
  "type": "claude",
  "use_knowledge_base": true,
  "require_approval": false,
  "model": "claude-opus-4-7",
  "system_prompt": "You are an SRE automation agent. Follow SOPs exactly.",
  "user_prompt": "Alert: $event_title\nSeverity: $event_severity\nLabels: $labels_raw",
  "allowed_tools": ["search_knowledge", "run_ansible", "send_slack"],
  "tool_defaults": {
    "run_ansible": {
      "url": "https://awx.example.com",
      "token": "your-awx-oauth2-token",
      "verify_ssl": true
    },
    "send_slack": {
      "webhook_url": "https://hooks.slack.com/services/..."
    }
  },
  "max_iterations": 8,
  "max_tokens": 4096
}
```

### Option: `use_knowledge_base`

**Default:** `false`

When `true`, AEDA automatically adds the `search_knowledge` tool to Claude's available tools and updates the system prompt to instruct Claude to search the Knowledge Base before taking any action.

**When to use it:** Always enable this when you have SOP documents in the Knowledge Base that describe remediation procedures for known alert types. The SOP's `action_hints` tell Claude exactly which Ansible template to run and which Slack channel to post to — removing ambiguity from the AI decision.

**Behaviour with `use_knowledge_base: true`:**

1. Claude calls `search_knowledge` with the alert title/description
2. AEDA performs a semantic similarity search over all SOP documents
3. The top matching SOPs are returned, including their `action_hints`
4. Claude reads the `action_hints` and uses them as authoritative instructions
5. If no SOP matches, Claude falls back to `query_ansible_templates`

### Option: `require_approval`

**Default:** `false`

When `true`, Claude is NOT allowed to execute `run_ansible` directly. Instead, it must call `request_approval` with the exact parameters it would have passed. The request is stored in the database and appears on the **Approvals** page in the UI.

An operator must then **approve** or **deny** the action. If approved, AEDA automatically executes the stored tool call using the credentials from `tool_defaults`.

**When to use it:** For production environments where unreviewed automated changes are unacceptable. Recommended during initial rollout — you can remove `require_approval` after validating the AI's decision quality.

### Option: `allowed_tools`

**Default:** all tools

Restricts which tools Claude may call. If omitted, Claude has access to all tools. Specify a list to limit scope.

Available tools:

| Tool | Description |
|------|-------------|
| `search_knowledge` | Semantic search over Knowledge Base SOPs |
| `query_ansible_templates` | List AWX/AAP job templates |
| `run_ansible` | Launch an AWX/AAP job |
| `send_slack` | Post a Slack message |
| `send_http` | Make an HTTP request |
| `query_recent_events` | Query recent AEDA events for context |
| `request_approval` | Request human approval (auto-added when `require_approval: true`) |

**Example — limit to Slack notifications only:**

```json
{
  "type": "claude",
  "allowed_tools": ["search_knowledge", "send_slack"],
  "tool_defaults": {
    "send_slack": {"webhook_url": "https://hooks.slack.com/services/..."}
  }
}
```

### Option: `tool_defaults`

A dictionary of default parameters injected into every tool call of a given type. This is how you supply AWX credentials and Slack URLs without hardcoding them in the system prompt.

```json
"tool_defaults": {
  "run_ansible": {
    "url": "https://awx.example.com",
    "token": "awx-token-abc123",
    "verify_ssl": true
  },
  "send_slack": {
    "webhook_url": "https://hooks.slack.com/services/T.../B.../..."
  }
}
```

Claude does not see these values in its context window — they are merged server-side when the tool executes. This keeps credentials out of the AI's reasoning trace.

### Option: `system_prompt`

Override the default system prompt entirely. If omitted, AEDA uses:

- When `use_knowledge_base: false` — a prompt instructing Claude to discover and run AWX templates
- When `use_knowledge_base: true` — a prompt instructing Claude to search SOPs first and follow their `action_hints`

**When to override:** When you want Claude to follow a specific workflow, adopt a particular tone, or integrate with non-standard tooling.

**Tip:** Your custom prompt should still explain what tools are available and how they work, since AEDA only provides the schema — not the usage instructions — to Claude automatically.

### Option: `user_prompt`

Override the default user message sent to Claude. The default includes all event fields:

```
Alert fired:
Title:     $event_title
Severity:  $event_severity
Source:    $event_source
Type:      $event_type
Timestamp: $event_timestamp
Labels:    $labels_raw
Payload:   $payload_raw
```

Override this when your events carry specific payload fields that Claude should emphasize.

### Option: `model`

**Default:** value of `ANTHROPIC_MODEL` in `.env`, falling back to `claude-opus-4-7`

Override the Claude model per rule. Useful if you want cheaper/faster models for low-priority rules and more capable models for critical ones.

```json
{
  "type": "claude",
  "model": "claude-sonnet-4-6"
}
```

### Option: `max_iterations`

**Default:** `8`

Maximum number of tool-use rounds in the agentic loop. If Claude has not produced a final `end_turn` response after this many iterations, the action is marked as failed. Increase for complex multi-step remediations.

### Complete Example: Production SRE Rule with Approval

```json
{
  "name": "prod-sre-ai-remediation",
  "description": "AI-driven remediation for production alerts, with operator approval",
  "enabled": true,
  "sources": ["uptime-kuma", "prometheus"],
  "conditions": [
    "event.severity == 'critical'",
    "labels.get('env') == 'prod'"
  ],
  "actions": [
    {
      "type": "claude",
      "use_knowledge_base": true,
      "require_approval": true,
      "tool_defaults": {
        "run_ansible": {
          "url": "https://awx.example.com",
          "token": "awx-token-abc123"
        },
        "send_slack": {
          "webhook_url": "https://hooks.slack.com/services/..."
        }
      }
    }
  ]
}
```

---

## 6. Knowledge Base

The Knowledge Base stores Standard Operating Procedure (SOP) documents. When `use_knowledge_base: true` is set on a Claude rule, the agent performs a semantic search over these documents to find the most relevant SOP before taking action.

### How It Works

1. When you add or update a document, AEDA generates a vector embedding of the title and content
2. AEDA stores the embedding in PostgreSQL (pgvector extension)
3. When Claude calls `search_knowledge`, AEDA does a cosine-similarity search and returns the top matching documents
4. Each document includes `action_hints` — structured instructions Claude must follow

### Adding a Document

1. Navigate to **Knowledge Base** in the left sidebar.
2. Click **Add Document**.
3. Fill in the form:
   - **Title**: Descriptive name for the SOP (e.g., `High CPU Usage Remediation`)
   - **Tags**: Optional comma-separated keywords for categorization
   - **Content**: The full SOP text (plain text or Markdown). Write clearly — Claude reads this verbatim.
   - **Action Hints**: JSON object with structured instructions (see below)
4. Click **Save**. The document is embedded immediately.

### Action Hints Format

`action_hints` is a JSON object that provides Claude with explicit, unambiguous instructions. Claude is instructed to follow these hints precisely rather than making its own decisions.

**Supported hint keys:**

| Key | Type | Description |
|-----|------|-------------|
| `ansible_template` | string | Exact AWX job template name to run |
| `slack_channel` | string | Slack channel to notify |
| `http_url` | string | External URL to call |
| `priority` | string | Suggested escalation priority |
| `notes` | string | Additional instructions for Claude |

**Example action_hints:**

```json
{
  "ansible_template": "remediate-high-cpu",
  "slack_channel": "#ops-alerts",
  "notes": "Only run if CPU > 90% for more than 5 minutes. Check recent events first."
}
```

### Example SOP Documents

#### SOP 1: High CPU Usage

**Title:** `High CPU Usage Remediation`  
**Tags:** `cpu, performance, linux`  
**Content:**
```
This procedure handles alerts for high CPU utilisation on Linux hosts.

Symptoms:
- CPU usage consistently above 85%
- System load average exceeding CPU count
- Application response times degrading

Diagnosis:
1. Check which processes are consuming CPU (top, htop)
2. Verify there are no runaway processes or infinite loops
3. Check if this is scheduled batch processing (expected behaviour)
4. Review application logs for errors causing retry loops

Remediation:
1. If runaway process: kill the process and investigate root cause
2. If application loop: run the cpu-remediation playbook to restart affected service
3. If scheduled batch: document and monitor; no action required
4. Always notify the ops channel with findings

Escalation: If CPU remains above 95% after playbook runs, page on-call engineer.
```
**Action Hints:**
```json
{
  "ansible_template": "remediate-high-cpu",
  "slack_channel": "#ops-alerts",
  "notes": "Run the playbook first, then post findings to Slack."
}
```

---

#### SOP 2: Disk Space Critical

**Title:** `Disk Space Critical Alert`  
**Tags:** `disk, storage, filesystem`  
**Content:**
```
This procedure handles disk usage alerts when filesystem utilisation exceeds 85%.

Symptoms:
- Disk usage above 85% on any monitored partition
- Applications failing to write logs or temporary files
- Database write failures

Immediate Actions:
1. Run the disk-cleanup playbook to remove old logs and temp files
2. Check for unintended large file creation (core dumps, log explosions)
3. Notify the storage team if cleanup does not free sufficient space

Long-term Actions:
1. Review log rotation configuration
2. Consider expanding the volume if cleanup only buys days
3. Update monitoring thresholds if baseline usage has grown

Do not attempt to delete files manually — use the playbook to avoid
accidentally removing critical data.
```
**Action Hints:**
```json
{
  "ansible_template": "disk-cleanup",
  "slack_channel": "#ops-alerts",
  "notes": "Always run cleanup before notifying. Include disk usage percentage in the Slack message if available from event labels."
}
```

---

#### SOP 3: Service Down

**Title:** `Service Down Remediation`  
**Tags:** `service, uptime, restart`  
**Content:**
```
Triggered when Uptime Kuma reports a monitored service is DOWN.

Immediate Response:
1. Check if the outage is planned (maintenance window)
2. Attempt service restart via the service-restart playbook
3. Post immediate notification to #incidents with monitor name and URL

Post-Restart:
1. Verify the service comes back UP within 60 seconds
2. Check application logs for the failure reason
3. If service fails to restart, escalate to on-call

Escalation Criteria:
- Service fails to restart after playbook execution
- Same service has gone down 3+ times in 24 hours
- Service is customer-facing (check env=prod label)
```
**Action Hints:**
```json
{
  "ansible_template": "service-restart",
  "slack_channel": "#incidents",
  "notes": "Use the monitor name from the event title. For production services (env=prod label), also send to #incidents-prod."
}
```

---

#### SOP 4: Deployment Failure

**Title:** `Deployment Pipeline Failure`  
**Tags:** `deployment, cicd, github, pipeline`  
**Content:**
```
Triggered when a GitHub Actions workflow fails or a deployment reports an error status.

Diagnosis:
1. Check the workflow run URL in the event payload (generatorURL or monitor_url)
2. Identify the failing step in the workflow
3. Determine if it is a transient failure (flaky test, rate limit) or a real issue

Remediation:
1. For transient failures: trigger a workflow re-run via the retry-deployment playbook
2. For real failures: notify the dev team in #deployments and do NOT auto-retry
3. Never auto-deploy to production — require_approval must be true for prod deployments

Environments:
- dev / staging: auto-retry is acceptable
- prod: always require human approval before any action
```
**Action Hints:**
```json
{
  "ansible_template": "retry-deployment",
  "slack_channel": "#deployments",
  "notes": "Check the env label. If env=prod, request_approval instead of running directly. Include the repository name and branch in the Slack message."
}
```

---

### Editing and Deleting Documents

- Click a document in the Knowledge Base list to open it
- Edit any field and click **Save** — the embedding is automatically regenerated when title or content changes
- Click **Delete** to permanently remove the document and its embedding

---

## 7. Approvals

### Overview

When a Claude AI rule has `require_approval: true`, the agent proposes an action but does NOT execute it. Instead, it creates an approval request stored in the database. An operator must review and either approve or deny the request in the AEDA UI.

This implements human-in-the-loop control for high-stakes automation.

### Approval Request Contents

Each approval request captures:

| Field | Description |
|-------|-------------|
| **Event** | The original alert that triggered the rule |
| **Rule Name** | Which rule created the approval request |
| **Tool Name** | Which tool Claude wants to run (currently always `run_ansible`) |
| **Tool Params** | The exact parameters Claude would pass (template name, extra_vars, limit) |
| **Reason** | Claude's explanation of why this action is necessary |
| **Status** | `pending`, `approved`, or `denied` |
| **Created At** | When the request was created |
| **Resolved At** | When an operator acted on it |

### Approval Workflow

**Step 1.** An alert fires and matches a Claude rule with `require_approval: true`.

**Step 2.** Claude reasons through the alert (searches Knowledge Base, identifies the appropriate remediation), then calls `request_approval` instead of `run_ansible`.

**Step 3.** The Pending Approvals counter on the Dashboard increments. An alert badge appears on the Approvals menu item.

**Step 4.** The operator navigates to **Approvals** and reviews pending requests.

**Step 5.** For each pending request, the operator reads Claude's reasoning (viewable in the linked Audit Log entry) and either:
- Clicks **Approve** — AEDA immediately executes the stored tool call using the credentials from `tool_defaults`
- Clicks **Deny** — The request is marked denied and no action is taken

**Step 6.** The approval record is updated with the resolution status, timestamp, and (if approved) the execution result from AWX.

### Viewing Approval Details

Click any approval request to expand its detail panel, which shows:

- The full event title and source
- Claude's reason text (why it chose this action)
- The exact tool parameters that will be passed to AWX if approved
- Current status

To see the full AI reasoning chain that led to this approval request, navigate to **Audit Log** and filter by the matching rule name.

### Best Practices for Approvals

- **Review within SLA**: Approvals are not automatically expired. Establish an SLA for your team (e.g., review within 15 minutes for critical alerts).
- **Check the reason carefully**: Claude's reason text explains what the playbook does and why. If the reason does not match the alert symptoms, deny and investigate the rule/SOP.
- **Use filters**: The Approvals page can be filtered by `pending`, `approved`, or `denied` status.

---

## 8. Integrating Monitoring Tools

### 8.1 Uptime Kuma

Uptime Kuma is the recommended companion tool for AEDA. It is included in the Docker Compose stack and runs at `http://localhost:3001`.

#### Initial Setup

1. Open `http://localhost:3001` in your browser.
2. Create an admin account on first login.

#### Adding a Monitor

1. Click **Add New Monitor** (the plus button).
2. Select a monitor type: `HTTP(s)`, `TCP Port`, `Ping`, etc.
3. Fill in the monitor name and target URL or host.
4. Configure the check interval (default: 60 seconds).
5. Click **Save**.

#### Configuring the AEDA Notification

1. Navigate to **Settings** > **Notifications**.
2. Click **Setup Notification**.
3. Fill in the form:
   - **Notification Type**: Select `Webhook`
   - **Friendly Name**: `AEDA`
   - **URL**: `http://api:8000/sources/webhook/uptime-kuma`
     *(Use `api` as the hostname since Uptime Kuma and AEDA share a Docker network. If AEDA runs on a separate host, use the actual hostname/IP.)*
   - **Request Method**: `POST`
   - **Content Type**: `application/json`
4. Click **Test** to verify the connection — you should see a test event appear in AEDA Events.
5. Click **Save**.

#### Linking the Notification to a Monitor

1. Open a monitor and click **Edit**.
2. Scroll to the **Notifications** section.
3. Enable the **AEDA** notification.
4. Click **Save**.

Repeat for each monitor you want to send alerts to AEDA.

#### Setting Severity with Monitor Tags

By default, Uptime Kuma DOWN events map to `warning` severity in AEDA. To change severity per monitor:

1. Open the monitor and click **Edit**.
2. Scroll to **Tags** and click **Add Tag**.
3. Create (or select) a tag with:
   - **Name**: `severity`
   - **Value**: `critical` (or `warning` or `info`)
4. Save the monitor.

AEDA reads this tag and uses its value as the event severity. Add additional tags (e.g., `env=prod`, `team=platform`) to make them available as rule condition labels.

**Example rule that matches only critical production monitors:**

```json
{
  "name": "uptime-critical-prod",
  "sources": ["uptime-kuma"],
  "conditions": [
    "event.severity == 'critical'",
    "labels.get('state') == 'DOWN'",
    "labels.get('env') == 'prod'"
  ],
  "actions": [
    {"type": "slack", "message": ":fire: Production service DOWN: $event_title"}
  ]
}
```

---

### 8.2 Prometheus Alertmanager

Point Alertmanager's webhook receiver at AEDA's Prometheus endpoint.

#### Alertmanager Configuration

Add a receiver to your `alertmanager.yml`:

```yaml
receivers:
  - name: aeda
    webhook_configs:
      - url: 'http://your-aeda-host:8000/sources/webhook/prometheus'
        send_resolved: true
        http_config:
          tls_config:
            insecure_skip_verify: false

route:
  receiver: aeda
  # Or route specific alerts:
  routes:
    - match:
        severity: critical
      receiver: aeda
```

Reload Alertmanager to apply the change.

#### Prometheus Alert Labels

AEDA extracts all Prometheus alert labels into the AEDA event's `labels` dictionary. Use them in rule conditions:

```json
{
  "conditions": [
    "event.severity == 'critical'",
    "labels.get('job') == 'node_exporter'",
    "labels.get('instance') == 'web-01:9100'"
  ]
}
```

---

### 8.3 GitHub

Send GitHub repository events to AEDA for CI/CD automation.

#### Configuring a GitHub Webhook

1. Navigate to your repository on GitHub.
2. Go to **Settings** > **Webhooks** > **Add webhook**.
3. Fill in:
   - **Payload URL**: `http://your-aeda-host:8000/sources/webhook/github`
   - **Content type**: `application/json`
   - **Secret**: Optional — AEDA does not currently validate GitHub signatures, but recording it is good practice.
   - **Events**: Select individual events or "Send me everything"
4. Click **Add webhook**.

Useful events to send: `push`, `pull_request`, `deployment`, `deployment_status`, `workflow_run`.

---

### 8.4 Generic Webhook

Any system that can POST JSON can send events to AEDA.

**Endpoint:** `POST http://your-aeda-host:8000/sources/webhook/{source_name}`

Replace `{source_name}` with any identifier (e.g., `my-app`, `grafana`, `zabbix`).

AEDA's generic normalizer looks for standard fields in the payload:

| AEDA Field | Payload keys checked (in order) |
|------------|---------------------------------|
| `title` | `title`, `name`, `message`, `summary`, `description` |
| `severity` | `severity`, `level`, `priority`, `status` |
| `event_type` | `event_type`, `type`, `kind`, `action` |

Severity value mapping:

| Incoming value | AEDA severity |
|----------------|---------------|
| `critical`, `error`, `high`, `fatal` | `critical` |
| `warning`, `warn`, `medium` | `warning` |
| `info`, `low`, `debug`, `ok` | `info` |

**Example generic payload:**

```json
POST /sources/webhook/zabbix

{
  "title": "Disk space low on db-01",
  "severity": "warning",
  "event_type": "disk_alert",
  "host": "db-01",
  "disk_usage": "87%"
}
```

---

## 9. Events

### Viewing the Events List

Navigate to **Events** to see all ingested events in reverse-chronological order.

Each row shows: time, source, severity badge, event type, and title.

**Filtering options:**
- Filter by **severity** (info / warning / critical)
- Filter by **source** name
- Date range selection

### Event Detail Modal

Click any event row to open the detail modal. It contains two tabs:

**Labels tab:**  
Shows the structured key/value labels extracted from the source's payload. For Uptime Kuma, this includes `monitor_id`, `monitor_type`, `state`, `url`, and all custom monitor tags. For Prometheus, this shows all Alertmanager labels.

These are the values available in rule conditions via `labels.get('key')`.

**Payload tab:**  
Shows the raw, full JSON payload received from the source. This is the original data before normalization.

### Understanding Event Fields

| Field | Description |
|-------|-------------|
| `id` | UUID generated by AEDA at ingest time |
| `source` | Source name (e.g., `uptime-kuma`, `prometheus`) |
| `event_type` | Type string (e.g., `monitor_alert`, `alert`, `push`) |
| `severity` | Normalized severity: `info`, `warning`, or `critical` |
| `title` | Human-readable title generated by the source normalizer |
| `labels` | Structured key/value metadata (extracted by normalizer) |
| `payload` | Original JSON payload from the source |
| `timestamp` | UTC time when the event was ingested |

---

## 10. Audit Log

### Overview

The Audit Log records every action execution. Each entry captures the full lifecycle of a rule firing: which rule matched, what action ran, whether it succeeded, and — for Claude AI actions — the complete AI reasoning chain.

### Viewing the Audit Log

Navigate to **Audit Log** in the left sidebar.

**Available filters:**
- **Rule Name**: Show only entries for a specific rule
- **Status**: Filter by `success` or `failed`
- **Limit**: Number of entries to show (up to 500)

### Audit Entry Fields

| Field | Description |
|-------|-------------|
| `timestamp` | When the action was executed |
| `event_title` | Title of the triggering event |
| `rule_name` | Name of the rule that fired |
| `action_type` | Action type: `log`, `http`, `slack`, `ansible`, `claude`, `shell` |
| `status` | `success` or `failed` |
| `output` | Success output (e.g., Ansible job ID, Slack confirmation) |
| `error` | Error message if the action failed |
| `duration_ms` | Execution time in milliseconds |
| `reasoning` | AI reasoning turns (Claude AI actions only) |

### Reading AI Reasoning Chains

For Claude AI actions, clicking an audit entry expands the **Reasoning** panel showing the complete agent conversation:

1. **User turn**: The event prompt sent to Claude (filled-in template with actual event data)
2. **Assistant turn**: Claude's response, including any `tool_use` blocks showing which tool it called and with what parameters
3. **Tool result turn**: The output returned by each tool (AWX job ID, Slack confirmation, search results)
4. Repeat for each iteration of the agentic loop
5. **Final assistant turn**: Claude's summary of what it did and why

**Example reasoning sequence for a CPU alert with Knowledge Base:**

```
1. USER: Alert fired: Title: [FIRING] High CPU on web-01 ...
2. ASSISTANT: [tool_use: search_knowledge] query="high CPU web server"
3. TOOL RESULT: Found SOP "High CPU Usage Remediation" — action_hints: {ansible_template: "remediate-high-cpu", slack_channel: "#ops-alerts"}
4. ASSISTANT: [tool_use: run_ansible] template_name="remediate-high-cpu" extra_vars={host: "web-01"}
5. TOOL RESULT: Job 847 launched. Status URL: https://awx.example.com/api/v2/jobs/847/
6. ASSISTANT: [tool_use: send_slack] message="Launched remediate-high-cpu for web-01. AWX Job #847."
7. TOOL RESULT: Slack message sent
8. ASSISTANT (end_turn): Matched SOP 'High CPU Usage Remediation'. Launched AWX job #847. Notified #ops-alerts.
```

This full trace is stored permanently and lets you audit exactly what the AI decided, what it found in the Knowledge Base, and what actions it executed.

---

## 11. Webhook Tester

The Webhook Tester allows you to send a synthetic event payload directly to AEDA without needing a real monitoring tool. Use it to:

- Validate that a new rule matches the expected events
- Test action configurations before going live
- Simulate specific alert scenarios

### Using the Webhook Tester

1. Navigate to **Webhook Tester** in the left sidebar.
2. Select the **Source** from the dropdown (this determines which normalizer processes the payload).
3. Edit the JSON payload in the editor. Modify fields like `severity`, `title`, or specific labels as needed.
4. Click **Send Test Event**.
5. AEDA processes the payload exactly as if it came from a real source.
6. Navigate to **Events** to see the ingested event, and to **Audit Log** to see which rules fired and what actions ran.

### Example Payloads by Source

**Uptime Kuma (source: `uptime-kuma`):**

```json
{
  "heartbeat": {"status": 0, "msg": "Connection refused"},
  "monitor": {
    "id": 1,
    "name": "Production API",
    "type": "http",
    "url": "https://api.example.com/health",
    "tags": [
      {"name": "severity", "value": "critical"},
      {"name": "env", "value": "prod"},
      {"name": "team", "value": "platform"}
    ]
  },
  "msg": "Production API is down"
}
```

**Prometheus (source: `prometheus`):**

```json
{
  "alerts": [
    {
      "status": "firing",
      "labels": {
        "alertname": "HighCPUUsage",
        "severity": "warning",
        "instance": "web-01:9100",
        "job": "node_exporter",
        "env": "staging"
      },
      "annotations": {
        "summary": "CPU usage above 85% on web-01",
        "description": "CPU usage is 92% for the last 5 minutes"
      }
    }
  ]
}
```

**Generic (source: `my-app`):**

```json
{
  "title": "Database connection pool exhausted",
  "severity": "critical",
  "event_type": "db_error",
  "service": "order-service",
  "env": "production"
}
```

---

## 12. Rule Conditions Reference

Rule conditions are Python expressions evaluated in a restricted sandbox. All conditions for a rule must evaluate to `True` for the rule to fire (AND logic).

### Available Variables

| Variable | Type | Description |
|----------|------|-------------|
| `event` | AEDAEvent | Full event object. Access fields as `event.title`, `event.severity`, etc. |
| `payload` | dict | Raw payload dictionary (same as `event.payload`) |
| `labels` | dict | Labels dictionary (same as `event.labels`) |
| `severity` | str | Shortcut for `event.severity` |
| `source` | str | Shortcut for `event.source` |
| `event_type` | str | Shortcut for `event.event_type` |
| `title` | str | Shortcut for `event.title` |

### Event Object Fields

| Field | Type | Example values |
|-------|------|----------------|
| `event.severity` | str | `"info"`, `"warning"`, `"critical"` |
| `event.source` | str | `"uptime-kuma"`, `"prometheus"`, `"github"` |
| `event.event_type` | str | `"monitor_alert"`, `"alert"`, `"push"`, `"pull_request"` |
| `event.title` | str | `"[DOWN] Production API"` |
| `event.id` | str | UUID string |

### Condition Examples

**Match by severity:**
```python
event.severity == 'critical'
severity in ('warning', 'critical')
```

**Match by source:**
```python
event.source == 'uptime-kuma'
source not in ('github', 'prometheus')
```

**Match by source wildcard (always true — use when you want all sources):**
```python
# No condition needed; leave conditions list empty or use:
True
```

**Match by event type:**
```python
event.event_type == 'monitor_alert'
event_type in ('alert', 'monitor_alert')
```

**Match by title (substring):**
```python
'CPU' in event.title
'DOWN' in title
'production' in event.title.lower()
```

**Match by label value:**
```python
labels.get('env') == 'prod'
labels.get('state') == 'DOWN'
labels.get('team') == 'platform'
labels.get('severity') == 'critical'
```

**Match by label presence:**
```python
'env' in labels
labels.get('env', '') != ''
```

**Match by payload field:**
```python
payload.get('status') == 'firing'
payload.get('disk_usage', 0) > 85
str(payload.get('action', '')) == 'opened'
```

**Compound conditions (multiple conditions combined by AND):**
```python
# Condition 1:
event.severity == 'critical'
# Condition 2:
labels.get('env') == 'prod'
# Condition 3:
'DOWN' in event.title
# All three must be true for the rule to fire
```

**Using Python builtins:**
```python
len(event.title) > 10
any([labels.get('env') == 'prod', labels.get('env') == 'staging'])
all([event.severity == 'critical', labels.get('state') == 'DOWN'])
isinstance(payload.get('count'), int)
```

**Available safe builtins:** `len`, `str`, `int`, `float`, `list`, `dict`, `any`, `all`, `isinstance`

**GitHub-specific examples:**
```python
event.event_type == 'pull_request' and payload.get('action') == 'opened'
labels.get('repo') == 'my-org/my-repo'
event.event_type == 'workflow_run'
```

**Prometheus-specific examples:**
```python
labels.get('alertname') == 'HighCPUUsage'
labels.get('job') == 'node_exporter'
payload.get('status') == 'firing'
```

---

## 13. Troubleshooting

### AEDA UI does not load

**Symptom:** Browser shows connection refused or a blank page at `http://localhost:8000`.

**Checks:**
1. Run `docker-compose ps` — is the `api` container running?
2. Run `docker-compose logs api` — look for startup errors
3. Check if postgres is healthy: `docker-compose ps postgres` — must show `healthy`
4. If postgres is still starting, the API will restart automatically — wait 30 seconds and try again

---

### Events are ingested but no rules fire

**Symptom:** Events appear on the Events page but the Audit Log shows no entries.

**Checks:**
1. Navigate to **Rules** and confirm the rule is **enabled**
2. Check the **Sources** list on the rule — ensure it includes the source name sending events, or is set to `*`
3. Use the **Webhook Tester** to send a synthetic event that should match the rule. If it still does not fire, check:
   - Are all conditions correct? Test each condition individually
   - Are the label values what you expect? Open the event detail and check the Labels tab
4. Run `docker-compose logs api` and look for condition evaluation warnings like `Condition eval failed`

---

### Claude AI action fails immediately

**Symptom:** Audit Log shows a Claude action with `failed` status and error `ANTHROPIC_API_KEY is not configured`.

**Fix:** Add your Anthropic API key to `.env` and restart the API:
```bash
docker-compose restart api
```

---

### Claude AI action fails with tool errors

**Symptom:** Audit Log shows a Claude action where `run_ansible` failed with `ansible action requires 'url'`.

**Cause:** `tool_defaults` for `run_ansible` are not configured on the rule.

**Fix:** Add `tool_defaults` to the Claude action config:
```json
{
  "type": "claude",
  "tool_defaults": {
    "run_ansible": {
      "url": "https://awx.example.com",
      "token": "your-awx-token"
    }
  }
}
```

---

### Ansible action returns HTTP 401

**Symptom:** Audit Log shows `Launch failed: HTTP 401`.

**Cause:** Invalid or expired AWX OAuth2 token.

**Fix:**
1. Log into AWX > User Settings > Tokens
2. Create a new token with the required scopes
3. Update the `token` field in your rule's action config or `tool_defaults`

---

### Slack messages not sending

**Symptom:** Slack action shows `failed` in Audit Log with error about missing webhook URL.

**Fix:**
1. Ensure `SLACK_WEBHOOK_URL` is set in `.env` (or `webhook_url` is set directly on the action config)
2. Restart the API after changing `.env`: `docker-compose restart api`
3. Test your Slack webhook URL directly:
   ```bash
   curl -X POST -H 'Content-type: application/json' \
     --data '{"text":"AEDA test"}' \
     https://hooks.slack.com/services/YOUR/WEBHOOK/URL
   ```

---

### Uptime Kuma notifications not arriving in AEDA

**Symptom:** Uptime Kuma shows notifications being sent but no events appear in AEDA.

**Checks:**
1. Verify the notification URL in Uptime Kuma is `http://api:8000/sources/webhook/uptime-kuma` (use `api` hostname inside Docker network, not `localhost`)
2. Run `docker-compose logs api` and look for incoming requests on the uptime-kuma endpoint
3. Use the **Webhook Tester** in AEDA to confirm event ingestion works independently

---

### Approval requests not executing after approval

**Symptom:** Clicking Approve on an approval request shows an error or the AWX job does not launch.

**Checks:**
1. Verify `tool_defaults` on the rule includes valid `run_ansible` credentials
2. Check the Audit Log for the approval execution entry — it will contain the AWX error detail
3. Ensure AWX is reachable from the AEDA container: `docker-compose exec api curl -I https://awx.example.com`

---

### Database connection errors on startup

**Symptom:** `docker-compose logs api` shows `asyncpg.exceptions.ConnectionDoesNotExistError` or similar.

**Fix:** PostgreSQL is still starting. The API container will restart automatically. Wait 60 seconds and check again. If the problem persists:

```bash
docker-compose restart postgres
docker-compose restart api
```

---

### Knowledge Base search returns poor results

**Symptom:** Claude's `search_knowledge` tool returns unrelated SOPs or no results.

**Cause:** Vector embeddings use TF-IDF similarity by default. Document titles and content must be descriptive enough to match alert terminology.

**Fixes:**
1. Write SOP titles using the exact terminology that appears in alert names (e.g., `HighCPUUsage` not just `CPU Issue`)
2. Include symptom keywords in the SOP content that will appear in alert titles and labels
3. After updating documents, embeddings are regenerated automatically on save

---

*End of AEDA User Guide*
