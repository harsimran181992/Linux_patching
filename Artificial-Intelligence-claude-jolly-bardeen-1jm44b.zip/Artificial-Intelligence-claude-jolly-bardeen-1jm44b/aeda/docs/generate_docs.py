"""
Generate Word (.docx) and PowerPoint (.pptx) documents for AEDA.
Run: python generate_docs.py
Outputs: HLD.docx, LLD.docx, USER_GUIDE.docx, PRESENTATION.pptx
"""
from __future__ import annotations

import re
import os

# ─── Word document generator ─────────────────────────────────────────────────

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


def _set_heading_style(doc: Document):
    """Apply consistent corporate styles to the document."""
    # Normal style
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    for i in range(1, 5):
        style_name = f"Heading {i}"
        if style_name in doc.styles:
            h = doc.styles[style_name]
            h.font.name = "Calibri"
            h.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D) if i == 1 else (
                RGBColor(0x2E, 0x74, 0xB5) if i == 2 else
                RGBColor(0x1F, 0x49, 0x7D) if i == 3 else
                RGBColor(0x40, 0x40, 0x40)
            )
            h.font.size = Pt(20 - (i - 1) * 3)
            h.font.bold = True


def _add_cover_page(doc: Document, title: str, subtitle: str, doc_type: str):
    """Add a styled cover page."""
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph()

    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = t.add_run("AEDA")
    run.font.size = Pt(48)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)

    t2 = doc.add_paragraph()
    t2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = t2.add_run("AI-Enhanced Event-Driven Automation")
    run2.font.size = Pt(18)
    run2.font.color.rgb = RGBColor(0x40, 0x40, 0x40)

    doc.add_paragraph()

    t3 = doc.add_paragraph()
    t3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run3 = t3.add_run(title)
    run3.font.size = Pt(28)
    run3.font.bold = True
    run3.font.color.rgb = RGBColor(0x2E, 0x74, 0xB5)

    if subtitle:
        t4 = doc.add_paragraph()
        t4.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run4 = t4.add_run(subtitle)
        run4.font.size = Pt(14)
        run4.font.italic = True
        run4.font.color.rgb = RGBColor(0x70, 0x70, 0x70)

    doc.add_paragraph()
    doc.add_paragraph()

    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run5 = meta.add_run(f"Version 1.0  ·  Date: 2026-05-25  ·  Status: Living Document")
    run5.font.size = Pt(11)
    run5.font.color.rgb = RGBColor(0x70, 0x70, 0x70)

    doc.add_page_break()


def _parse_inline(run_parent, text: str):
    """Handle **bold**, *italic*, and `code` inline formatting."""
    parts = re.split(r'(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)', text)
    for part in parts:
        if part.startswith('**') and part.endswith('**'):
            r = run_parent.add_run(part[2:-2])
            r.bold = True
        elif part.startswith('*') and part.endswith('*'):
            r = run_parent.add_run(part[1:-1])
            r.italic = True
        elif part.startswith('`') and part.endswith('`'):
            r = run_parent.add_run(part[1:-1])
            r.font.name = "Courier New"
            r.font.size = Pt(10)
        else:
            if part:
                run_parent.add_run(part)


def _add_table_from_md(doc: Document, lines: list[str]):
    """Convert Markdown table lines to a Word table."""
    # Filter out separator lines (|---|---|)
    data_lines = [l for l in lines if not re.match(r'^\s*\|[-:| ]+\|\s*$', l)]
    rows = []
    for line in data_lines:
        cells = [c.strip() for c in line.strip().strip('|').split('|')]
        rows.append(cells)
    if not rows:
        return

    ncols = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=ncols)
    table.style = "Table Grid"

    for i, row_data in enumerate(rows):
        row = table.rows[i]
        for j, cell_text in enumerate(row_data):
            if j >= ncols:
                break
            cell = row.cells[j]
            cell.text = ""
            p = cell.paragraphs[0]
            _parse_inline(p, re.sub(r'\*\*([^*]+)\*\*', r'\1', cell_text))
            if i == 0:
                for run in p.runs:
                    run.bold = True
                # Shade header row
                tc = cell._tc
                tcPr = tc.get_or_add_tcPr()
                shd = OxmlElement('w:shd')
                shd.set(qn('w:val'), 'clear')
                shd.set(qn('w:color'), 'auto')
                shd.set(qn('w:fill'), '2E74B5')
                tcPr.append(shd)
                for run in p.runs:
                    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    doc.add_paragraph()


def md_to_docx(md_path: str, out_path: str, doc_type: str, subtitle: str = ""):
    """Convert a Markdown file to a well-formatted Word document."""
    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()

    doc = Document()
    _set_heading_style(doc)

    # Set margins
    for section in doc.sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1.2)
        section.right_margin = Inches(1.2)

    # Extract title from first H1
    lines = content.split('\n')
    title_line = next((l for l in lines if l.startswith('# ')), "AEDA Document")
    title = title_line.lstrip('# ').strip()

    _add_cover_page(doc, doc_type, subtitle, doc_type)

    i = 0
    in_code_block = False
    code_lines: list[str] = []
    table_lines: list[str] = []
    in_table = False

    while i < len(lines):
        line = lines[i]

        # Code block start/end
        if line.strip().startswith('```'):
            if in_code_block:
                # End code block — render accumulated lines
                in_code_block = False
                code_text = '\n'.join(code_lines)
                p = doc.add_paragraph()
                p.style = doc.styles["Normal"]
                r = p.add_run(code_text)
                r.font.name = "Courier New"
                r.font.size = Pt(9)
                # Add light grey shading
                pPr = p._p.get_or_add_pPr()
                shd = OxmlElement('w:shd')
                shd.set(qn('w:val'), 'clear')
                shd.set(qn('w:color'), 'auto')
                shd.set(qn('w:fill'), 'F2F2F2')
                pPr.append(shd)
                code_lines = []
            else:
                in_code_block = True
            i += 1
            continue

        if in_code_block:
            code_lines.append(line)
            i += 1
            continue

        # Table detection
        if line.strip().startswith('|'):
            table_lines.append(line)
            i += 1
            continue
        else:
            if table_lines:
                _add_table_from_md(doc, table_lines)
                table_lines = []

        # Headings
        heading_match = re.match(r'^(#{1,4})\s+(.*)', line)
        if heading_match:
            level = len(heading_match.group(1))
            text = heading_match.group(2).strip()
            # Skip table of contents entries
            if re.match(r'^\d+\.\s+\[', text) or re.match(r'^\s+-\s+\[', text):
                i += 1
                continue
            p = doc.add_heading(text, level=min(level, 4))
            i += 1
            continue

        # Horizontal rule
        if re.match(r'^---+\s*$', line):
            p = doc.add_paragraph('─' * 60)
            p.runs[0].font.color.rgb = RGBColor(0xCC, 0xCC, 0xCC)
            i += 1
            continue

        # Bullet list
        if re.match(r'^\s*[-*]\s+', line):
            text = re.sub(r'^\s*[-*]\s+', '', line)
            indent = len(line) - len(line.lstrip())
            list_level = indent // 2
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.left_indent = Inches(0.25 * (list_level + 1))
            _parse_inline(p, text)
            i += 1
            continue

        # Numbered list
        if re.match(r'^\s*\d+\.\s+', line):
            text = re.sub(r'^\s*\d+\.\s+', '', line)
            indent = len(line) - len(line.lstrip())
            p = doc.add_paragraph(style='List Number')
            p.paragraph_format.left_indent = Inches(0.25 + 0.25 * (indent // 2))
            _parse_inline(p, text)
            i += 1
            continue

        # Blockquote / note
        if line.strip().startswith('>'):
            text = line.strip().lstrip('> ')
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.5)
            r = p.add_run(text)
            r.italic = True
            r.font.color.rgb = RGBColor(0x50, 0x50, 0x50)
            i += 1
            continue

        # Skip ToC anchor lines like [Section](#anchor)
        if re.match(r'^\d+\.\s+\[', line.strip()):
            i += 1
            continue

        # Empty line
        if not line.strip():
            doc.add_paragraph()
            i += 1
            continue

        # Bold metadata lines (**Key:** value)
        if line.strip().startswith('**') and ':**' in line or line.strip().startswith('**') and line.strip().endswith('**'):
            p = doc.add_paragraph()
            _parse_inline(p, line.strip())
            i += 1
            continue

        # Normal paragraph
        p = doc.add_paragraph()
        _parse_inline(p, line.strip())
        i += 1

    # Flush any remaining table
    if table_lines:
        _add_table_from_md(doc, table_lines)

    doc.save(out_path)
    print(f"✓ Saved: {out_path}")


# ─── PowerPoint generator ─────────────────────────────────────────────────────

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor as PPTColor
from pptx.enum.text import PP_ALIGN


DARK_BG   = PPTColor(0x0F, 0x17, 0x2A)   # slate-950
NAVY      = PPTColor(0x1E, 0x3A, 0x8A)   # blue-800  (accent panel)
INDIGO    = PPTColor(0x43, 0x38, 0xCA)   # indigo-600
WHITE     = PPTColor(0xFF, 0xFF, 0xFF)
SLATE_200 = PPTColor(0xE2, 0xE8, 0xF0)
SLATE_400 = PPTColor(0x94, 0xA3, 0xB8)
YELLOW    = PPTColor(0xFB, 0xBF, 0x24)   # amber-400
GREEN     = PPTColor(0x34, 0xD3, 0x99)   # emerald-400
RED       = PPTColor(0xF8, 0x71, 0x71)   # red-400


def _slide_bg(slide, prs):
    """Fill slide background with dark colour."""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = DARK_BG


def _add_textbox(slide, text, left, top, width, height,
                 font_size=18, bold=False, color=WHITE, align=PP_ALIGN.LEFT,
                 italic=False, word_wrap=True):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = word_wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    run.font.name = "Calibri"
    return txBox


def _add_rect(slide, left, top, width, height, fill_color, radius=None):
    shape = slide.shapes.add_shape(
        1,  # MSO_SHAPE_TYPE.RECTANGLE
        left, top, width, height
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    shape.line.fill.background()
    return shape


def _header_bar(slide, prs, title: str, subtitle: str = ""):
    """Add a top header bar with title."""
    bar = _add_rect(slide, 0, 0, prs.slide_width, Inches(1.15), NAVY)
    _add_textbox(slide, title,
                 Inches(0.4), Inches(0.18), prs.slide_width - Inches(1),
                 Inches(0.6), font_size=28, bold=True, color=WHITE)
    if subtitle:
        _add_textbox(slide, subtitle,
                     Inches(0.4), Inches(0.72), prs.slide_width - Inches(1),
                     Inches(0.35), font_size=13, color=SLATE_400)


def _bullet_block(slide, items: list[str], left, top, width, height,
                  font_size=16, color=SLATE_200, icon="▸"):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    for idx, item in enumerate(items):
        if idx == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.space_before = Pt(4)
        run = p.add_run()
        run.text = f"{icon}  {item}"
        run.font.size = Pt(font_size)
        run.font.color.rgb = color
        run.font.name = "Calibri"


def _box_with_title(slide, title, items, left, top, width, height,
                    bg_color=NAVY, title_color=YELLOW, item_color=SLATE_200,
                    font_size=14):
    _add_rect(slide, left, top, width, height, bg_color)
    _add_textbox(slide, title, left + Inches(0.12), top + Inches(0.08),
                 width - Inches(0.2), Inches(0.35),
                 font_size=15, bold=True, color=title_color)
    if items:
        txBox = slide.shapes.add_textbox(
            left + Inches(0.12), top + Inches(0.4),
            width - Inches(0.2), height - Inches(0.5)
        )
        tf = txBox.text_frame
        tf.word_wrap = True
        for idx, item in enumerate(items):
            p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
            p.space_before = Pt(3)
            run = p.add_run()
            run.text = f"• {item}"
            run.font.size = Pt(font_size)
            run.font.color.rgb = item_color
            run.font.name = "Calibri"


def create_presentation(out_path: str):
    prs = Presentation()
    prs.slide_width  = Inches(13.33)
    prs.slide_height = Inches(7.5)

    blank_layout = prs.slide_layouts[6]  # blank

    # ── Slide 1: Title ──────────────────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)

    # Large logo area
    _add_rect(slide, Inches(0), Inches(0), prs.slide_width, Inches(7.5), DARK_BG)
    # Accent stripe top
    _add_rect(slide, 0, 0, prs.slide_width, Inches(0.08), INDIGO)
    # Accent stripe bottom
    _add_rect(slide, 0, prs.slide_height - Inches(0.08), prs.slide_width, Inches(0.08), INDIGO)

    _add_textbox(slide, "⚡ AEDA",
                 Inches(1), Inches(1.5), Inches(11), Inches(1.2),
                 font_size=72, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _add_textbox(slide, "AI-Enhanced Event-Driven Automation",
                 Inches(1), Inches(2.8), Inches(11), Inches(0.6),
                 font_size=24, color=SLATE_400, align=PP_ALIGN.CENTER)
    _add_textbox(slide, "Intelligent Remediation · Autonomous Operations · Human-in-the-Loop",
                 Inches(1), Inches(3.5), Inches(11), Inches(0.5),
                 font_size=16, italic=True, color=INDIGO, align=PP_ALIGN.CENTER)
    _add_textbox(slide, "Client Presentation  ·  v1.0  ·  2026",
                 Inches(1), Inches(6.4), Inches(11), Inches(0.4),
                 font_size=13, color=SLATE_400, align=PP_ALIGN.CENTER)

    # ── Slide 2: The Problem ────────────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "The Problem", "Why traditional automation is not enough")

    _bullet_block(slide, [
        "Alert fatigue — thousands of signals daily, most requiring manual triage",
        "Runbooks and SOPs locked in wikis, not machine-readable or actionable",
        "Traditional rule engines can route alerts but cannot reason about context",
        "Engineers spend hours on repetitive remediation instead of innovation",
        "Inconsistent application of procedures leads to outages and compliance gaps",
        "Growing infrastructure complexity outpaces team headcount",
    ], Inches(0.5), Inches(1.4), Inches(8), Inches(5.5),
       font_size=17, color=SLATE_200)

    # Stats box
    _box_with_title(slide, "Industry Reality", [
        "~70% of alerts require no human action",
        "MTTR averages 4+ hours without automation",
        "SRE teams spend 40% of time on toil",
        "Only 20% of runbooks are machine-executed",
    ], Inches(9), Inches(1.4), Inches(3.8), Inches(3.5),
       bg_color=PPTColor(0x1E, 0x1E, 0x3A), title_color=RED)

    # ── Slide 3: Solution Overview ──────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "AEDA — The Solution", "An AI-native event automation platform")

    _add_textbox(slide,
                 "AEDA bridges traditional rule-based automation with AI-driven contextual reasoning. "
                 "It ingests events from any monitoring source, evaluates them against configurable rules, "
                 "and uses Claude AI to select and execute the right remediation — guided by your SOPs.",
                 Inches(0.5), Inches(1.3), Inches(12.3), Inches(0.9),
                 font_size=15, color=SLATE_200)

    cols = [
        ("Event Ingestion", ["Webhooks from any source", "Uptime Kuma, Prometheus, GitHub", "Normalised + stored in PostgreSQL", "Labelled & classified"], Inches(0.4)),
        ("Rule Engine",     ["Priority-based matching", "Safe expression conditions", "Multiple actions per rule", "Instant + persistent"], Inches(3.6)),
        ("AI Agent",        ["Claude LLM tool-use loop", "RAG knowledge base (SOPs)", "Ansible AWX integration", "Slack / HTTP / Shell tools"], Inches(6.8)),
        ("Oversight",       ["Human-in-the-loop approvals", "Full audit trail", "Approval queue in UI", "Configurable per rule"], Inches(10.0)),
    ]
    for title, items, left in cols:
        _box_with_title(slide, title, items,
                        left, Inches(2.4), Inches(2.9), Inches(4.5),
                        bg_color=NAVY)

    # ── Slide 4: Architecture Diagram ───────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Architecture Overview", "End-to-end platform design")

    # Layer boxes
    layers = [
        ("External Sources",    "Uptime Kuma · Prometheus · GitHub · Generic Webhook",   Inches(0.3),  Inches(1.3),  INDIGO),
        ("Ingest API (FastAPI)", "POST /events  ·  /sources/webhook/*  ·  CORS + validation", Inches(0.3), Inches(2.3), PPTColor(0x0E, 0x7A, 0x9E)),
        ("Redis Queue",         "LPUSH aeda:event_queue  ·  BRPOP consumer  ·  TTL cache",   Inches(0.3), Inches(3.3), PPTColor(0x9E, 0x2A, 0x2A)),
        ("Rule Engine + Worker","find_matching_rules()  ·  priority order  ·  all matches fire", Inches(0.3), Inches(4.3), PPTColor(0x16, 0x6A, 0x34)),
        ("Action Executor",     "log · http · shell · slack · ansible · claude",              Inches(0.3), Inches(5.3), PPTColor(0x92, 0x4A, 0x00)),
    ]
    for title, desc, left, top, color in layers:
        _add_rect(slide, left, top, Inches(7.8), Inches(0.72), color)
        _add_textbox(slide, title, left + Inches(0.15), top + Inches(0.04),
                     Inches(2.5), Inches(0.35), font_size=13, bold=True, color=WHITE)
        _add_textbox(slide, desc, left + Inches(2.7), top + Inches(0.04),
                     Inches(5), Inches(0.35), font_size=11, color=SLATE_200)

    # Right column: storage
    right_boxes = [
        ("PostgreSQL",  "Events · Rules · Audit\nApprovals · Knowledge Docs\npgvector (RAG)",  Inches(8.5), Inches(1.3)),
        ("Claude Agent","Tool-use loop\nrun_ansible · send_slack\nsearch_knowledge · request_approval", Inches(8.5), Inches(3.3)),
        ("Operator UI", "Dashboard · Rules · Approvals\nKnowledge Base · Audit Log\nWebhook Tester",     Inches(8.5), Inches(5.3)),
    ]
    for title, desc, left, top in right_boxes:
        _add_rect(slide, left, top, Inches(4.4), Inches(1.55), NAVY)
        _add_textbox(slide, title, left + Inches(0.12), top + Inches(0.08),
                     Inches(4), Inches(0.38), font_size=14, bold=True, color=YELLOW)
        _add_textbox(slide, desc, left + Inches(0.12), top + Inches(0.48),
                     Inches(4), Inches(1), font_size=11, color=SLATE_200)

    # ── Slide 5: Key Features ────────────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Key Features", "What makes AEDA different")

    features = [
        ("🔁  Rule Engine",
         ["Condition-based matching with\nsafe expression eval",
          "Priority ordering, multi-action rules",
          "Persistent storage — survive restarts",
          "$variable substitution from event"]),
        ("🤖  Claude AI Agent",
         ["Multi-step tool-use loop",
          "Selects & runs correct Ansible playbook",
          "Uses RAG SOPs for guided remediation",
          "Configurable per-rule (model, tools)"]),
        ("📚  Knowledge Base",
         ["Semantic search via pgvector",
          "Structured action_hints in SOPs",
          "BAAI/bge-small-en-v1.5 embeddings",
          "REST CRUD + auto-embed on save"]),
        ("✅  Human-in-the-Loop",
         ["Operator approves AI actions before run",
          "Approval queue in UI with badge count",
          "Full reason + params stored for review",
          "Approved actions execute server-side"]),
        ("📋  Full Audit Trail",
         ["Every event, rule match, action logged",
          "AI reasoning chain stored",
          "Duration, status, error detail",
          "Searchable and filterable UI"]),
        ("🔗  Integrations",
         ["Uptime Kuma (heartbeat + tags)",
          "Ansible AWX/AAP (job templates)",
          "Slack incoming webhooks",
          "Generic HTTP, Shell, Log"]),
    ]

    positions = [
        (Inches(0.3),  Inches(1.3)),
        (Inches(4.55), Inches(1.3)),
        (Inches(8.8),  Inches(1.3)),
        (Inches(0.3),  Inches(4.1)),
        (Inches(4.55), Inches(4.1)),
        (Inches(8.8),  Inches(4.1)),
    ]

    for (title, items), (left, top) in zip(features, positions):
        _add_rect(slide, left, top, Inches(4.0), Inches(2.55), NAVY)
        _add_textbox(slide, title, left + Inches(0.12), top + Inches(0.08),
                     Inches(3.7), Inches(0.38), font_size=14, bold=True, color=YELLOW)
        txBox = slide.shapes.add_textbox(
            left + Inches(0.12), top + Inches(0.48),
            Inches(3.7), Inches(1.9)
        )
        tf = txBox.text_frame
        tf.word_wrap = True
        for idx, item in enumerate(items):
            p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
            p.space_before = Pt(3)
            r = p.add_run()
            r.text = f"• {item}"
            r.font.size = Pt(12)
            r.font.color.rgb = SLATE_200
            r.font.name = "Calibri"

    # ── Slide 6: AI Agent Deep Dive ──────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Claude AI Agent", "How AEDA uses AI for intelligent remediation")

    # Flow steps
    steps = [
        ("1", "Event Fires",       "Alert arrives via webhook,\nrule matches → Claude action"),
        ("2", "Search SOPs",       "search_knowledge() finds\nrelevant SOP from KB"),
        ("3", "Read action_hints", "SOP returns ansible_template,\nslack_channel, instructions"),
        ("4", "Execute Action",    "run_ansible() launches\nAWX job template"),
        ("5", "Approval (opt.)",   "request_approval() if\nrequire_approval: true"),
        ("6", "Summarise",         "Claude writes reasoning\nstored in audit log"),
    ]

    arrow_color = PPTColor(0x43, 0x38, 0xCA)
    for idx, (num, title, desc) in enumerate(steps):
        left = Inches(0.3 + idx * 2.15)
        top  = Inches(1.5)
        _add_rect(slide, left, top, Inches(1.9), Inches(2.0), NAVY)
        _add_textbox(slide, num, left + Inches(0.1), top + Inches(0.08),
                     Inches(0.4), Inches(0.38), font_size=22, bold=True, color=YELLOW)
        _add_textbox(slide, title, left + Inches(0.1), top + Inches(0.5),
                     Inches(1.7), Inches(0.38), font_size=13, bold=True, color=WHITE)
        _add_textbox(slide, desc, left + Inches(0.1), top + Inches(0.9),
                     Inches(1.7), Inches(1.0), font_size=11, color=SLATE_200)
        if idx < len(steps) - 1:
            _add_textbox(slide, "→", left + Inches(1.95), top + Inches(0.65),
                         Inches(0.3), Inches(0.4), font_size=22, bold=True, color=arrow_color)

    # Tools list
    _add_rect(slide, Inches(0.3), Inches(3.8), Inches(12.7), Inches(1.25), PPTColor(0x1A, 0x1A, 0x3A))
    _add_textbox(slide, "Available Tools:",
                 Inches(0.5), Inches(3.9), Inches(2), Inches(0.35),
                 font_size=13, bold=True, color=YELLOW)
    tools_text = "run_ansible  ·  query_ansible_templates  ·  send_slack  ·  send_http  ·  run_shell  ·  search_knowledge  ·  query_recent_events  ·  request_approval"
    _add_textbox(slide, tools_text,
                 Inches(2.4), Inches(3.9), Inches(10.5), Inches(0.9),
                 font_size=12, color=GREEN)

    # Config note
    _add_textbox(slide,
                 "⚙  Configurable per rule: model · allowed_tools · tool_defaults · max_iterations · use_knowledge_base · require_approval",
                 Inches(0.3), Inches(5.2), Inches(12.7), Inches(0.5),
                 font_size=12, italic=True, color=SLATE_400)

    # ── Slide 7: Knowledge Base / RAG ────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Knowledge Base (RAG)", "SOP-guided intelligent remediation")

    _add_textbox(slide,
                 "Each SOP document contains a structured action_hints block that tells the AI agent exactly what to do.",
                 Inches(0.5), Inches(1.3), Inches(12.3), Inches(0.5), font_size=15, color=SLATE_200)

    # Left: How it works
    _box_with_title(slide, "How It Works", [
        "1.  Operator creates SOP with action_hints",
        "2.  System embeds content with BAAI/bge-small-en-v1.5",
        "3.  Vector stored in PostgreSQL (pgvector)",
        "4.  Alert fires → Claude calls search_knowledge()",
        "5.  Cosine similarity retrieves top SOP match",
        "6.  action_hints.ansible_template used directly",
        "7.  No guessing — exact playbook name from SOP",
    ], Inches(0.4), Inches(1.95), Inches(5.5), Inches(4.9),
       bg_color=NAVY, font_size=13)

    # Right: Example SOP
    _add_rect(slide, Inches(6.3), Inches(1.95), Inches(6.7), Inches(4.9), PPTColor(0x0A, 0x0A, 0x1A))
    _add_textbox(slide, "Example SOP Document",
                 Inches(6.5), Inches(2.05), Inches(6), Inches(0.35),
                 font_size=13, bold=True, color=YELLOW)
    sop_text = (
        'title: "High CPU Alert"\n'
        'content: "Run CPU remediation playbook..."\n'
        'tags: ["cpu", "performance"]\n\n'
        'action_hints:\n'
        '  ansible_template: "cpu-remediation"\n'
        '  slack_channel: "#ops-alerts"\n'
        '  severity_threshold: "critical"\n'
        '  notes: "Check top processes first"'
    )
    _add_textbox(slide, sop_text,
                 Inches(6.5), Inches(2.5), Inches(6.3), Inches(3.2),
                 font_size=11, color=GREEN)

    # ── Slide 8: Human-in-the-Loop ───────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Human-in-the-Loop (HITL)", "Operator oversight for AI-driven actions")

    _add_textbox(slide,
                 "When require_approval: true is set on a rule, the AI agent pauses before executing Ansible and creates a pending approval for operator review.",
                 Inches(0.5), Inches(1.3), Inches(12.3), Inches(0.55), font_size=14, color=SLATE_200)

    # State machine
    states = [
        ("Alert Fires",  "Event matches\napproval rule",     Inches(0.4)),
        ("AI Analyses",  "Claude reasons,\nchooses playbook", Inches(3.1)),
        ("Pending",      "request_approval()\ncreates record", Inches(5.8)),
        ("Operator Acts","Reviews in UI:\nApprove / Deny",    Inches(8.5)),
        ("Executes",     "Approved: playbook\nruns server-side", Inches(11.2)),
    ]
    for title, desc, left in states:
        color = PPTColor(0x9E, 0x2A, 0x2A) if title == "Pending" else NAVY
        _add_rect(slide, left, Inches(2.1), Inches(2.3), Inches(2.2), color)
        _add_textbox(slide, title, left + Inches(0.1), Inches(2.2),
                     Inches(2.1), Inches(0.4), font_size=13, bold=True, color=YELLOW)
        _add_textbox(slide, desc, left + Inches(0.1), Inches(2.65),
                     Inches(2.1), Inches(0.9), font_size=12, color=SLATE_200)

    # Arrows
    for x in [Inches(2.75), Inches(5.45), Inches(8.15), Inches(10.85)]:
        _add_textbox(slide, "→", x, Inches(2.7), Inches(0.4), Inches(0.4),
                     font_size=22, bold=True, color=INDIGO)

    # What's stored
    _box_with_title(slide, "What operators see in the Approvals tab", [
        "Event title that triggered the action",
        "Rule name that matched",
        "Exact Ansible template + parameters",
        "AI reasoning: why this playbook was chosen",
        "One-click Approve or Deny buttons",
        "Red badge shows pending count in nav",
    ], Inches(0.4), Inches(4.6), Inches(8), Inches(2.5),
       bg_color=PPTColor(0x0A, 0x1A, 0x0A), title_color=GREEN, font_size=13)

    _box_with_title(slide, "Benefits", [
        "High-risk actions always reviewed",
        "AI works 24/7, humans decide",
        "Complete accountability",
    ], Inches(8.9), Inches(4.6), Inches(4.1), Inches(2.5),
       bg_color=PPTColor(0x1A, 0x0A, 0x0A), title_color=YELLOW, font_size=13)

    # ── Slide 9: Uptime Kuma Integration ─────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Monitoring Integration", "Uptime Kuma → AEDA → Ansible")

    _bullet_block(slide, [
        "Uptime Kuma sends webhook on monitor state change (DOWN / UP)",
        "AEDA normaliser extracts monitor name, status, all custom tags",
        "Tags become event labels: severity=critical, env=production, team=infra",
        "Labels are available as conditions in rules and as $variable in actions",
        "Rule matches on severity + source → triggers Claude AI action",
        "Claude queries Knowledge Base → finds matching SOP → runs Ansible playbook",
        "Result posted to Slack + stored in audit log",
    ], Inches(0.5), Inches(1.4), Inches(7.5), Inches(5),
       font_size=16, color=SLATE_200)

    _box_with_title(slide, "E2E Example", [
        "Monitor: api.example.com goes DOWN",
        'Tags: severity=critical, env=prod, service=api',
        "→  AEDA event: source=uptime_kuma",
        "→  Rule: AI-Remediation fires (priority 10)",
        "→  Claude searches KB: 'service down api'",
        "→  SOP found: ansible_template=restart-service",
        "→  AWX job launched → service restarted",
        "→  Slack: '✅ Service api restarted'",
    ], Inches(8.3), Inches(1.4), Inches(4.7), Inches(5),
       bg_color=PPTColor(0x0A, 0x1A, 0x0A), title_color=GREEN, font_size=12)

    # ── Slide 10: Current Status / Phases ────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Development Roadmap", "Current status and future phases")

    phases = [
        ("Phase 1 ✅",  "Foundation",         "FastAPI, PostgreSQL, Redis queue, CRUD API, basic UI",                              GREEN),
        ("Phase 2 ✅",  "Rule Engine",         "Persistent rules, priority matching, multi-action, audit log",                     GREEN),
        ("Phase 2b ✅", "AI Agent",            "Claude tool-use loop, Ansible integration, tool_defaults pattern",                  GREEN),
        ("Phase 2c ✅", "RAG + KB",            "pgvector, fastembed, SOP action_hints, KB-guided remediation",                     GREEN),
        ("Phase 2d ✅", "HITL Approvals",      "Approval queue, request_approval tool, UI badge, server-side execution",           GREEN),
        ("Phase 3 🔜",  "Webhook Auth + RBAC", "HMAC signatures on inbound, API key auth, role-based UI access",                   YELLOW),
        ("Phase 4 🔜",  "Multi-Tenancy",       "Workspace isolation, per-tenant rules and KB, SSO integration",                    YELLOW),
        ("Phase 5 🔜",  "Real-time & Analytics","WebSocket event stream, MTTR dashboard, cost tracking, SLA reports",              SLATE_400),
        ("Phase 6 🔜",  "Self-Healing Loop",   "AI learns from outcomes, auto-updates SOPs, predictive alerting",                  SLATE_400),
    ]

    col_w = Inches(1.55)
    row_h = Inches(0.55)
    headers = ["Phase", "Name", "Scope", "Status"]
    header_widths = [Inches(1.3), Inches(1.8), Inches(8.5), Inches(1.1)]

    # Header row
    x = Inches(0.3)
    for h, w in zip(headers, header_widths):
        _add_rect(slide, x, Inches(1.3), w, Inches(0.38), INDIGO)
        _add_textbox(slide, h, x + Inches(0.05), Inches(1.33),
                     w - Inches(0.1), Inches(0.35), font_size=12, bold=True, color=WHITE)
        x += w

    for idx, (phase, name, scope, color) in enumerate(phases):
        top = Inches(1.68) + idx * Inches(0.58)
        bg = PPTColor(0x1A, 0x1A, 0x2A) if idx % 2 == 0 else NAVY
        row_data = [phase, name, scope, "Done" if color == GREEN else "Planned"]
        x = Inches(0.3)
        for val, w in zip(row_data, header_widths):
            _add_rect(slide, x, top, w, Inches(0.55), bg)
            fc = color if val in ("Done", "Planned") else WHITE
            _add_textbox(slide, val, x + Inches(0.06), top + Inches(0.08),
                         w - Inches(0.1), Inches(0.38), font_size=11, color=fc)
            x += w

    # ── Slide 11: Security & Compliance ─────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Security & Compliance", "Built-in safeguards and audit capability")

    left_items = [
        ("Credential Isolation",
         "AWX tokens, Slack URLs stored in rule config. Merged server-side into tool calls. Never passed to Claude as arguments, never in logs."),
        ("Safe Expression Sandbox",
         "Rule conditions evaluated in a restricted Python eval sandbox. Only whitelisted builtins. No filesystem or network access."),
        ("Human-in-the-Loop",
         "High-risk Ansible actions require explicit operator approval. AI cannot execute destructive playbooks autonomously when gated."),
        ("Audit Non-Repudiation",
         "Every event, rule match, action, and AI reasoning step is persisted with timestamps. Cannot be modified post-write."),
    ]

    top = Inches(1.4)
    for title, desc in left_items:
        _add_rect(slide, Inches(0.4), top, Inches(6.1), Inches(1.2), NAVY)
        _add_textbox(slide, f"🔒  {title}",
                     Inches(0.55), top + Inches(0.08), Inches(5.8), Inches(0.35),
                     font_size=13, bold=True, color=YELLOW)
        _add_textbox(slide, desc,
                     Inches(0.55), top + Inches(0.45), Inches(5.8), Inches(0.65),
                     font_size=12, color=SLATE_200)
        top += Inches(1.35)

    _box_with_title(slide, "Roadmap Security Items", [
        "HMAC webhook signature validation",
        "Per-source secret keys",
        "API key authentication",
        "Role-based access control (RBAC)",
        "SSO / OIDC integration",
        "Network egress controls",
        "Secrets manager integration (Vault)",
    ], Inches(7), Inches(1.4), Inches(5.9), Inches(5.7),
       bg_color=PPTColor(0x1A, 0x0A, 0x0A), title_color=RED, font_size=13)

    # ── Slide 12: ROI & Business Value ───────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Business Value & ROI", "Measurable outcomes for operations teams")

    metrics = [
        ("↓ MTTR",         "From hours\nto minutes",         "Automated remediation\nexecutes in seconds"),
        ("↓ Alert Fatigue", "70% fewer\nmanual responses",   "AI filters + acts\nautonomously"),
        ("↑ Consistency",  "100% SOP\ncompliance",           "AI follows documented\nprocedures every time"),
        ("↑ Visibility",   "Full audit\ntrail",              "Every decision\nrecorded and queryable"),
    ]

    for idx, (metric, value, detail) in enumerate(metrics):
        left = Inches(0.4 + idx * 3.2)
        _add_rect(slide, left, Inches(1.4), Inches(2.9), Inches(2.8), NAVY)
        _add_textbox(slide, metric, left + Inches(0.12), Inches(1.5),
                     Inches(2.6), Inches(0.4), font_size=16, bold=True, color=YELLOW)
        _add_textbox(slide, value, left + Inches(0.12), Inches(1.95),
                     Inches(2.6), Inches(0.65), font_size=20, bold=True, color=GREEN)
        _add_textbox(slide, detail, left + Inches(0.12), Inches(2.65),
                     Inches(2.6), Inches(0.65), font_size=12, color=SLATE_200)

    _bullet_block(slide, [
        "No additional headcount required — AI handles routine remediation 24/7",
        "Open-source components (PostgreSQL, Redis, FastAPI) — no vendor lock-in",
        "Kubernetes-ready architecture scales horizontally as workload grows",
        "Per-rule AI configuration — expensive Claude actions only where needed",
        "HITL gates ensure accountability for regulatory and compliance requirements",
        "Knowledge Base captures institutional SRE knowledge — survives team turnover",
    ], Inches(0.4), Inches(4.5), Inches(12.5), Inches(2.7),
       font_size=15, color=SLATE_200, icon="✓")

    # ── Slide 13: Why AEDA ───────────────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)
    _header_bar(slide, prs, "Why AEDA?", "Competitive positioning")

    headers_row = ["Capability", "AEDA", "Ansible EDA", "PagerDuty", "Custom Scripts"]
    rows_data = [
        ["AI-guided remediation",      "✅ Full",    "❌",        "⚠ Limited",  "❌"],
        ["SOP Knowledge Base (RAG)",   "✅ Built-in","❌",        "⚠ Manual",   "❌"],
        ["Human-in-the-loop approvals","✅ Native",  "❌",        "✅ Manual",   "❌"],
        ["Webhook ingestion (any src)", "✅ Generic","✅",        "✅",          "⚠ Custom"],
        ["Full audit trail",           "✅",         "⚠ Partial","✅",          "❌"],
        ["Open source / self-hosted",  "✅",         "✅",        "❌",          "✅"],
        ["Operator UI",                "✅",         "⚠ Limited","✅",          "❌"],
    ]

    col_widths = [Inches(3.0), Inches(2.2), Inches(2.2), Inches(2.2), Inches(2.2)]
    header_bg = INDIGO

    x_start = Inches(0.3)
    y_header = Inches(1.35)
    x = x_start
    for h, w in zip(headers_row, col_widths):
        _add_rect(slide, x, y_header, w, Inches(0.38), header_bg)
        _add_textbox(slide, h, x + Inches(0.05), y_header + Inches(0.04),
                     w - Inches(0.1), Inches(0.32), font_size=12, bold=True,
                     color=WHITE, align=PP_ALIGN.CENTER)
        x += w

    for ri, row in enumerate(rows_data):
        y = Inches(1.73) + ri * Inches(0.56)
        bg = PPTColor(0x1A, 0x1A, 0x2A) if ri % 2 == 0 else NAVY
        x = x_start
        for ci, (val, w) in enumerate(zip(row, col_widths)):
            _add_rect(slide, x, y, w, Inches(0.53), bg)
            col = GREEN if "✅" in val else (RED if "❌" in val else YELLOW)
            _add_textbox(slide, val, x + Inches(0.05), y + Inches(0.07),
                         w - Inches(0.1), Inches(0.38), font_size=12,
                         color=col if ci > 0 else SLATE_200,
                         align=PP_ALIGN.CENTER if ci > 0 else PP_ALIGN.LEFT)
            x += w

    # ── Slide 14: Q&A / Thank You ────────────────────────────────────────────
    slide = prs.slides.add_slide(blank_layout)
    _slide_bg(slide, prs)

    _add_rect(slide, 0, 0, prs.slide_width, Inches(0.08), INDIGO)
    _add_rect(slide, 0, prs.slide_height - Inches(0.08), prs.slide_width, Inches(0.08), INDIGO)

    _add_textbox(slide, "Thank You",
                 Inches(1), Inches(1.3), Inches(11), Inches(1.2),
                 font_size=60, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _add_textbox(slide, "Questions & Discussion",
                 Inches(1), Inches(2.7), Inches(11), Inches(0.6),
                 font_size=24, color=SLATE_400, align=PP_ALIGN.CENTER)

    _add_rect(slide, Inches(2.5), Inches(3.6), Inches(8.3), Inches(2.4), NAVY)
    contact_lines = [
        "⚡  AEDA — AI-Enhanced Event-Driven Automation",
        "📦  Stack: FastAPI · PostgreSQL · Redis · Claude AI · pgvector",
        "🔗  Integrations: Uptime Kuma · Ansible AWX · Slack · Generic Webhook",
        "📋  Phases 1–2d complete  ·  Phases 3–6 on roadmap",
    ]
    txBox = slide.shapes.add_textbox(Inches(2.7), Inches(3.75), Inches(7.9), Inches(2.1))
    tf = txBox.text_frame
    tf.word_wrap = True
    for idx, line in enumerate(contact_lines):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.space_before = Pt(6)
        r = p.add_run()
        r.text = line
        r.font.size = Pt(14)
        r.font.color.rgb = SLATE_200
        r.font.name = "Calibri"

    prs.save(out_path)
    print(f"✓ Saved: {out_path}")


# ─── Main ────────────────────────────────────────────────────────────────────

DOCS_DIR = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":
    print("Generating AEDA documentation…\n")

    # Word: HLD
    hld_md = os.path.join(DOCS_DIR, "HLD.md")
    if os.path.exists(hld_md):
        md_to_docx(hld_md, os.path.join(DOCS_DIR, "HLD.docx"),
                   "High-Level Design Document",
                   "Architecture, Components, Phases, and Roadmap")
    else:
        print("⚠ HLD.md not found, skipping HLD.docx")

    # Word: LLD
    lld_md = os.path.join(DOCS_DIR, "LLD.md")
    if os.path.exists(lld_md):
        md_to_docx(lld_md, os.path.join(DOCS_DIR, "LLD.docx"),
                   "Low-Level Design Document",
                   "Component Internals, API Contracts, Data Schemas, and Implementation Details")
    else:
        print("⚠ LLD.md not found — will generate LLD.docx once LLD.md is ready")

    # Word: User Guide
    ug_md = os.path.join(DOCS_DIR, "USER_GUIDE.md")
    if os.path.exists(ug_md):
        md_to_docx(ug_md, os.path.join(DOCS_DIR, "USER_GUIDE.docx"),
                   "User Guide",
                   "Step-by-step guide for DevOps Engineers, SREs, and Platform Teams")
    else:
        print("⚠ USER_GUIDE.md not found, skipping USER_GUIDE.docx")

    # PowerPoint
    create_presentation(os.path.join(DOCS_DIR, "PRESENTATION.pptx"))

    print("\nDone! Files written to:", DOCS_DIR)
