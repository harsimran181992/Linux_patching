# AEDA — AI-Enhanced Event-Driven Automation
# Low-Level Design Document

**Version:** 0.2.0
**Date:** 2026-05-25
**Status:** Living Document

---

## Table of Contents

1. [Overview](#1-overview)
2. [Package Structure](#2-package-structure)
3. [Database Schema](#3-database-schema)
4. [API Endpoints](#4-api-endpoints)
5. [Event Processing Pipeline](#5-event-processing-pipeline)
6. [Rule Engine Internals](#6-rule-engine-internals)
7. [Claude Agent Tool-Use Loop](#7-claude-agent-tool-use-loop)
8. [RAG Pipeline](#8-rag-pipeline)
9. [Human-in-the-Loop (HITL) State Machine](#9-human-in-the-loop-hitl-state-machine)
10. [Environment Variable Reference](#10-environment-variable-reference)
11. [Future Phases](#11-future-phases)

---

## 1. Overview

AEDA is a FastAPI + async Python platform for intelligent, rule-driven automation. External systems emit events (via REST or webhooks); those events flow through a Redis-backed queue to a rule engine that matches them against user-defined rules; matching rules trigger one or more actions—ranging from a simple log entry to a full Claude AI agentic loop that can execute Ansible playbooks, send Slack notifications, make HTTP calls, and request human approval before taking destructive actions.

### Core Subsystems at a Glance

| Subsystem | Technology | Responsibility |
|-----------|------------|----------------|
| HTTP API | FastAPI + uvicorn | Event ingestion, CRUD, approval UI backend |
| Message queue | Redis (LPUSH/BRPOP) | Decouple ingestion from processing |
| Rule engine | Python `eval` sandbox | Match events to rules by source + conditions |
| Action executor | asyncio | Dispatch rule actions: log, http, shell, slack, ansible, claude |
| Claude agent | Anthropic SDK | Agentic tool-use loop for AI-driven remediation |
| RAG knowledge base | fastembed + pgvector | SOP search for Claude context |
| HITL approvals | PostgreSQL state machine | Human approval gate before destructive actions |
| Persistence | PostgreSQL + SQLAlchemy 2.0 async + asyncpg | All persistent state |

---

## 2. Package Structure

```
aeda/                            # repository root
├── main.py                      # uvicorn entry point
├── config.py                    # pydantic-settings Settings class
├── requirements.txt             # pinned Python dependencies
├── Dockerfile                   # multi-stage production image
├── docker-compose.yml           # postgres + redis + api + uptime-kuma
├── entrypoint.sh                # optional alembic upgrade + exec python main.py
├── alembic.ini                  # Alembic config
├── alembic/
│   ├── env.py                   # async Alembic env
│   └── versions/
│       ├── 0001_initial_schema.py       # sources, rules, events, audit_entries
│       ├── 0002_add_agent_reasoning.py  # audit_entries.reasoning JSONB column
│       ├── 0003_add_knowledge_docs.py   # knowledge_docs + pgvector extension
│       └── 0004_add_approvals.py        # approvals table
├── rules/                       # example YAML rule files (not used in Docker deploy)
│   ├── example_slack_alert.yaml
│   ├── example_shell_script.yaml
│   ├── example_multi_condition.yaml
│   ├── example_http_forward.yaml
│   └── example_webhook_rules.yaml
├── ui/
│   └── index.html               # single-file SPA (vanilla JS + TailwindCSS CDN)
└── aeda/                        # main Python package
    ├── __init__.py
    ├── models.py                # AEDAEvent, RuleData, ActionResult (Pydantic/dataclass)
    ├── rule_engine.py           # find_matching_rules(), _eval_condition() sandbox
    ├── action_executor.py       # execute_action() dispatcher + per-type handlers
    ├── embeddings.py            # lazy fastembed singleton, embed_text()
    ├── pipeline.py              # LEGACY in-memory pipeline (not used in Docker deploy)
    ├── agent/
    │   ├── __init__.py
    │   ├── runner.py            # run_agent() — Anthropic SDK agentic loop
    │   ├── executor.py          # execute_tool() dispatcher + all tool implementations
    │   └── tools.py             # TOOL_SCHEMAS dict + get_tool_schemas()
    ├── worker/
    │   ├── __init__.py
    │   ├── queue.py             # EventQueue (Redis LPUSH/BRPOP, QUEUE_KEY)
    │   └── processor.py         # EventProcessor, rule cache TTL=30 s, _process()
    ├── db/
    │   ├── __init__.py
    │   ├── base.py              # SQLAlchemy DeclarativeBase
    │   ├── orm.py               # Event, Rule, Source, AuditEntry, Approval, KnowledgeDoc ORM models
    │   └── session.py           # create_async_engine, AsyncSessionLocal, get_db()
    ├── sources/
    │   ├── __init__.py
    │   └── webhook.py           # webhook routes + normalizers (prometheus, github, uptime-kuma, generic)
    ├── repositories/
    │   ├── __init__.py
    │   ├── event_repo.py        # save_event(), list_recent(), mark_processed()
    │   ├── rule_repo.py         # list_rules(), get_rule(), create_rule(), update_rule(), delete_rule()
    │   ├── source_repo.py       # CRUD for sources
    │   ├── audit_repo.py        # list_audit(), count_by_status()
    │   ├── approval_repo.py     # create(), list_approvals(), get(), resolve(), count_pending()
    │   └── knowledge_repo.py    # save_doc(), list_docs(), get_doc(), update_doc(), delete_doc(), search_similar()
    └── api/
        ├── __init__.py
        ├── app.py               # FastAPI app, lifespan (queue + processor), CORS, router inclusion
        ├── deps.py              # get_db(), get_queue(), get_processor() FastAPI dependencies
        └── routers/
            ├── __init__.py
            ├── events.py        # POST /events/ingest, GET /events/recent
            ├── rules.py         # Full CRUD /rules
            ├── sources.py       # Full CRUD /sources
            ├── audit.py         # GET /audit, GET /audit/stats
            ├── health.py        # GET /health
            ├── knowledge.py     # Full CRUD /knowledge
            └── approvals.py     # GET /approvals, POST /approvals/{id}/approve|deny, GET /approvals/pending/count
```

### Per-File Responsibilities

#### `main.py`
Entry point. Reads `settings.LOG_LEVEL` for `logging.basicConfig`, then calls `uvicorn.run("aeda.api.app:app", host, port)`. Imports nothing from the `aeda` package except `config.settings`.

#### `config.py`
`pydantic_settings.BaseSettings` subclass `Settings`. Reads from `.env` file and environment. Exposes a `SYNC_DATABASE_URL` property that rewrites `postgresql+asyncpg` → `postgresql+psycopg2` for Alembic.

#### `aeda/models.py`
Three public types:
- `AEDAEvent` (Pydantic `BaseModel`): runtime event that flows through the pipeline. `to_eval_context()` flattens fields into a `dict` for the rule engine eval namespace.
- `RuleData` (Python `dataclass`): rule loaded from DB into the worker's in-memory cache.
- `ActionResult` (Pydantic `BaseModel`): result returned by every action handler; includes optional `reasoning` list for Claude's turn-by-turn log.

#### `aeda/rule_engine.py`
Pure functions: no I/O, no state. `_eval_condition(expression, context)` runs a single boolean Python expression in a locked-down namespace. `match_event(rule, event)` checks source filter then all conditions with `all()`. `find_matching_rules(rules, event)` is a list comprehension over all loaded rules.

#### `aeda/action_executor.py`
`execute_action(action_config, event)` is the top-level coroutine. Renders `$variable` placeholders via `_render()`, then dispatches to `_log_action`, `_http_action`, `_shell_action`, `_slack_action`, `_ansible_action`, or `_claude_action`. Each handler returns `ActionResult`. `_claude_action` imports `run_agent` lazily to avoid circular imports. The `_rule_name` key injected by the processor is consumed here to populate `_meta` for HITL approval records.

#### `aeda/embeddings.py`
Module-level singleton `_model`. `_get_model()` initialises `fastembed.TextEmbedding("BAAI/bge-small-en-v1.5")` on first call. `embed_text(text)` wraps `model.embed([text])` and returns a Python `List[float]` of length 384.

#### `aeda/agent/runner.py`
`run_agent(...)` coroutine. Builds the Anthropic client (direct or Azure AI Foundry endpoint depending on `ANTHROPIC_BASE_URL`). Maintains two parallel structures: `messages` (sent to the API each iteration) and `turns` (serialisable copy for audit storage). Loops up to `max_iterations` calling `client.messages.create`. On `stop_reason == "end_turn"` returns `AgentResult(success=True)`. On `stop_reason == "tool_use"` calls `execute_tool` for each `tool_use` block and appends results as `tool_result` content. On unexpected stop reason or iteration exhaust returns `AgentResult(success=False)`.

#### `aeda/agent/executor.py`
`execute_tool(tool_name, tool_input, event, defaults)` merges `defaults[tool_name]` with `tool_input` (tool input wins on conflicts), then dispatches to the appropriate implementation. `query_ansible_templates` additionally merges `run_ansible` defaults as a fallback so AWX credentials do not need to be duplicated. `_resolve_ansible_template` translates `template_name` → `template_id` via an AWX API call when only the name is provided.

#### `aeda/agent/tools.py`
`TOOL_SCHEMAS` dict mapping tool names to Anthropic-format JSON Schema descriptors. `get_tool_schemas(allowed_tools)` returns all schemas if the list is empty, or filters to the named subset.

#### `aeda/worker/queue.py`
`EventQueue` wraps `redis.asyncio`. `QUEUE_KEY = "aeda:event_queue"`. `push(event_data)` calls `LPUSH` (appends to the left/head). `pop(timeout)` calls `BRPOP` (blocks on the right/tail) — implements FIFO. `size()` is `LLEN`. `ping()` returns a boolean for health checks.

#### `aeda/worker/processor.py`
`EventProcessor` owns the rule cache (`List[RuleData]`) with TTL 30 s controlled by `_rules_loaded_at`. `start()` calls `_refresh_rules()` then spawns the `_worker()` task. The worker calls `queue.pop(timeout=1)` in a tight loop. After each pop, it checks the cache TTL and refreshes if stale. `_process(event_dict)` deserialises the dict back to `AEDAEvent`, calls `find_matching_rules`, marks the DB row processed, iterates matching rules and actions, calls `execute_action` with `_rule_name` injected, writes an `AuditEntry`, and commits in a single DB transaction.

#### `aeda/db/orm.py`
Six SQLAlchemy `DeclarativeBase` mapped classes: `Source`, `Rule`, `Event`, `Approval`, `KnowledgeDoc`, `AuditEntry`. Uses PostgreSQL-specific types: `UUID`, `JSONB`, `Vector(384)` from `pgvector.sqlalchemy`. `KnowledgeDoc.embedding` is `Vector(384)` nullable.

#### `aeda/db/session.py`
Creates the `AsyncEngine` with `pool_size=10`, `max_overflow=20`, `pool_pre_ping=True`. `AsyncSessionLocal` is an `async_sessionmaker` with `expire_on_commit=False`. Exports `get_db()` as a FastAPI dependency generator.

#### `aeda/sources/webhook.py`
FastAPI `APIRouter` at prefix `/sources/webhook`. Four normalizer functions convert raw payloads to `List[AEDAEvent]`:
- `normalize_prometheus`: iterates `alerts[]`, maps severity labels.
- `normalize_github`: switches on event type from `X-GitHub-Event` header.
- `normalize_uptime_kuma`: reads `heartbeat.status`, `monitor.name`, monitor tags.
- `normalize_generic`: heuristic key search for title, severity, event_type.

Shared helper `_ingest_events(request, events)` persists each event to DB and pushes to Redis queue.

#### `aeda/repositories/`
Thin async data access layer. Each module imports only its ORM model and `AsyncSession`. No business logic—only SQLAlchemy `select/insert/update/delete` wrapped in async functions. `knowledge_repo.search_similar` uses pgvector's `cosine_distance` operator via `KnowledgeDoc.embedding.cosine_distance(query_embedding)`.

#### `aeda/api/app.py`
Creates the `FastAPI` app with `lifespan` context manager. On startup: creates `EventQueue`, connects to Redis, creates `EventProcessor`, starts the worker task. On shutdown: stops processor, disconnects queue, disposes DB engine. Registers CORS middleware (`allow_origins=["*"]` — tighten in production). Serves `ui/index.html` at `GET /`.

---

## 3. Database Schema

All tables live in the default PostgreSQL schema (`public`). UUID primary keys are generated application-side (Python `uuid.uuid4()`). Timestamps are `TIMESTAMPTZ` (timezone-aware).

### 3.1 `sources`

Represents an external system that sends events to AEDA.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| `id` | `UUID` | PK | Generated by app |
| `name` | `VARCHAR(128)` | UNIQUE, NOT NULL | Machine-readable identifier; used in webhook URLs |
| `display_name` | `VARCHAR(256)` | NOT NULL, default `''` | Human-readable label |
| `source_type` | `VARCHAR(64)` | NOT NULL, default `'webhook_generic'` | One of: `webhook_generic`, `webhook_prometheus`, `webhook_github`, `manual` |
| `description` | `TEXT` | NOT NULL, default `''` | Free-text description |
| `config` | `JSONB` | NOT NULL, default `{}` | Source-specific configuration (e.g. shared secret for HMAC) |
| `enabled` | `BOOLEAN` | NOT NULL, default `true` | Soft-disable without deleting |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, server default `now()` | |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, server default `now()` | Application must update on writes |

**Indexes:** `sources_name_key` (unique on `name`).

### 3.2 `rules`

User-defined automation rules evaluated against every incoming event.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| `id` | `UUID` | PK | |
| `name` | `VARCHAR(256)` | UNIQUE, NOT NULL | Human-readable; used in audit entries and approval records |
| `description` | `TEXT` | NOT NULL, default `''` | |
| `enabled` | `BOOLEAN` | NOT NULL, default `true` | Disabled rules are not loaded into the worker cache |
| `sources` | `JSONB` | NOT NULL, default `["*"]` | List of source names; `["*"]` matches all sources |
| `conditions` | `JSONB` | NOT NULL, default `[]` | List of Python expression strings; empty list = always match |
| `actions` | `JSONB` | NOT NULL, default `[]` | Ordered list of action config objects |
| `priority` | `INTEGER` | NOT NULL, default `0` | Lower value = higher priority; rules sorted by `(priority, name)` |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, server default `now()` | |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, server default `now()` | |

**Indexes:**
- `rules_name_key` (unique on `name`)
- `ix_rules_enabled_priority` (composite on `enabled, priority`)

**Relationship:** one-to-many with `audit_entries` via `rule_id` FK (SET NULL on delete).

### 3.3 `events`

Immutable record of every event received by AEDA.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| `id` | `UUID` | PK | Generated by app before DB insert |
| `source` | `VARCHAR(128)` | NOT NULL, indexed | Source identifier string |
| `event_type` | `VARCHAR(128)` | NOT NULL | e.g. `alert`, `push`, `monitor_alert` |
| `severity` | `VARCHAR(32)` | NOT NULL, default `'info'`, indexed | One of: `info`, `warning`, `critical` |
| `title` | `TEXT` | NOT NULL | Human-readable summary |
| `payload` | `JSONB` | NOT NULL, default `{}` | Full raw payload from source |
| `labels` | `JSONB` | NOT NULL, default `{}` | Key-value string metadata (e.g. monitor tags) |
| `timestamp` | `TIMESTAMPTZ` | NOT NULL, indexed, server default `now()` | Event occurrence time |
| `processed_at` | `TIMESTAMPTZ` | NULL | Set by processor after rule evaluation; NULL = unprocessed |

**Indexes:**
- `ix_events_timestamp` on `timestamp` (descending queries)
- `ix_events_source` on `source`
- `ix_events_severity` on `severity`

**Relationship:** one-to-many with `audit_entries` via `event_id` FK (SET NULL on delete).

### 3.4 `audit_entries`

Append-only record of every action execution result.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| `id` | `UUID` | PK | |
| `timestamp` | `TIMESTAMPTZ` | NOT NULL, indexed, server default `now()` | When the action ran |
| `event_id` | `UUID` | FK → `events.id` SET NULL, indexed, nullable | NULL if the source event was deleted |
| `event_title` | `TEXT` | NOT NULL | Denormalised title snapshot |
| `rule_id` | `UUID` | FK → `rules.id` SET NULL, nullable | NULL if the rule was deleted |
| `rule_name` | `VARCHAR(256)` | NOT NULL, indexed | Denormalised name snapshot |
| `action_type` | `VARCHAR(64)` | NOT NULL | One of: `log`, `http`, `shell`, `slack`, `ansible`, `claude` |
| `status` | `VARCHAR(16)` | NOT NULL, indexed | `success` or `failed` |
| `output` | `TEXT` | nullable | Truncated stdout/response/summary |
| `error` | `TEXT` | nullable | Error message on failure |
| `duration_ms` | `INTEGER` | nullable | Wall-clock execution time |
| `reasoning` | `JSONB` | nullable | Claude agent turn-by-turn log (added in migration 0002) |

**Indexes:**
- `ix_audit_entries_timestamp`
- `ix_audit_entries_rule_name`
- `ix_audit_entries_status`
- `ix_audit_entries_event_id`

### 3.5 `approvals`

Human-in-the-loop approval records for AI-requested actions.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| `id` | `UUID` | PK | |
| `event_id` | `VARCHAR(64)` | nullable | String UUID of the triggering event |
| `event_title` | `TEXT` | NOT NULL | Snapshot of event title for UI display |
| `rule_name` | `VARCHAR(256)` | NOT NULL | Rule that triggered this approval request |
| `tool_name` | `VARCHAR(64)` | NOT NULL | Target tool (e.g. `run_ansible`) |
| `tool_params` | `JSONB` | NOT NULL, default `{}` | Parameters Claude wants to pass to the tool |
| `tool_defaults` | `JSONB` | NOT NULL, default `{}` | Credentials/defaults for the target tool (server-side only, never sent to Claude) |
| `reason` | `TEXT` | NOT NULL | Claude's explanation for why this action is needed |
| `status` | `VARCHAR(16)` | NOT NULL, indexed, default `'pending'` | State machine: `pending` → `approved` or `denied` |
| `result` | `TEXT` | nullable | Tool execution output (set on approve) or denial message |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, indexed, server default `now()` | |
| `resolved_at` | `TIMESTAMPTZ` | nullable | Set when approved or denied |

**Indexes:**
- `ix_approvals_status` on `status`
- `ix_approvals_created_at` on `created_at`

### 3.6 `knowledge_docs`

SOP (Standard Operating Procedure) documents for the RAG knowledge base.

| Column | Type | Constraints | Notes |
|--------|------|-------------|-------|
| `id` | `UUID` | PK | |
| `title` | `VARCHAR(256)` | NOT NULL | Document title (included in embedding input) |
| `content` | `TEXT` | NOT NULL | Full SOP procedure text |
| `tags` | `JSONB` | NOT NULL, default `[]` | String array for categorisation |
| `action_hints` | `JSONB` | NOT NULL, default `{}` | Machine-readable hints returned to Claude: e.g. `{"ansible_template": "cpu-remediation", "slack_channel": "#ops"}` |
| `embedding` | `vector(384)` | nullable | fastembed BAAI/bge-small-en-v1.5 embedding of `title + "\n" + content` |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, server default `now()` | |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, server default `now()` | |

**Indexes:** pgvector automatically supports cosine distance queries via the `<=>` operator. An `IVFFLAT` or `HNSW` index on the `embedding` column is recommended for production with large doc sets (not created by current migrations).

---

## 4. API Endpoints

Base URL: `http://host:8000`

### 4.1 Event Ingestion

#### `POST /events/ingest`
Accept a raw event payload and queue it for rule evaluation.

**Request body** (any JSON object — fields mapped by convention):
```json
{
  "source": "my-monitoring",
  "event_type": "disk_alert",
  "severity": "warning",
  "title": "Disk usage > 85% on web-01",
  "payload": {"disk_pct": 87, "host": "web-01"},
  "labels": {"env": "production", "team": "ops"}
}
```

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| `source` | string | `"unknown"` | Identifies the originating system |
| `event_type` | string | `"event"` | Subcategory of event |
| `severity` | string | `"info"` | `info`, `warning`, or `critical` |
| `title` | string | `"Untitled event"` | Human-readable summary |
| `payload` | object | `{}` | Arbitrary event data |
| `labels` | object | `{}` | String key-value metadata |

**Response** `202 Accepted`:
```json
{"accepted": true, "event_id": "3f4a2b1c-..."}
```

**Behaviour:** Generates UUID, persists to `events` table, pushes JSON-serialised `AEDAEvent` to Redis key `aeda:event_queue` via `LPUSH`.

#### `GET /events/recent`
List recent ingested events.

**Query parameters:**

| Parameter | Type | Default | Notes |
|-----------|------|---------|-------|
| `limit` | int | 50 | Max 500 |
| `source` | string | — | Filter by source name |
| `severity` | string | — | Filter by severity |

**Response** `200 OK`: Array of event objects with `id`, `source`, `event_type`, `severity`, `title`, `payload`, `labels`, `timestamp`, `processed` (boolean).

### 4.2 Rules CRUD

#### `GET /rules`

| Query param | Default | Notes |
|-------------|---------|-------|
| `enabled_only` | `false` | When `true`, returns only enabled rules |

**Response** `200 OK`: Array of rule objects.

#### `POST /rules`
Create a new rule.

**Request body:**
```json
{
  "name": "disk-alert-ansible",
  "description": "Run Ansible playbook when disk usage is critical",
  "enabled": true,
  "sources": ["my-monitoring"],
  "conditions": ["severity == 'critical'", "'disk' in event_type"],
  "actions": [
    {
      "type": "ansible",
      "url": "https://awx.example.com",
      "token": "my-token",
      "template_id": 42,
      "wait": true
    }
  ],
  "priority": 10
}
```

**Response** `201 Created`: Full rule object.
**Error** `409 Conflict`: Rule name already exists.

Side effect: calls `processor.invalidate_rules()` to force cache refresh on next worker tick.

#### `GET /rules/{rule_id}`
**Response** `200 OK`: Single rule object.
**Error** `404 Not Found`.

#### `PUT /rules/{rule_id}`
Partial update (fields omitted from body are unchanged).

**Response** `200 OK`: Updated rule object.
**Error** `404 Not Found`.
Side effect: calls `processor.invalidate_rules()`.

#### `DELETE /rules/{rule_id}`
**Response** `204 No Content`.
**Error** `404 Not Found`.
Side effect: calls `processor.invalidate_rules()`.

**Rule object schema:**
```json
{
  "id": "uuid",
  "name": "string",
  "description": "string",
  "enabled": true,
  "sources": ["*"],
  "conditions": ["severity == 'critical'"],
  "actions": [{"type": "log", "message": "$event_title"}],
  "priority": 0,
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

### 4.3 Sources CRUD

#### `GET /sources`
**Response** `200 OK`: Array of source objects (includes computed `webhook_url` for webhook source types).

#### `POST /sources`
**Request body:**
```json
{
  "name": "uptime-kuma-prod",
  "display_name": "Uptime Kuma Production",
  "source_type": "webhook_generic",
  "description": "Production monitoring via Uptime Kuma",
  "enabled": true,
  "config": {}
}
```
Valid `source_type` values: `webhook_generic`, `webhook_prometheus`, `webhook_github`, `manual`.

**Response** `201 Created`.
**Error** `409 Conflict` (name taken), `422 Unprocessable Entity` (invalid source_type).

#### `GET /sources/{source_id}`
**Response** `200 OK` | `404 Not Found`.

#### `PUT /sources/{source_id}`
Partial update.

#### `DELETE /sources/{source_id}`
**Response** `204 No Content` | `404 Not Found`.

**Source object schema:**
```json
{
  "id": "uuid",
  "name": "string",
  "display_name": "string",
  "source_type": "webhook_generic",
  "description": "string",
  "enabled": true,
  "config": {},
  "created_at": "ISO8601",
  "updated_at": "ISO8601",
  "webhook_url": "/sources/webhook/uptime-kuma-prod"
}
```

### 4.4 Webhook Ingestion

All webhook endpoints accept `POST`, return `202 Accepted`, and internally call `_ingest_events()` to persist and queue events.

#### `POST /sources/webhook/prometheus`
Accepts Prometheus Alertmanager webhook format. Iterates `alerts[]` array; creates one `AEDAEvent` per alert.

**Response:**
```json
{"accepted": true, "events_queued": 3}
```

#### `POST /sources/webhook/github`
Accepts GitHub webhook payloads. Reads `X-GitHub-Event` header (falls back to `payload.action`). Handles: `push`, `pull_request`, `deployment`, `deployment_status`, `workflow_run`, and generic fallback.

**Response:**
```json
{"accepted": true, "events_queued": 1, "event_type": "push"}
```

#### `POST /sources/webhook/uptime-kuma`
Accepts Uptime Kuma webhook payloads.

Expected payload structure:
```json
{
  "heartbeat": {"status": 0, "msg": "...", "duration": 120},
  "monitor": {
    "id": 1,
    "name": "My Service",
    "type": "http",
    "url": "https://example.com",
    "tags": [{"name": "severity", "value": "critical"}]
  },
  "msg": "My Service is down"
}
```

Severity logic: tag `name=severity` → value used directly; otherwise DOWN → `warning`, UP → `info`. All monitor tags are mapped to AEDA `labels` for rule condition access.

#### `POST /sources/webhook/{source_name}`
Generic fallback. Heuristically extracts `title`, `severity`, `event_type` from common field names (`title`, `name`, `message`, `summary`, `description`; `severity`, `level`, `priority`, `status`; `event_type`, `type`, `kind`, `action`).

### 4.5 Audit Log

#### `GET /audit`

| Query param | Default | Notes |
|-------------|---------|-------|
| `limit` | 50 | Max 500 |
| `rule_name` | — | Filter by exact rule name |
| `status` | — | Filter by `success` or `failed` |

**Response** `200 OK`: Array of audit entry objects including `reasoning` (Claude turn log, if applicable).

#### `GET /audit/stats`
**Response:**
```json
{"total": 150, "success": 130, "failed": 20}
```

### 4.6 Knowledge Base

#### `GET /knowledge`
**Response** `200 OK`: Array of knowledge doc objects.

#### `POST /knowledge`
Create a new SOP document. Automatically generates and stores a 384-dim embedding.

**Request body:**
```json
{
  "title": "High CPU Remediation SOP",
  "content": "1. Identify top processes via top.\n2. Run cpu-remediation Ansible playbook.\n3. Notify #ops-alerts channel.",
  "tags": ["cpu", "performance", "ansible"],
  "action_hints": {
    "ansible_template": "cpu-remediation",
    "slack_channel": "#ops-alerts"
  }
}
```

**Response** `201 Created`: Document object with `has_embedding: true`.

#### `GET /knowledge/{doc_id}`
**Response** `200 OK` | `404 Not Found`.

#### `PUT /knowledge/{doc_id}`
Partial update. Regenerates embedding whenever `title` or `content` changes.

#### `DELETE /knowledge/{doc_id}`
**Response** `204 No Content` | `404 Not Found`.

**Knowledge doc object schema:**
```json
{
  "id": "uuid",
  "title": "string",
  "content": "string",
  "tags": ["string"],
  "action_hints": {"ansible_template": "...", "slack_channel": "..."},
  "has_embedding": true,
  "created_at": "ISO8601",
  "updated_at": "ISO8601"
}
```

### 4.7 Approvals (HITL)

#### `GET /approvals`

| Query param | Default | Notes |
|-------------|---------|-------|
| `status` | — | Filter by `pending`, `approved`, or `denied` |

**Response** `200 OK`: Array of approval objects.

#### `GET /approvals/pending/count`
**Response:** `{"count": 3}`

#### `POST /approvals/{approval_id}/approve`
Approve and immediately execute the stored tool call.

1. Looks up the approval record; errors `404` if not found, `400` if already resolved.
2. Reconstructs a synthetic `AEDAEvent` from stored `event_id` and `event_title`.
3. Calls `execute_tool(tool_name, tool_params, event, {tool_name: tool_defaults})`.
4. Sets `status = "approved"`, `result = execution_output`, `resolved_at = now()`.

**Response** `200 OK`: Updated approval object.

#### `POST /approvals/{approval_id}/deny`
Deny the approval without executing.

1. Sets `status = "denied"`, `result = "Denied by operator"`, `resolved_at = now()`.

**Response** `200 OK`: Updated approval object.

**Approval object schema:**
```json
{
  "id": "uuid",
  "event_id": "string",
  "event_title": "string",
  "rule_name": "string",
  "tool_name": "run_ansible",
  "tool_params": {"template_name": "cpu-remediation", "extra_vars": {}},
  "reason": "CPU usage exceeded 90% for 10 minutes...",
  "status": "pending",
  "result": null,
  "created_at": "ISO8601",
  "resolved_at": null
}
```

Note: `tool_defaults` (credentials) is stored in the DB but **never** included in API responses.

### 4.8 System

#### `GET /health`
**Response:**
```json
{
  "status": "ok",
  "db": "ok",
  "redis": "ok",
  "queue_size": 0
}
```
`status` is `"degraded"` if either `db` or `redis` reports `"error"`. Performs live `SELECT 1` against PostgreSQL and `PING` against Redis.

#### `GET /`
Serves `ui/index.html` (single-file SPA). Not included in OpenAPI schema (`include_in_schema=False`).

---

## 5. Event Processing Pipeline

### 5.1 Ingestion Path (API → Redis)

```
HTTP Client
    │
    ▼
POST /events/ingest  (or /sources/webhook/*)
    │
    ├─ Normalise payload → AEDAEvent(id, source, event_type, severity, title, payload, labels, timestamp)
    │
    ├─ event_repo.save_event(db, {...})
    │     └─ INSERT INTO events ...  [commit]
    │
    └─ queue.push(event.model_dump(mode="json"))
          └─ LPUSH aeda:event_queue <json>
                                        [returns 202 immediately]
```

The API returns `202 Accepted` before rule evaluation begins. Ingestion latency is bounded by a single DB INSERT and a Redis LPUSH — typically sub-millisecond.

### 5.2 Worker Processing Path (Redis → DB)

```
EventProcessor._worker()                [asyncio.Task, name="aeda-processor"]
    │
    ├─ await queue.pop(timeout=1)
    │     └─ BRPOP aeda:event_queue 1
    │           [blocks up to 1 s if queue is empty]
    │
    ├─ if monotonic() - _rules_loaded_at > 30:
    │       await _refresh_rules()
    │             └─ SELECT * FROM rules WHERE enabled=true ORDER BY priority, name
    │                map to List[RuleData], update cache timestamp
    │
    └─ await _process(event_dict)
          │
          ├─ AEDAEvent(**event_dict)
          │
          ├─ matching = find_matching_rules(rules, event)
          │
          ├─ UPDATE events SET processed_at=now() WHERE id=event.id
          │
          ├─ if not matching: commit, return
          │
          └─ for rule in matching:
                for action_config in rule.actions:
                    t0 = monotonic()
                    enriched = {**action_config, "_rule_name": rule.name}
                    result = await execute_action(enriched, event)
                    duration_ms = int((monotonic() - t0) * 1000)
                    db.add(AuditEntry(..., reasoning=result.reasoning))
                commit()
```

### 5.3 Rule Cache Refresh

The worker holds rules in memory to avoid a DB query on every event. The cache is invalidated in two ways:

1. **TTL expiry:** `time.monotonic() - _rules_loaded_at > 30` — checked after every `BRPOP` return.
2. **Explicit invalidation:** Any rules CRUD endpoint calls `processor.invalidate_rules()`, which sets `_rules_loaded_at = 0.0`, forcing a refresh on the next worker tick.

The cache is refreshed _after_ the blocking pop, not before, so that any invalidation that occurred while `BRPOP` was waiting is picked up before the freshly dequeued event is processed.

### 5.4 Action Dispatch

`execute_action(action_config, event)` performs the following:

1. Extracts `action_type = action_config["type"].lower()`.
2. Calls `_render(v, event)` on every value in `action_config` except `"type"` — this substitutes `$variable` and `${variable}` placeholders using `string.Template.safe_substitute`.
3. Looks up the handler in `dispatch` dict; returns `ActionResult(success=False, error="Unknown action type")` if not found.
4. Calls the handler inside a `try/except` to catch unhandled errors.

**Template substitution variables available in `_render()`:**

| Variable | Value |
|----------|-------|
| `$event_id` | `event.id` |
| `$event_title` | `event.title` |
| `$event_source` | `event.source` |
| `$event_type` | `event.event_type` |
| `$event_severity` | `event.severity` |
| `$event_timestamp` | `str(event.timestamp)` |
| `$payload_raw` | `json.dumps(event.payload)` |
| `$labels_raw` | `json.dumps(event.labels)` |
| `$payload_{key}` | `str(event.payload[key])` for each key |
| `$label_{key}` | `event.labels[key]` for each key |

`safe_substitute` is used — unknown variables are left as-is rather than raising `KeyError`.

### 5.5 Per-Action Handler Details

#### `_log_action`
Calls the Python `logging` module at the specified level (`info`, `warning`, `error`, `debug`). Always returns `ActionResult(success=True)`.

#### `_http_action`
Uses `httpx.AsyncClient`. Sends the rendered `body` as JSON. Calls `response.raise_for_status()`. Returns first 300 chars of response text. Default timeout: 30 s.

#### `_shell_action`
Uses `asyncio.create_subprocess_shell`. Waits with `asyncio.wait_for(proc.communicate(), timeout)`. On timeout, kills the process. Returns first 500 chars of stdout on success, stderr on failure. Default timeout: 60 s.

#### `_slack_action`
Falls back to `SLACK_WEBHOOK_URL` env var if `webhook_url` not in params. Posts `{"text": message, "channel": channel}` to Slack Incoming Webhook. Uses `httpx.AsyncClient(timeout=10)`.

#### `_ansible_action`
1. Constructs launch URL: `{base_url}/api/v2/{job_templates|workflow_job_templates}/{template_id}/launch/`
2. Sends `POST` with `extra_vars` and optional `limit`. Auth via `Authorization: Bearer {token}` or HTTP basic auth.
3. If `wait=false` (default), returns immediately with job ID and status URL.
4. If `wait=true`, polls `GET {status_url}` every `poll_interval` seconds until status in `{"successful", "failed", "error", "canceled"}` or timeout.

#### `_claude_action`
See Section 7 for detailed agentic loop description.

---

## 6. Rule Engine Internals

### 6.1 Evaluation Sandbox

The rule engine uses Python's built-in `eval()` with a restricted namespace. The `__builtins__` key is set to an empty dict `{}` to prevent access to built-in functions that could pose security risks. An explicit allowlist of safe callables is provided:

```python
_SAFE_BUILTINS = {
    "__builtins__": {},
    "True": True, "False": False, "None": None,
    "len": len, "str": str, "int": int, "float": float,
    "list": list, "dict": dict, "any": any, "all": all,
    "isinstance": isinstance,
}
```

The evaluation namespace is `{**_SAFE_BUILTINS, **context}`. The `context` dict is populated from `AEDAEvent.to_eval_context()`:

```python
{
    "event":      <AEDAEvent>,   # full event object for attribute access
    "payload":    event.payload, # dict
    "labels":     event.labels,  # dict
    "severity":   event.severity,
    "source":     event.source,
    "event_type": event.event_type,
    "title":      event.title,
}
```

This gives rule authors access to:
- `severity == 'critical'`
- `'disk' in event_type`
- `payload.get('disk_pct', 0) > 90`
- `labels.get('env') == 'production'`
- `event.severity == 'warning' and 'web' in event.source`

Any exception during eval (syntax error, name error, etc.) is caught, logged as a WARNING, and treated as `False` (condition not met).

### 6.2 Condition Evaluation Flow

```
match_event(rule, event):
    if not rule.enabled:
        return False

    if "*" not in rule.sources AND event.source not in rule.sources:
        return False                           # source filter

    ctx = event.to_eval_context()
    return all(
        _eval_condition(condition_str, ctx)
        for condition_str in rule.conditions   # AND semantics
    )
    # Empty conditions list → all() of empty → True (catch-all rule)
```

`find_matching_rules(rules, event)` is a list comprehension:
```python
[r for r in rules if match_event(r, event)]
```

Rules in the worker's cache are already ordered by `(priority ASC, name ASC)` from the DB query, so matching rules are returned in priority order. Actions within a single rule are executed sequentially in definition order.

### 6.3 Example Rule Conditions

| Condition Expression | Matches When |
|---------------------|--------------|
| `severity == 'critical'` | Severity is exactly `critical` |
| `'disk' in event_type` | Event type contains the word `disk` |
| `payload.get('disk_pct', 0) > 85` | Payload has `disk_pct` field exceeding 85 |
| `labels.get('env') == 'production'` | Labels contain `env=production` |
| `source == 'uptime-kuma' and labels.get('state') == 'DOWN'` | Uptime Kuma monitor went DOWN |
| `any(w in title.lower() for w in ['cpu', 'memory', 'disk'])` | Title mentions common resource issues |
| `severity in ('warning', 'critical')` | Any non-info severity |

### 6.4 Security Considerations

The `eval` sandbox prevents access to `import`, `open`, `os`, and other dangerous builtins by setting `__builtins__` to `{}`. However, users with write access to the rules API can still cause:
- CPU exhaustion via deeply recursive expressions or large list comprehensions
- Infinite loops with complex generators

Production deployments should restrict rules write access to trusted operators. Future phases include RBAC (Phase 3) and expression pre-validation.

---

## 7. Claude Agent Tool-Use Loop

### 7.1 Architecture Overview

The Claude action in AEDA implements a stateful, multi-turn conversation with Claude using the Anthropic Messages API. The loop continues until Claude signals `stop_reason == "end_turn"` (conversation complete) or the iteration cap is reached.

```
_claude_action(params, event)
    │
    ├─ Determine system_prompt (with/without KB, with/without approval mode)
    ├─ Build allowed_tools list (filtering/adding tools based on flags)
    ├─ Inject _meta into tool_defaults["request_approval"] if require_approval
    │
    └─ run_agent(system_prompt, user_prompt, event, model, allowed_tools,
                 tool_defaults, max_iterations, max_tokens)
```

### 7.2 Agentic Loop Detail

```
run_agent():
    client = AsyncAnthropic(api_key, [base_url])
    tool_schemas = get_tool_schemas(allowed_tools)
    messages = [{"role": "user", "content": rendered_user_prompt}]
    turns = [...]   # serialisable copy for audit

    for iteration in range(max_iterations):      # default 8
        response = await client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system_prompt,
            messages=messages,
            tools=tool_schemas,                  # omitted if no tools
        )

        turns.append({role: "assistant", stop_reason, content: [...]})

        if response.stop_reason == "end_turn":
            return AgentResult(success=True, output=final_text, turns=turns)

        if response.stop_reason != "tool_use":
            return AgentResult(success=False, error=f"Unexpected: {stop_reason}")

        # Append assistant message (with tool_use blocks) to conversation
        messages.append({"role": "assistant", "content": response.content})

        tool_results = []
        for block in response.content:
            if block.type != "tool_use":
                continue
            result_str = await execute_tool(block.name, block.input, event, tool_defaults)
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": result_str,
            })
            turns.append({role: "tool_result", name, input, result})

        # Append tool results as next user turn
        messages.append({"role": "user", "content": tool_results})

    return AgentResult(success=False, error="Reached max_iterations")
```

### 7.3 Tool Dispatch and Defaults Merging

`execute_tool(tool_name, tool_input, event, defaults)`:

1. Load `base = defaults.get(tool_name, {})`. Special case: `query_ansible_templates` also merges from `defaults.get("run_ansible", {})` as a fallback so AWX credentials need not be duplicated.
2. Merge: `merged = {**base, **tool_input}`. Tool input (Claude's arguments) wins over defaults on key conflicts. This is the critical security boundary: credentials exist only in `base` (server-side config) and are never in `tool_input` (which Claude generated and which is visible in logs).
3. Dispatch to implementation.

### 7.4 Tool Implementations

#### `run_ansible`
1. `_resolve_ansible_template(merged)`: if `template_name` is set but `template_id` is not, queries `GET /api/v2/job_templates/?name={template_name}` to resolve the numeric ID. Raises `ValueError` if 0 or >1 results.
2. Delegates to `_ansible_action(merged, event)` from `action_executor`.

#### `query_ansible_templates`
Calls `GET /api/v2/job_templates/?page_size=50&order_by=name[&search={search}]` using AWX credentials from merged defaults. Returns a formatted string list of `ID, name, playbook, description`.

#### `send_slack`
Delegates to `_slack_action(merged, event)` from `action_executor`. Credentials (webhook_url) come from `tool_defaults["send_slack"]`.

#### `send_http`
Delegates to `_http_action(merged, event)` from `action_executor`.

#### `search_knowledge`
1. Calls `embed_text(query)` to get a 384-dim query vector.
2. Queries `knowledge_repo.search_similar(db, query_embedding, limit)` which uses pgvector cosine distance.
3. Formats results: title, relevance percentage `(1 - dist) * 100`, tags, full content, action_hints.
4. Returns formatted string to Claude.

#### `query_recent_events`
Queries the `events` table with optional filters (`source`, `event_type`, `severity`). Returns up to 50 records. If filters yield no results, falls back to unfiltered query and notes this to Claude.

#### `request_approval`
See Section 9 (HITL). Writes an `Approval` record to DB; returns a holding message to Claude instructing it not to retry.

### 7.5 `tool_defaults` Pattern and Credential Security

Credentials are never included in Claude's API arguments. The flow is:

```
Rule config (DB):
    tool_defaults:
        run_ansible:
            url: "https://awx.example.com"
            token: "secret-token"             ← server-side only

Claude API call → Claude decides to call run_ansible:
    block.input = {
        "template_name": "cpu-remediation",   ← Claude generated
        "extra_vars": {"host": "web-01"},     ← Claude generated
    }

execute_tool:
    base = {"url": "https://awx...", "token": "secret-token"}
    merged = {
        "url": "https://awx...",              ← from defaults
        "token": "secret-token",              ← from defaults
        "template_name": "cpu-remediation",   ← from Claude
        "extra_vars": {...},                  ← from Claude
    }
```

Claude only ever sees tool results (plain text strings), never the credential values.

### 7.6 Approval Mode

When `require_approval: true` is set in the action config:

1. `run_ansible` and `query_ansible_templates` are removed from `allowed_tools`.
2. `request_approval` is added to `allowed_tools`.
3. `_APPROVAL_INSTRUCTIONS` is appended to the system prompt, explicitly directing Claude to call `request_approval` instead of `run_ansible`.
4. A `_meta` dict is injected into `tool_defaults["request_approval"]`:
   ```python
   {
       "_meta": {
           "rule_name": "disk-alert-with-approval",
           "all_defaults": {<all tool_defaults>},
           "event_id": "3f4a2b1c-...",
           "event_title": "Disk usage > 85% on web-01",
       }
   }
   ```
5. When `_request_approval` runs, it extracts `_meta`, stores the `target_defaults` for the requested `tool_name`, and creates an `Approval` DB record with `status="pending"`.

### 7.7 System Prompt Selection

| `use_kb` | `require_approval` | System Prompt Logic |
|----------|-------------------|---------------------|
| `false` | `false` | `_DEFAULT_SYSTEM_NO_KB` |
| `true` | `false` | `_DEFAULT_SYSTEM_WITH_KB` |
| `false` | `true` | `_DEFAULT_SYSTEM_NO_KB` + `_APPROVAL_INSTRUCTIONS` |
| `true` | `true` | `_DEFAULT_SYSTEM_WITH_KB` + `_APPROVAL_INSTRUCTIONS` |
| any | any | Explicit `system_prompt` in rule config overrides all of the above |

The default user prompt (`_DEFAULT_USER`) includes all event fields and raw JSON payloads/labels. It is rendered through `_render()` before being sent to the API.

### 7.8 Azure AI Foundry Support

If `ANTHROPIC_BASE_URL` is set, the Anthropic client is constructed with a custom base URL:
```python
client = anthropic.AsyncAnthropic(
    api_key=settings.ANTHROPIC_API_KEY,
    base_url=settings.ANTHROPIC_BASE_URL,  # e.g. https://<resource>.services.ai.azure.com/anthropic
)
```
The rest of the API calls are identical to direct Anthropic. The default model in `docker-compose.yml` is `claude-sonnet-4-6`.

---

## 8. RAG Pipeline

### 8.1 Embedding Model

- **Model:** `BAAI/bge-small-en-v1.5` via `fastembed.TextEmbedding`
- **Dimensions:** 384
- **Initialisation:** Lazy singleton — loaded on first call to `embed_text()`. Subsequent calls reuse the in-process model.
- **Input:** `title + "\n" + content` (title is prepended to improve semantic matching)
- **Output:** `List[float]` of length 384

```python
# embeddings.py
def embed_text(text: str) -> List[float]:
    model = _get_model()                  # lazy init
    results = list(model.embed([text]))   # returns generator
    return results[0].tolist()            # numpy array → Python list
```

### 8.2 Document Storage

When a knowledge document is created or its title/content is updated, the API immediately generates a new embedding synchronously:

```
POST /knowledge  or  PUT /knowledge/{id} (with title/content change)
    │
    ├─ embed_text(f"{body.title}\n{body.content}")  → List[float] len=384
    │
    └─ knowledge_repo.save_doc(db, {
           "id": uuid4(),
           "title": ...,
           "content": ...,
           "tags": [...],
           "action_hints": {...},
           "embedding": <384-dim vector>,
       })
       └─ INSERT INTO knowledge_docs (embedding = vector(384)) ...
```

The embedding is stored as PostgreSQL `vector(384)` type from the `pgvector` extension.

### 8.3 Similarity Search

`knowledge_repo.search_similar(db, query_embedding, limit)`:

```python
dist_col = KnowledgeDoc.embedding.cosine_distance(query_embedding).label("dist")
stmt = (
    select(KnowledgeDoc, dist_col)
    .where(KnowledgeDoc.embedding.isnot(None))  # skip docs without embeddings
    .order_by(dist_col)                          # ascending = most similar first
    .limit(limit)
)
```

The `cosine_distance` operator (`<=>` in raw SQL) returns values in `[0, 2]` where 0 = identical. AEDA converts to a relevance percentage: `(1 - dist) * 100`.

The generated SQL is approximately:
```sql
SELECT knowledge_docs.*, (embedding <=> '[0.1, 0.2, ...]'::vector) AS dist
FROM knowledge_docs
WHERE embedding IS NOT NULL
ORDER BY dist ASC
LIMIT 3;
```

### 8.4 RAG in the Agent Loop

The `search_knowledge` tool integrates RAG into the Claude agent loop:

```
Claude calls search_knowledge(query="high cpu usage alert")
    │
    ├─ embed_text("high cpu usage alert") → 384-dim vector
    ├─ search_similar(db, vector, limit=3)
    │     └─ returns [(KnowledgeDoc, cosine_dist), ...]
    │
    └─ Formats result string:
       "Found 2 relevant SOP(s) for: 'high cpu usage alert'
        [1] High CPU Remediation SOP  (relevance: 92.3%)
            Tags: cpu, performance, ansible
            Procedure: 1. Identify top processes...
            Action hints (USE THESE for tool calls):
              ansible_template: 'cpu-remediation'
              slack_channel: '#ops-alerts'
        ..."
                    │
                    ▼
        Claude reads action_hints, extracts ansible_template
        Claude calls run_ansible(template_name="cpu-remediation")
```

The `action_hints` pattern is the key bridge between human-authored SOPs and machine-executable actions. When Claude finds `action_hints.ansible_template`, it should use that exact value as `template_name` in `run_ansible`, bypassing the need to call `query_ansible_templates`.

### 8.5 Production Indexing Recommendations

For knowledge bases with more than ~1000 documents, a vector index should be created:

```sql
-- IVFFLAT index (good for bulk insert, approximate search)
CREATE INDEX ON knowledge_docs USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- HNSW index (better recall, higher memory, faster queries)
CREATE INDEX ON knowledge_docs USING hnsw (embedding vector_cosine_ops) WITH (m = 16, ef_construction = 64);
```

Neither index is created by current Alembic migrations. Adding them is a Phase 3 task.

---

## 9. Human-in-the-Loop (HITL) State Machine

### 9.1 States and Transitions

```
                        ┌─────────────┐
                        │  [CREATED]  │
                        │   pending   │
                        └──────┬──────┘
                               │
               ┌───────────────┼───────────────┐
               ▼                               ▼
    POST /approvals/{id}/approve    POST /approvals/{id}/deny
               │                               │
    execute_tool(tool_name,                    │
        tool_params, event,                    │
        {tool_name: tool_defaults})            │
               │                               │
               ▼                               ▼
        ┌─────────────┐                ┌─────────────┐
        │  approved   │                │   denied    │
        │  (terminal) │                │  (terminal) │
        └─────────────┘                └─────────────┘
```

**Valid transitions:**
- `pending` → `approved` (via approve endpoint)
- `pending` → `denied` (via deny endpoint)

**Invalid transitions (return 400):**
- Any attempt to approve or deny an already-resolved record.

### 9.2 Creation Flow (Claude → DB)

```
EventProcessor._process(event)
    └─ execute_action({type: "claude", require_approval: true, ...}, event)
          └─ _claude_action(params, event)
                ├─ Injects _meta into tool_defaults["request_approval"]
                └─ run_agent(...)
                      └─ Claude decides to call request_approval(
                             tool_name="run_ansible",
                             tool_params={"template_name": "cpu-fix"},
                             reason="CPU at 95%, need to run remediation"
                         )
                               └─ execute_tool("request_approval", block.input, ...)
                                     └─ _request_approval(merged)
                                           │
                                           ├─ extract meta._meta: rule_name, all_defaults, event_id, event_title
                                           ├─ target_defaults = all_defaults["run_ansible"]
                                           │      = {url: "...", token: "..."}  (credentials)
                                           │
                                           └─ db.add(Approval(
                                                  tool_name="run_ansible",
                                                  tool_params={"template_name": "cpu-fix"},
                                                  tool_defaults=target_defaults,  ← credentials stored here
                                                  reason="CPU at 95%...",
                                                  status="pending",
                                              ))
                                              db.commit()
                                              return "Approval request submitted..."
```

Claude receives the holding message, summarises what it requested, and the conversation ends with `end_turn`. The `audit_entries` record for this action will have `status="success"` (the claude action itself succeeded; it is the downstream tool that awaits human approval).

### 9.3 Resolution Flow (Operator → Execution)

```
Operator opens AEDA UI → Approvals tab
    │
    ├─ GET /approvals?status=pending        → sees pending records
    │
    └─ POST /approvals/{id}/approve
          │
          ├─ approval_repo.get(db, id)       → load Approval record
          │
          ├─ Validate status == "pending"
          │
          ├─ _execute_approved(approval):
          │     event = AEDAEvent(
          │         id=approval.event_id,
          │         source="approval",
          │         event_type="approved_action",
          │         title=approval.event_title,
          │     )
          │     defaults = {approval.tool_name: approval.tool_defaults}
          │     result = await execute_tool(
          │         approval.tool_name,     # "run_ansible"
          │         approval.tool_params,   # {"template_name": "cpu-fix"}
          │         event,
          │         defaults,               # credentials retrieved from DB
          │     )
          │
          └─ approval_repo.resolve(db, id, status="approved", result=result_str)
                └─ UPDATE approvals SET status="approved", result=..., resolved_at=now()
```

The credentials are retrieved from `approval.tool_defaults` (stored in the `approvals` table when the request was created). They are never exposed to the UI — the API response serialiser explicitly excludes `tool_defaults`.

### 9.4 Key Security Properties

1. **Credentials are stored server-side only.** Claude never receives or generates credentials. They flow from `rule.actions[].tool_defaults` → `_meta.all_defaults` → `approval.tool_defaults` → execution.

2. **Claude cannot self-approve.** The approval endpoint is a separate HTTP call from a human operator. The agent loop has already terminated before any approval action is taken.

3. **Approved actions are idempotent by design.** Re-approving (attempting to approve an already-approved record) returns `400 Bad Request`. This prevents duplicate executions from double-clicks.

4. **Audit trail.** The `approvals` table records the full tool_params, reason, timestamps, and result, providing a complete record of what was requested and what was executed.

---

## 10. Environment Variable Reference

All variables are read by `config.py` via `pydantic-settings`. Defaults are shown; variables without defaults are required.

| Variable | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| `DATABASE_URL` | string | `postgresql+asyncpg://aeda:aeda@localhost:5432/aeda` | Yes | AsyncPG connection URL. Must use `postgresql+asyncpg` scheme. |
| `REDIS_URL` | string | `redis://localhost:6379/0` | Yes | Redis connection URL including DB index. |
| `LOG_LEVEL` | string | `INFO` | No | Python logging level: `DEBUG`, `INFO`, `WARNING`, `ERROR`. |
| `HOST` | string | `0.0.0.0` | No | Uvicorn bind address. |
| `PORT` | int | `8000` | No | Uvicorn listen port. |
| `SLACK_WEBHOOK_URL` | string | `""` | No | Default Slack Incoming Webhook URL for `_slack_action`. Overridden by per-rule `webhook_url`. |
| `ANTHROPIC_API_KEY` | string | `""` | For Claude | Anthropic API key (`sk-ant-...`). Also used as the API key for Azure AI Foundry when `ANTHROPIC_BASE_URL` is set. |
| `ANTHROPIC_BASE_URL` | string | `""` | No | Leave empty for direct Anthropic API. Set to Azure AI Foundry endpoint (e.g. `https://<resource>.services.ai.azure.com/anthropic`) to use Azure. |
| `ANTHROPIC_MODEL` | string | `"claude-opus-4-7"` | No | Default Claude model for the agent. Overridden per-rule via `actions[].model`. |
| `RUN_MIGRATIONS` | bool | `false` | No | When `true`, `entrypoint.sh` runs `alembic upgrade head` before starting uvicorn. Set to `"true"` in `docker-compose.yml`. |
| `POSTGRES_PASSWORD` | string | `aeda_secret` | Docker only | Used by `docker-compose.yml` to construct `DATABASE_URL`. Not read by `config.py` directly. |

### 10.1 `.env.example`

The repository includes `.env.example` with all variables. Copy to `.env` and populate:

```bash
DATABASE_URL=postgresql+asyncpg://aeda:aeda_secret@localhost:5432/aeda
REDIS_URL=redis://localhost:6379/0
LOG_LEVEL=INFO
HOST=0.0.0.0
PORT=8000
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_BASE_URL=
ANTHROPIC_MODEL=claude-sonnet-4-6
RUN_MIGRATIONS=false
```

### 10.2 Docker Compose Variables

The `docker-compose.yml` file uses the following variables (set in the host shell or a `.env` file in the project root):

| Variable | Used By | Notes |
|----------|---------|-------|
| `POSTGRES_PASSWORD` | `postgres` service, `api` service | Default: `aeda_secret` |
| `ANTHROPIC_API_KEY` | `api` service | Passed through from host environment |
| `ANTHROPIC_BASE_URL` | `api` service | Optional; for Azure AI Foundry |
| `ANTHROPIC_MODEL` | `api` service | Default: `claude-sonnet-4-6` |
| `SLACK_WEBHOOK_URL` | `api` service | Optional |

---

## 11. Future Phases

### Phase 3 — Security Hardening and Multi-Tenancy

#### 3.1 Multi-Tenancy

The current schema is single-tenant. To support multiple isolated tenants:

- Add a `tenant_id UUID NOT NULL` column to `rules`, `events`, `sources`, `approvals`, `knowledge_docs`, and `audit_entries`.
- Create a `tenants` table: `id`, `name`, `slug`, `config JSONB`, `created_at`.
- All repository queries become tenant-scoped by default: `WHERE tenant_id = :tenant_id`.
- The `EventProcessor` either runs one worker per tenant or uses a tenant-tagged queue key pattern: `aeda:event_queue:{tenant_id}`.
- Alembic migration adds the column with a default value (`00000000-0000-0000-0000-000000000000`) to preserve existing data.

#### 3.2 RBAC (Role-Based Access Control)

Introduce authentication and authorisation:

- New tables: `users` (id, email, hashed_password, tenant_id, created_at), `roles` (id, name, permissions JSONB), `user_roles` (user_id FK, role_id FK).
- Predefined roles: `viewer` (read-only), `operator` (can approve/deny, read all), `admin` (full CRUD including rules and sources).
- JWT-based authentication: `POST /auth/login` returns `access_token` (short TTL) and `refresh_token` (long TTL).
- FastAPI dependency `require_role(role)` extracted as a callable, injected into all sensitive endpoints.
- Approval endpoints specifically require the `operator` or `admin` role.
- Rule/source CRUD requires `admin` role.

#### 3.3 Webhook Authentication

Current webhook endpoints accept any payload without authentication:

- Add `shared_secret` field to `Source.config`.
- For Prometheus/GitHub, implement HMAC-SHA256 signature verification (`X-Hub-Signature-256`, `X-Alertmanager-Secret`).
- For generic webhooks, support Bearer token or HMAC header verification.
- Failed authentication returns `401 Unauthorized` and logs the attempt to an `auth_audit` table.
- Uptime Kuma supports a custom HTTP header for basic auth; implement header-based token verification.

#### 3.4 Vector Index for Production RAG

- Add Alembic migration to create an HNSW index on `knowledge_docs.embedding`:
  ```sql
  CREATE INDEX knowledge_docs_embedding_hnsw
      ON knowledge_docs USING hnsw (embedding vector_cosine_ops)
      WITH (m = 16, ef_construction = 64);
  ```
- Add `search_similar_by_threshold(db, query_embedding, threshold=0.7)` to `knowledge_repo` for relevance-filtered search.

---

### Phase 4 — Observability, Metrics, and Extended Integrations

#### 4.1 Real-Time UI (WebSocket)

Replace the current polling-based UI with a WebSocket-based push model:

- New endpoint `GET /ws` upgrades to WebSocket using FastAPI's `WebSocket` support.
- The `EventProcessor` publishes to an in-process `asyncio.Queue` on each processed event and new approval.
- A `WebSocketManager` (singleton on `app.state`) broadcasts serialised updates to all connected clients.
- Message types: `{"type": "event", "data": {...}}`, `{"type": "audit", "data": {...}}`, `{"type": "approval", "data": {...}}`.
- Frontend subscribes on load, updates the event table and approval badge without page refresh.
- Redis Pub/Sub (`SUBSCRIBE aeda:updates`) could replace the in-process queue for multi-instance deployments.

#### 4.2 Metric Collection

Expose Prometheus-compatible metrics:

- Integrate `prometheus-fastapi-instrumentator` for automatic HTTP request metrics (latency, status codes).
- Custom counters via `prometheus_client`:
  - `aeda_events_total{source, severity}` — events ingested
  - `aeda_rules_matched_total{rule_name}` — rule match frequency
  - `aeda_actions_total{action_type, status}` — action execution counts
  - `aeda_queue_size` gauge — current Redis queue depth
  - `aeda_approvals_pending` gauge — pending approvals count
  - `aeda_claude_iterations_total{rule_name}` — agent loop iterations
- New endpoint `GET /metrics` returns metrics in Prometheus text format.
- Grafana dashboard definition shipped as a JSON file in `docs/grafana/`.

#### 4.3 Alerting Integrations Beyond Uptime Kuma

Implement dedicated normalizers and webhook endpoints for:

- **PagerDuty:** `POST /sources/webhook/pagerduty` — parse PagerDuty Events v2 webhook; map `event.severity` and `event.summary`.
- **Datadog:** `POST /sources/webhook/datadog` — parse Datadog webhook format; support `alert_type`, `title`, `tags`.
- **Grafana:** `POST /sources/webhook/grafana` — parse Grafana Alerting unified webhook format; handle `firing` and `resolved` states.
- **OpsGenie:** `POST /sources/webhook/opsgenie` — parse OpsGenie alert webhook; map priority levels.
- **Zabbix:** `POST /sources/webhook/zabbix` — parse Zabbix media type webhook; map trigger severity.

Each normalizer follows the existing pattern: function `normalize_{source}(payload) -> List[AEDAEvent]` with standardised field mapping.

#### 4.4 Scheduled/Cron Events

Introduce a scheduler for time-based event generation:

- New table: `scheduled_events` (id, name, cron_expression, event_template JSONB, enabled, last_run_at).
- `APScheduler` integration running inside the FastAPI lifespan alongside `EventProcessor`.
- New CRUD endpoints: `GET/POST/PUT/DELETE /schedules`.
- Use cases: daily compliance checks, periodic health summary events, timed remediation windows.

---

### Phase 5 — Self-Healing Feedback Loop and Auto-SOP Generation

#### 5.1 Self-Healing Feedback Loop

Close the automation loop with outcome tracking:

- Add `outcome` field to `audit_entries`: `resolved`, `escalated`, `partial`, `unknown`.
- After a Claude action completes (or an approved Ansible job finishes), schedule a follow-up event check:
  - `POST /events/ingest` with `event_type="remediation_check"` and `labels: {"original_event_id": "...", "rule_name": "..."}`.
  - A rule matching `event_type == "remediation_check"` runs a Claude action that calls `query_recent_events` to check if the original alert recurred.
  - If the alert recurred within a configurable window, mark the outcome as `escalated` and notify `#ops-escalations` on Slack.
- New metric: `aeda_remediation_success_rate{rule_name}` — ratio of `resolved` to `resolved + escalated`.
- Build a feedback report API: `GET /reports/remediation-effectiveness` returns rule-level success rates and MTTR (Mean Time To Resolution) estimates.

#### 5.2 Auto-SOP Generation

Leverage successful remediation history to automatically draft new SOPs:

- After a rule's Claude action results in `outcome=resolved`, the system triggers an SOP generation job:
  - Collects: event payload, rule conditions, Claude's `reasoning` turns, tool calls made, tool results.
  - Sends to Claude with a prompt: "Based on the following remediation session, write a Standard Operating Procedure document..."
  - Saves the generated SOP as a draft `knowledge_doc` with `tags=["auto-generated", "draft"]`.
- Operators review and promote drafts to active SOPs via a `PUT /knowledge/{id}` with `tags` update.
- A "similar events" heuristic: before saving a new auto-SOP, search the knowledge base for existing docs with cosine similarity > 0.9 to avoid duplicates.
- New field `source_audit_id` in `knowledge_docs` linking auto-generated SOPs back to the audit entry that inspired them.

#### 5.3 Event Correlation and Deduplication

Prevent alert storms from triggering redundant actions:

- Add a `correlation_key` field to `AEDAEvent` and `events` table (populated by normalizers from incident ID, alert fingerprint, etc.).
- Rule engine gets a new optional field: `dedup_window_seconds` (default 0 = disabled).
- Before executing actions, the processor checks: `SELECT COUNT(*) FROM audit_entries WHERE rule_name=:rule_name AND timestamp > now() - :window AND status='success'`. If count > 0, skip and log a dedup event.
- New table `event_correlations` (correlation_key, first_event_id, last_event_id, event_count, last_seen_at) for grouping related events in the UI.

#### 5.4 Approval Delegation and Escalation

Extend the HITL system:

- Add `assigned_to` (user_id FK nullable) and `escalated_at` (TIMESTAMPTZ nullable) to `approvals`.
- `POST /approvals/{id}/assign` — operator claims an approval for themselves.
- Auto-escalation: a background task checks for approvals with `status='pending'` and `created_at < now() - :sla_minutes`. Escalates by sending a Slack DM to the on-call user and setting `escalated_at`.
- `POST /approvals/{id}/delegate/{user_id}` — transfer ownership to another operator.
- Approval SLA configuration in `Source.config` or system-wide env var `APPROVAL_SLA_MINUTES` (default 60).

#### 5.5 Multi-Step Approval Workflows

For high-risk actions requiring multiple reviewers:

- New field `required_approvals: int` on rules (default 1).
- New table `approval_votes` (approval_id FK, user_id FK, vote `approve|deny`, timestamp, comment).
- An approval transitions to `approved` only when `COUNT(votes WHERE vote='approve') >= required_approvals`.
- Any `deny` vote immediately transitions to `denied` regardless of required_approvals count.
- The approval detail view in the UI shows all votes and a comment thread.

#### 5.6 Plugin Architecture

Decouple action types and normalizers from the core:

- Define `ActionPlugin` and `NormalizerPlugin` abstract base classes.
- Plugins discovered via Python entry points (`setuptools` plugin system) or a `plugins/` directory with auto-import.
- Each plugin registers its action type name(s) and async handler coroutine.
- Enables third-party action types (e.g. Jira ticket creation, ServiceNow incident management, AWS SSM documents) without modifying core AEDA code.
- Plugin metadata (name, version, author, description) exposed via `GET /plugins`.

---

## Appendix A: Data Flow Diagram

```
External Sources                AEDA API             Internal Services
─────────────────           ─────────────────       ─────────────────
Uptime Kuma     ──POST──►  /sources/webhook/         Redis
Prometheus      ──POST──►  uptime-kuma          ──LPUSH──►  aeda:event_queue
GitHub          ──POST──►  /prometheus                         │
Custom App      ──POST──►  /github               ◄──BRPOP──┘
                           /events/ingest                      │
                                │                              ▼
                                │                       EventProcessor
                                │                              │
                                ▼                    find_matching_rules()
                          PostgreSQL                           │
                          (events table)               execute_action()
                                                              │
                               ┌───────┬──────────┬──────────┼──────────┐
                               ▼       ▼          ▼          ▼          ▼
                             log    http       slack      ansible    claude
                                                                       │
                                                              ┌────────┴────────┐
                                                              ▼                 ▼
                                                         run_agent()      request_approval()
                                                              │                 │
                                                   ┌──────────┼──────┐         ▼
                                                   ▼          ▼      ▼    approvals table
                                             search_kb  run_ansible  ...       │
                                               (pgvec)  (AWX API)        Operator UI
                                                                         POST /approve
                                                                               │
                                                                         execute_tool()
```

## Appendix B: Alembic Migration Chain

| Revision | Name | Changes |
|----------|------|---------|
| `0001` | `initial_schema` | Creates `sources`, `rules`, `events`, `audit_entries` |
| `0002` | `add_agent_reasoning` | Adds `reasoning JSONB` column to `audit_entries` |
| `0003` | `add_knowledge_docs` | Enables `pgvector` extension; creates `knowledge_docs` with `vector(384)` |
| `0004` | `add_approvals` | Creates `approvals` table |

Run `alembic upgrade head` or set `RUN_MIGRATIONS=true` in Docker to apply all migrations.

## Appendix C: Dependency Versions

| Package | Version | Purpose |
|---------|---------|---------|
| `fastapi` | 0.115.0 | HTTP framework |
| `uvicorn[standard]` | 0.30.6 | ASGI server |
| `pydantic` | 2.8.2 | Data validation and serialisation |
| `pydantic-settings` | 2.4.0 | Settings from environment |
| `sqlalchemy[asyncio]` | 2.0.35 | ORM + async engine |
| `asyncpg` | 0.29.0 | Async PostgreSQL driver |
| `psycopg2-binary` | 2.9.9 | Sync PostgreSQL driver (Alembic only) |
| `alembic` | 1.13.3 | Database migrations |
| `redis[asyncio]` | 5.1.1 | Async Redis client |
| `httpx` | 0.27.2 | Async HTTP client (actions + AWX) |
| `pyyaml` | 6.0.2 | YAML rule file parsing (legacy pipeline) |
| `python-dotenv` | 1.0.1 | `.env` file loading |
| `anthropic` | >=0.40.0 | Anthropic Messages API + Azure AI Foundry |
| `fastembed` | >=0.4.0 | Local text embedding (BAAI/bge-small-en-v1.5) |
| `pgvector` | >=0.3.0 | pgvector SQLAlchemy integration |
