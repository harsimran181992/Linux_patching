# AEDA — AI-Enhanced Event-Driven Automation
# High-Level Design Document

**Version:** 1.0  
**Date:** 2026-05-25  
**Status:** Living Document  
**Audience:** Engineering Leadership, Solution Architects, Senior Engineers

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Overview and Goals](#2-system-overview-and-goals)
3. [Architecture Overview](#3-architecture-overview)
4. [Core Components](#4-core-components)
5. [Integration Landscape](#5-integration-landscape)
6. [Data Flow Diagrams](#6-data-flow-diagrams)
7. [Technology Stack](#7-technology-stack)
8. [Development Phases](#8-development-phases)
9. [Non-Functional Requirements](#9-non-functional-requirements)
10. [Deployment Architecture](#10-deployment-architecture)
11. [Roadmap and Timeline](#11-roadmap-and-timeline)

---

## 1. Executive Summary

AEDA (AI-Enhanced Event-Driven Automation) is an enterprise automation platform that processes operational events from disparate monitoring and CI/CD systems, evaluates them against configurable rules, and executes automated or AI-directed remediation actions with a full audit trail.

The platform's central differentiator is the integration of Claude (Anthropic's large language model) as an intelligent remediation agent. When a traditional rule engine is insufficient — when events require contextual reasoning, selection among multiple possible remediation paths, or synthesis of documented operating procedures — the Claude agent takes over. It queries an internal SOP knowledge base, selects the appropriate Ansible automation, and either executes it autonomously or routes it through a human-in-the-loop approval queue.

AEDA bridges the gap between traditional automation frameworks (Ansible EDA, Alertmanager routing) and the emerging paradigm of AI-driven operations. It is production-ready for small-to-medium infrastructure teams and provides a clear architectural foundation for scaling to multi-tenant enterprise deployments.

**Key outcomes:**
- Reduction in mean time to remediation (MTTR) through automated and AI-guided response
- Consistent application of documented SOPs at machine speed
- Operator oversight preserved via human-in-the-loop approvals for high-risk actions
- Complete audit trail of all events, decisions, and actions for compliance and learning

---

## 2. System Overview and Goals

### 2.1 Problem Statement

Modern infrastructure operations teams face an alert fatigue crisis. Observability tooling generates thousands of signals daily, but the runbooks and institutional knowledge required to act on those signals remain locked in wikis, in engineers' heads, or encoded in bespoke shell scripts. Existing automation frameworks like Ansible EDA or PagerDuty workflows address routing but lack the contextual reasoning to select the right remediation from a catalog of options or to adapt to novel situations.

### 2.2 Goals

| Priority | Goal |
|----------|------|
| P0 | Reliable, low-latency ingestion of events from any source via webhooks |
| P0 | Rule-based matching and action execution with persistent storage |
| P0 | Complete audit log of every event, rule match, and action outcome |
| P1 | Claude AI agent capable of multi-step remediation with tool use |
| P1 | RAG-powered SOP knowledge base for procedure-guided automation |
| P1 | Human-in-the-loop approval queue for high-risk automated actions |
| P2 | Analytics and reporting for MTTR, automation coverage, and cost |
| P2 | Multi-tenancy and RBAC for enterprise organizational boundaries |
| P3 | Predictive alerting and self-healing before failures manifest |

### 2.3 Non-Goals (Current Scope)

- AEDA is not a metrics storage or time-series database — it consumes events from monitoring systems, not raw metrics
- AEDA does not replace Ansible AWX/AAP — it orchestrates them via REST API
- AEDA is not a general-purpose workflow orchestrator — it is event-triggered, not schedule-first (scheduled triggers are a planned extension)

---

## 3. Architecture Overview

### 3.1 High-Level Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────────────┐
│                           EXTERNAL EVENT SOURCES                         │
│                                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  ┌─────────────┐  │
│  │  Prometheus  │  │   GitHub     │  │ Uptime Kuma │  │  Generic    │  │
│  │ Alertmanager │  │  Webhooks    │  │  Webhooks   │  │  Webhooks   │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬──────┘  └──────┬──────┘  │
└─────────┼─────────────────┼─────────────────┼────────────────┼──────────┘
          │                 │                 │                │
          ▼                 ▼                 ▼                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         AEDA PLATFORM (FastAPI)                         │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │                     WEBHOOK INGESTION LAYER                      │   │
│  │   /sources/webhook/{prometheus,github,uptime-kuma,*}             │   │
│  │   Normalizers: source-specific payload → AEDAEvent               │   │
│  └──────────────────────────┬───────────────────────────────────────┘   │
│                             │ Save to DB + Push to Redis                 │
│                             ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    PostgreSQL (Events Table)                     │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                             │                                            │
│  ┌──────────────────────────▼──────────────────────────────────────┐    │
│  │              REDIS QUEUE (aeda:event_queue)                     │    │
│  │              BRPOP-based reliable delivery                      │    │
│  └──────────────────────────┬───────────────────────────────────────┘   │
│                             │ Worker pops                                │
│  ┌──────────────────────────▼──────────────────────────────────────┐    │
│  │                     EVENT PROCESSOR (Worker)                    │    │
│  │                                                                  │    │
│  │   ┌─────────────────────────────────────────────────────────┐   │    │
│  │   │                    RULE ENGINE                          │   │    │
│  │   │   Loads enabled rules from DB (30s TTL cache)           │   │    │
│  │   │   Matches source + evaluates condition expressions      │   │    │
│  │   │   Returns ordered list of matching rules (by priority)  │   │    │
│  │   └─────────────────────┬───────────────────────────────────┘   │    │
│  │                         │ For each matching rule                 │    │
│  │   ┌─────────────────────▼───────────────────────────────────┐   │    │
│  │   │                 ACTION EXECUTOR                         │   │    │
│  │   │   http  │  shell  │  slack  │  log  │  ansible  │ claude│   │    │
│  │   └─────────────────────┬───────────────────────────────────┘   │    │
│  └──────────────────────────┼───────────────────────────────────────┘   │
│                             │ Result + reasoning                         │
│  ┌──────────────────────────▼──────────────────────────────────────┐    │
│  │                  AUDIT LOG (PostgreSQL)                         │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │               CLAUDE AI AGENT (when action type = claude)        │   │
│  │                                                                  │   │
│  │  ┌────────────────────────────────────────────────────────────┐  │   │
│  │  │  Tool-use loop (max 8 iterations)                          │  │   │
│  │  │  Tools: search_knowledge │ query_ansible_templates         │  │   │
│  │  │         run_ansible      │ send_slack │ send_http          │  │   │
│  │  │         query_recent_events │ request_approval             │  │   │
│  │  └────────────────────────────────────────────────────────────┘  │   │
│  │                                                                  │   │
│  │  ┌──────────────────┐   ┌───────────────────────────────────┐   │   │
│  │  │  RAG KNOWLEDGE   │   │      HITL APPROVAL QUEUE          │   │   │
│  │  │  BASE (pgvector) │   │  (approvals table + UI widget)    │   │   │
│  │  └──────────────────┘   └───────────────────────────────────┘   │   │
│  └──────────────────────────────────────────────────────────────────┘   │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │                  REST API + OPERATOR UI                          │   │
│  │  /events  /rules  /sources  /audit  /knowledge  /approvals      │   │
│  └──────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
          │                          │
          ▼                          ▼
┌─────────────────┐       ┌──────────────────────┐
│  Ansible AWX /  │       │   Slack / External   │
│  AAP (REST API) │       │   HTTP Endpoints     │
└─────────────────┘       └──────────────────────┘
```

### 3.2 Architectural Principles

**Event-driven, not polling.** All automation is triggered by inbound events. AEDA never polls external systems for state changes (except Ansible job status when `wait: true`).

**Dual-mode processing.** A deterministic rule engine handles simple, well-understood scenarios at low cost and latency. The Claude AI agent handles ambiguous, complex, or SOP-guided scenarios at higher cost but with superior reasoning.

**Credentials never in Claude's context.** Tool defaults (AWX tokens, Slack webhook URLs, etc.) are injected by the server at dispatch time. Claude sees only tool names and semantic parameters — never secrets.

**Auditability by design.** Every event, every rule match, every action, and every Claude reasoning turn is persisted. The full agent conversation history is stored in `audit_entries.reasoning` as a structured JSON array.

**Non-destructive approval flow.** When `require_approval: true`, the agent calls `request_approval` instead of executing. The approval record stores the complete intended action; approval causes execution; denial creates a deny record. Nothing is lost, nothing is guessed.

---

## 4. Core Components

### 4.1 Webhook Ingestion Layer

The ingestion layer accepts events from external monitoring and CI/CD systems. Source-specific normalizers transform heterogeneous payloads into the canonical `AEDAEvent` model.

**Supported sources with native normalizers:**
- **Prometheus Alertmanager** — processes `alerts[]` array, maps severity labels, preserves generator URLs
- **GitHub** — handles push, pull_request, deployment, deployment_status, and workflow_run event types via `X-GitHub-Event` header
- **Uptime Kuma** — maps heartbeat status (0/1) to DOWN/UP, extracts severity from monitor tags
- **Generic webhook** — field heuristics extract title, severity, and event_type from any JSON payload

All normalized events are persisted to PostgreSQL before being pushed to Redis, ensuring no events are lost if the worker is temporarily unavailable.

### 4.2 Rule Engine

The rule engine evaluates normalized events against stored rules and returns an ordered list of matching rules. Rules are loaded from PostgreSQL with a 30-second TTL cache; any CRUD operation on rules immediately invalidates the cache via `processor.invalidate_rules()`.

**Rule structure:**
- `sources` — list of source names that trigger this rule, or `["*"]` for all sources
- `conditions` — list of Python expressions evaluated against the event context
- `actions` — ordered list of action configurations to execute on match
- `priority` — integer for ordering (lower value = higher priority)

**Condition evaluation context** exposes: `event`, `payload`, `labels`, `severity`, `source`, `event_type`, `title` — all derived from the `AEDAEvent` object.

### 4.3 Action Executor

The action executor is a dispatch table mapping action type strings to async handler functions:

| Action Type | Description |
|-------------|-------------|
| `http` | Outbound HTTP request with configurable method, headers, body |
| `shell` | Local shell command execution with timeout and output capture |
| `slack` | Slack Incoming Webhook message (supports per-action webhook URL) |
| `log` | Structured log at configurable level (for dry-run and debugging) |
| `ansible` | Launch AWX/AAP job template via v2 REST API with optional wait |
| `claude` | Start Claude AI agent tool-use loop |

All action configs support `$variable` and `${variable}` template substitution using event fields (id, title, source, event_type, severity, timestamp, payload fields, label fields).

### 4.4 Claude AI Agent

The Claude agent is a stateless async function (`run_agent`) that implements the Anthropic tool-use protocol. It accepts a system prompt, a user prompt (the alert description), and a set of tools. It runs an iteration loop, dispatching tool calls to the tool executor and feeding results back into the conversation until Claude signals `end_turn` or the iteration cap is reached.

**Key design decisions:**
- The agent is stateless; all context is in the message array for that invocation
- `tool_defaults` pattern keeps secrets out of Claude's context window
- The full message history (including tool calls and results) is returned for audit storage
- Works with both direct Anthropic API and Azure AI Foundry's Anthropic-compatible endpoint

### 4.5 RAG Knowledge Base

The knowledge base stores Standard Operating Procedure (SOP) documents with semantic embeddings. When an alert fires and `use_knowledge_base: true`, Claude calls `search_knowledge` as its first tool. The tool embeds the query using `BAAI/bge-small-en-v1.5` via fastembed, queries pgvector for cosine-similar documents, and returns the top-k SOPs including their `action_hints`.

`action_hints` is a structured JSON field that provides Claude with exact tool parameters (e.g., `{"ansible_template": "Restart Web Server", "slack_channel": "#incidents"}`), eliminating the need for Claude to guess parameter values.

### 4.6 Human-in-the-Loop Approval Queue

When a rule sets `require_approval: true`, the Claude agent is instructed to call `request_approval` instead of `run_ansible`. The tool stores the intended action (tool name, parameters, credentials, reasoning) in the `approvals` table with `status: pending`.

An operator reviews pending approvals in the UI and either approves or denies. On approval, the stored action is executed immediately via the same tool executor used by the agent. The result is stored in `approvals.result`.

This design preserves the full automation benefit (Claude does the analysis and selects the right template) while maintaining operator oversight for high-impact actions.

---

## 5. Integration Landscape

### 5.1 Inbound Integrations (Event Sources)

```
┌─────────────────────────────────────────────────────────────────┐
│                    INBOUND INTEGRATIONS                         │
│                                                                 │
│  Monitoring          CI/CD              Custom                  │
│  ──────────────      ──────────────     ──────────────          │
│  Prometheus          GitHub Actions     Any system with         │
│  Alertmanager        GitHub Push        HTTP webhook            │
│                      GitHub PRs         capability              │
│  Uptime Kuma         GitHub Deploy                             │
│  (heartbeat)         Workflow runs                             │
│                                                                 │
│  All ingest at: POST /sources/webhook/{source_name}            │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 Outbound Integrations (Action Targets)

```
┌─────────────────────────────────────────────────────────────────┐
│                    OUTBOUND INTEGRATIONS                        │
│                                                                 │
│  Automation          Notification       Generic                 │
│  ──────────────      ──────────────     ──────────────          │
│  Ansible AWX         Slack Incoming     Any REST API            │
│  Ansible AAP         Webhook            (HTTP action)           │
│  (v2 REST API)                                                  │
│                      Future:            Future:                 │
│  Future:             Microsoft Teams    Jira                    │
│  Terraform Cloud     PagerDuty          ServiceNow              │
│  Kubernetes API                         ITSM systems            │
└─────────────────────────────────────────────────────────────────┘
```

### 5.3 AI Provider Integration

AEDA uses the Anthropic Python SDK and supports two deployment modes:

| Mode | Configuration | Use Case |
|------|---------------|----------|
| Direct Anthropic | `ANTHROPIC_API_KEY=sk-ant-...` | Development, small teams |
| Azure AI Foundry | `ANTHROPIC_API_KEY` + `ANTHROPIC_BASE_URL` | Enterprise, data residency requirements |

The model is configurable globally (`ANTHROPIC_MODEL`) and can be overridden per rule action, allowing use of different model tiers for different alert criticalities.

---

## 6. Data Flow Diagrams

### 6.1 Standard Event Flow (Rule Action)

```
External System
     │
     │ POST /sources/webhook/prometheus
     ▼
Webhook Normalizer
     │ normalize_prometheus() → [AEDAEvent, ...]
     ▼
Event Repository           Redis Queue
     │ save_event()              │
     │ (PostgreSQL commit)       │ queue.push(event.dict)
     └───────────────────────────┘
                                 │
                                 │ BRPOP (EventQueue.pop)
                                 ▼
                        Event Processor Worker
                                 │
                                 │ find_matching_rules(rules, event)
                                 ▼
                          Rule Engine
                                 │ [matched_rules]
                                 ▼
                    For each rule → For each action:
                        Action Executor
                         ├── HTTP action → external endpoint
                         ├── Slack action → Slack webhook
                         ├── Ansible action → AWX REST API
                         └── Claude action → AI Agent loop
                                 │
                                 │ ActionResult(success, output, error, reasoning)
                                 ▼
                         Audit Repository
                                 │ save AuditEntry to PostgreSQL
                                 ▼
                         Update Event.processed_at
```

### 6.2 Claude Agent Flow (with RAG and HITL)

```
Event Processor
     │ action type = "claude", use_knowledge_base=true, require_approval=true
     ▼
_claude_action()
     │ Constructs system_prompt (with HITL instructions)
     │ Injects tool_defaults with _meta (rule_name, event_id, credentials)
     │ Allowed tools: [search_knowledge, request_approval, send_slack, ...]
     ▼
run_agent(system, user_prompt, event, tools, tool_defaults)
     │
     │ Iteration 1:
     │   Claude calls: search_knowledge(query="High CPU on web-01")
     │   ▼ execute_tool("search_knowledge", ...)
     │   ▼ embed_text(query) → BAAI/bge-small-en-v1.5 → 384-dim vector
     │   ▼ pgvector cosine_distance search → top-3 SOPs
     │   ▼ Returns SOP with action_hints: {ansible_template: "CPU Remediation"}
     │
     │ Iteration 2:
     │   Claude calls: request_approval(
     │     tool_name="run_ansible",
     │     tool_params={template_name: "CPU Remediation", limit: "web-01"},
     │     reason="SOP indicates running CPU Remediation playbook..."
     │   )
     │   ▼ execute_tool("request_approval", ...)
     │   ▼ Creates Approval record (status=pending) in PostgreSQL
     │   ▼ Returns: "Approval request submitted. Operator will review."
     │
     │ Iteration 3: Claude calls end_turn with summary
     ▼
AgentResult(success=True, output="Summary...", turns=[...conversation...])
     │
     ▼
ActionResult(success, output, reasoning=turns)
     │
     ▼
AuditEntry saved with full reasoning JSON

     ═════════════════ OPERATOR REVIEWS UI ═════════════════

     Operator sees pending approval in UI
     Operator clicks "Approve"
     │
     ▼
POST /approvals/{id}/approve
     │
     ▼
_execute_approved(approval)
     │ Reconstructs event, tool_defaults from stored record
     │ Calls execute_tool("run_ansible", tool_params, event, defaults)
     │
     ▼
AWX REST API: POST /api/v2/job_templates/{id}/launch/
     │
     ▼
Approval.status = "approved", result = "Job 123 launched"
```

### 6.3 Knowledge Base Ingestion Flow

```
Operator / Admin
     │
     │ POST /knowledge
     │ {title, content, tags, action_hints}
     ▼
Knowledge Router
     │
     │ embed_text(title + "\n" + content)
     ▼ BAAI/bge-small-en-v1.5 (fastembed, in-process)
     │ → 384-dimensional float vector
     ▼
knowledge_repo.save_doc(db, {..., embedding=vector})
     │
     ▼
PostgreSQL: knowledge_docs table
  - content stored as TEXT
  - embedding stored as pgvector Vector(384)
  - action_hints stored as JSONB
```

---

## 7. Technology Stack

### 7.1 Stack Decisions and Rationale

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| API Framework | FastAPI | 0.115 | Async-native, Pydantic validation, OpenAPI docs out of the box |
| ORM | SQLAlchemy | 2.0 async | Async session support, type-annotated mapped columns, Alembic integration |
| Database | PostgreSQL | 16 + pgvector | JSONB for flexible event payloads; pgvector extension for RAG semantic search in same DB |
| Queue | Redis | 7 | BRPOP provides reliable blocking dequeue; list semantics are simple and durable with AOF |
| Embedding Model | BAAI/bge-small-en-v1.5 | — | 384-dim, runs in-process via fastembed (no external API call for embeddings), excellent quality/cost |
| Embedding Runtime | fastembed | 0.4+ | ONNX runtime, CPU-friendly, no GPU required |
| Vector Search | pgvector | 0.3+ | Cosine distance operator built into PostgreSQL; avoids a separate vector DB service |
| AI Model | Claude (Anthropic) | claude-sonnet-4-6+ | Best-in-class tool use, instruction following for SRE scenarios |
| AI SDK | anthropic (Python) | 0.40+ | Official async SDK, handles tool_use stop_reason loop |
| HTTP Client | httpx | 0.27 | Async-native, used for AWX/AAP calls and outbound HTTP actions |
| Migrations | Alembic | 1.13 | Industry standard for SQLAlchemy schema migrations |
| Runtime | Python | 3.11 | asyncio stability, type hint improvements |
| Container | Docker + Compose | — | Single-command local deployment; production-ready for k8s migration |

### 7.2 Dependency Graph

```
FastAPI (ASGI/uvicorn)
  ├── SQLAlchemy 2.0 async → asyncpg → PostgreSQL
  ├── redis[asyncio] → Redis BRPOP queue
  ├── anthropic SDK → Anthropic API / Azure AI Foundry
  ├── fastembed → ONNX → BAAI/bge-small-en-v1.5 (local)
  ├── pgvector → pgvector PostgreSQL extension
  ├── httpx → AWX/AAP, Slack, outbound HTTP
  ├── pydantic v2 → request/response validation
  └── alembic → schema migrations
```

### 7.3 Why Not Alternatives

| Alternative Considered | Decision | Reason |
|------------------------|----------|--------|
| Celery + RabbitMQ | Rejected | Redis list + BRPOP sufficient; avoids Celery worker management complexity |
| Pinecone / Weaviate | Rejected | pgvector in existing PostgreSQL eliminates a separate managed service |
| OpenAI GPT-4 | Not used | Claude's tool use loop is more reliable for multi-step SRE workflows |
| Sentence Transformers (torch) | Rejected | fastembed/ONNX avoids PyTorch dependency; lighter container image |
| YAML-file rules | Superseded | Phase 1 started with YAML files; Phase 1 completed with PostgreSQL persistence |

---

## 8. Development Phases

### 8.1 Completed Phases

#### Phase 1: Core Platform

**Status:** Complete  
**Goal:** Minimal viable event-driven automation platform

- Webhook ingestion with source normalization (Prometheus, GitHub, Uptime Kuma, generic)
- Rule engine: YAML-backed rules with Python expression conditions, migrated to PostgreSQL
- Action types: HTTP, Shell, Slack, Log
- PostgreSQL persistence (events, rules, sources, audit_entries) via SQLAlchemy 2.0 async
- Redis queue (LPUSH/BRPOP) for decoupled async processing
- REST API: /events, /rules, /sources, /audit, /health
- Single-page operator UI (vanilla HTML/JS)
- Docker Compose deployment (FastAPI + PostgreSQL + Redis)
- Alembic migrations

#### Phase 2a: Ansible AWX/AAP Integration

**Status:** Complete  
**Goal:** Enable Ansible-based remediation as a first-class action type

- `ansible` action type: launches AWX/AAP job templates via v2 REST API
- Supports both OAuth2 Bearer token and HTTP Basic Auth
- Supports regular job templates and workflow job templates
- Optional `wait: true` with configurable polling interval and timeout
- Template discovery: `query_ansible_templates` lists available templates with search filtering

#### Phase 2b: Claude AI Agent

**Status:** Complete  
**Goal:** AI-driven intelligent remediation with multi-step tool use

- `claude` action type wrapping `run_agent` async loop
- Tool-use protocol: iterates until `end_turn` or `max_iterations` cap
- Available tools: `search_knowledge`, `query_ansible_templates`, `run_ansible`, `send_slack`, `send_http`, `query_recent_events`
- `tool_defaults` pattern: server injects credentials, Claude sees only semantic parameters
- Azure AI Foundry compatibility via `ANTHROPIC_BASE_URL`
- Full conversation history (turns) stored in `audit_entries.reasoning`
- Configurable `system_prompt`, `user_prompt`, `model`, `allowed_tools`, `max_iterations`

#### Phase 2c: RAG Knowledge Base

**Status:** Complete  
**Goal:** SOP-guided automation — Claude reads documented procedures before acting

- `knowledge_docs` table with content, tags, action_hints (JSONB), and pgvector embedding
- In-process embedding generation via fastembed (BAAI/bge-small-en-v1.5, 384 dimensions)
- Automatic re-embedding on document update (title or content changes)
- `search_knowledge` tool: embeds query, cosine distance search, returns SOPs + action_hints
- System prompt variant guides Claude to call `search_knowledge` first and use `action_hints` exactly
- REST API: /knowledge (CRUD)

#### Phase 2d: Human-in-the-Loop Approvals

**Status:** Complete  
**Goal:** Operator oversight for high-risk automated actions

- `approvals` table: stores pending/approved/denied actions with full tool params and credentials
- `require_approval: true` rule flag rewrites Claude's allowed tools to use `request_approval` instead of `run_ansible`
- `request_approval` tool stores the intended action and returns a holding message to Claude
- REST API: /approvals (list, approve, deny, pending count)
- Approval execution: `/approvals/{id}/approve` triggers immediate action via tool executor
- UI widget shows pending count badge; approval panel shows reason, parameters, and outcome

### 8.2 Planned Phases

#### Phase 3a: Event Correlation and Deduplication

**Status:** Planned — Q3 2026  
**Goal:** Suppress duplicate alerts and group related events to reduce noise

**Scope:**
- Fingerprint-based deduplication: hash of (source, event_type, key labels) to suppress repeat alerts within a configurable window
- Correlation groups: link related events (e.g., all alerts from same host in same 5-minute window) into a correlation group
- Resolved event handling: when a monitoring system sends a "resolved" alert, mark earlier correlated events as closed
- New table: `event_correlations` (group_id, event_ids[], fingerprint, first_seen, last_seen, count, status)
- Rule conditions can filter on `event.correlation_count` and `event.is_duplicate`

#### Phase 3b: Scheduled and Time-Triggered Rules

**Status:** Planned — Q3 2026  
**Goal:** Enable maintenance windows and time-based automation

**Scope:**
- `schedule` action type and cron-expression rule trigger
- Maintenance window support: rules can be configured to suppress actions during defined windows
- New APScheduler or similar in-process scheduler alongside the event processor
- New table: `scheduled_jobs` (cron_expr, rule_id, last_run, next_run, enabled)
- UI: schedule builder for cron expressions

#### Phase 3c: Auto-Remediation Learning

**Status:** Planned — Q4 2026  
**Goal:** Improve automation quality by learning from outcomes

**Scope:**
- Track remediation outcomes: did the alert clear after the action? (via follow-up resolved event)
- Success/failure rate per (rule, action_type, ansible_template) triple
- Suggest rule improvements: surface rules with high failure rates in UI
- New table: `remediation_outcomes` (rule_id, template_name, outcome, resolution_time_minutes)
- Claude context enrichment: include recent success rates in agent prompts

#### Phase 3d: Multi-Agent Workflows

**Status:** Planned — Q4 2026  
**Goal:** Decompose complex remediations across specialized agents

**Scope:**
- Orchestrator agent: analyzes the alert, determines sub-tasks, delegates to specialist agents (network agent, database agent, application agent)
- Sub-agent results fed back to orchestrator for synthesis
- New tool: `delegate_to_agent(agent_type, task_description, context)`
- Agent registry: defines specialist agents with their system prompts and allowed tools
- New table: `agent_workflows` (orchestrator_audit_id, sub_tasks[], statuses[])

#### Phase 4a: RBAC and Multi-Tenancy

**Status:** Planned — Q1 2027  
**Goal:** Support multiple teams with isolated namespaces

**Scope:**
- `organizations` table: top-level tenant isolation
- `teams` table: team membership with role assignments
- Role levels: `viewer`, `operator`, `engineer`, `admin`
- Namespace isolation: rules, events, knowledge docs scoped to organization
- JWT-based authentication with team membership claims
- New tables: `organizations`, `teams`, `team_memberships`, `api_keys`

#### Phase 4b: Analytics Dashboard

**Status:** Planned — Q1 2027  
**Goal:** Business-level visibility into automation value

**Scope:**
- MTTR calculation: time from event to processed_at across severity levels
- Automation coverage: % of alerts that triggered a rule vs. fell through with no match
- Cost savings estimate: hours saved based on automated actions vs. manual median resolution time
- Alert trend analysis: event volume by source/severity over configurable time windows
- Materialized views or time-series aggregation for efficient queries
- New API routes: /analytics/mttr, /analytics/coverage, /analytics/trends

#### Phase 4c: Integration Hub

**Status:** Planned — Q2 2027  
**Goal:** Bidirectional integrations with ITSM and collaboration tools

**Scope:**
- Jira ticket creation: new action type `jira` (create/update issues, add comments)
- ServiceNow ITSM: create incidents, update CI records
- PagerDuty: trigger/resolve incidents, add notes
- Microsoft Teams: send adaptive cards, create meeting links
- Bidirectional: webhook receivers for status updates from these systems back into AEDA

#### Phase 5a: Predictive Alerting

**Status:** Planned — Q3 2027  
**Goal:** Act before alerts fire based on historical patterns

**Scope:**
- ML models trained on historical metric trends: ARIMA, Prophet, or simple threshold-based anomaly detection
- Metrics ingestion endpoint (separate from events) for raw time-series data
- Prediction engine runs on a schedule, generates synthetic events when thresholds crossed
- Model registry: track model versions, accuracy metrics, retrain schedules

#### Phase 5b: Natural Language Rule Creation

**Status:** Planned — Q3 2027  
**Goal:** Non-engineers can create automation rules in plain English

**Scope:**
- Operator describes rule: "When Prometheus fires a critical CPU alert for any web server, run the CPU Remediation playbook"
- Claude generates the rule JSON (sources, conditions, actions) from the description
- Operator reviews generated rule in a diff-style UI before saving
- New API endpoint: `POST /rules/generate` with natural language input, returns draft rule

#### Phase 5c: Self-Healing Infrastructure

**Status:** Planned — Q4 2027  
**Goal:** Proactive remediation before alerts fire

**Scope:**
- Combines predictive alerting (5a) with automated remediation
- When prediction confidence exceeds threshold, generate a pre-emptive remediation event
- "Calm mode": proactive actions are logged but not executed until operator enables self-healing for specific resource types
- Audit trail clearly distinguishes reactive remediations from proactive self-healing

---

## 9. Non-Functional Requirements

### 9.1 Performance

| Metric | Target | Current State |
|--------|--------|---------------|
| Webhook ingestion latency | < 100ms p99 | Met — FastAPI async, single DB write |
| Event processing latency (non-Claude rules) | < 500ms p99 | Met — Redis BRPOP, direct action dispatch |
| Claude agent latency | < 30s typical | 5–15s typical (3–4 tool iterations) |
| API response time (reads) | < 50ms p95 | Met — indexed queries |
| Rule cache refresh | Every 30s or on change | Met — TTL cache with invalidation |
| Concurrent webhook ingestion | > 100 req/s (single instance) | FastAPI async, not load-tested |

### 9.2 Availability

| Requirement | Approach |
|-------------|----------|
| API availability | FastAPI with uvicorn; `restart: unless-stopped` in Docker Compose |
| Queue durability | Redis with AOF persistence; events saved to PostgreSQL before queueing |
| No-loss event processing | Event persisted to DB before Redis push; BRPOP acknowledges after processing |
| Database availability | Single PostgreSQL instance (Phase 4a adds HA replication option) |
| Graceful shutdown | lifespan context manager stops processor cleanly on SIGTERM |

### 9.3 Security

| Concern | Current Mitigation |
|---------|-------------------|
| Credential exposure to Claude | `tool_defaults` are server-side only; Claude's context contains zero secrets |
| Rule condition injection | Python `eval` is restricted to `_SAFE_BUILTINS`; no `__builtins__`, no import |
| API authentication | None in v1 (single-tenant); JWT RBAC planned in Phase 4a |
| Approval record credentials | Only the target tool's defaults are stored; `_meta` credentials are not persisted |
| Webhook source verification | No signature validation in v1; HMAC verification planned per source in Phase 3 |
| TLS | Handled at reverse proxy (nginx/traefik); internal Docker network is private |
| CORS | Wildcard `*` in v1 (single-tenant); scoped origins in Phase 4a |

### 9.4 Scalability

AEDA's current single-process architecture is intentional for simplicity. The Redis queue is the natural scale-out point:

- **Horizontal API scaling**: Multiple FastAPI instances can receive webhooks (all write to same DB + Redis)
- **Horizontal worker scaling**: Multiple EventProcessor instances can pop from the same Redis queue (no coordination needed for simple rules; Claude agent actions are idempotent by design)
- **Database scaling**: pgvector cosine search scales to millions of knowledge docs; connection pooling via asyncpg
- **Redis scaling**: For very high throughput, Redis Cluster or Redis Sentinel can replace standalone Redis

### 9.5 Observability

| Mechanism | Details |
|-----------|---------|
| Structured logging | Python logging with level controlled by `LOG_LEVEL` env var |
| Health endpoint | `GET /health` returns DB and Redis status + queue depth |
| Audit log | Every event, rule match, and action outcome is queryable via `/audit` |
| Agent reasoning | Full Claude conversation stored in `audit_entries.reasoning` |
| Approval trail | Every HITL decision stored with timestamp and result in `approvals` |

---

## 10. Deployment Architecture

### 10.1 Current: Docker Compose (Single Host)

```
┌─────────────────────────────────────────────────────────┐
│                       Docker Host                       │
│                                                         │
│  ┌──────────────────────────────────────────────────┐   │
│  │               AEDA API Container                │   │
│  │   FastAPI + uvicorn (port 8000)                 │   │
│  │   EventProcessor worker (async task)            │   │
│  │   fastembed ONNX model (in-process)             │   │
│  └──────────────────────────────────────────────────┘   │
│                    │           │                        │
│  ┌─────────────────▼──┐  ┌────▼─────────────────────┐  │
│  │   PostgreSQL 16    │  │      Redis 7              │  │
│  │   + pgvector ext   │  │  + AOF persistence        │  │
│  │   (port 5432)      │  │  (port 6379)              │  │
│  └────────────────────┘  └──────────────────────────┘   │
│                                                         │
│  Optional:                                              │
│  ┌────────────────────┐                                 │
│  │   Uptime Kuma      │  (monitoring of external       │
│  │   (port 3001)      │   services, feeds back         │
│  └────────────────────┘   into AEDA via webhook)       │
└─────────────────────────────────────────────────────────┘
```

**Configuration:** `.env` file with `DATABASE_URL`, `REDIS_URL`, `ANTHROPIC_API_KEY`, `SLACK_WEBHOOK_URL`  
**Startup:** `docker compose up -d`  
**Migrations:** Run automatically on startup when `RUN_MIGRATIONS=true`

### 10.2 Target: Kubernetes (Phase 4+)

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Kubernetes Cluster                         │
│                                                                     │
│  ┌────────────────────────────────────────────────────────────┐     │
│  │                    AEDA Namespace                          │     │
│  │                                                            │     │
│  │  Ingress (nginx/traefik) ──► AEDA API (Deployment, 3 pods) │     │
│  │                              HPA: scale on CPU / RPS       │     │
│  │                                                            │     │
│  │  AEDA Worker (Deployment, 1-N pods) ──► Redis              │     │
│  │  (scales independently from API)                           │     │
│  │                                                            │     │
│  │  Secrets: ANTHROPIC_API_KEY, DB creds (Sealed Secrets)     │     │
│  └────────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Managed Services (outside cluster):                                │
│  ┌─────────────────┐  ┌──────────────────┐                         │
│  │  Cloud PostgreSQL│  │  Cloud Redis     │                         │
│  │  (RDS/CloudSQL)  │  │  (ElastiCache/   │                         │
│  │  + pgvector      │  │  MemoryStore)    │                         │
│  └─────────────────┘  └──────────────────┘                         │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 11. Roadmap and Timeline

```
2026 Q2 (Now)    ████████████████████████  Phases 1–2d COMPLETE
                  Core platform, AI agent, RAG, HITL approvals

2026 Q3          ░░░░░░░░░░░░░░░░░░░░░░░░  Phase 3a + 3b
                  Event deduplication/correlation, scheduled rules

2026 Q4          ░░░░░░░░░░░░░░░░░░░░░░░░  Phase 3c + 3d
                  Remediation learning, multi-agent workflows

2027 Q1          ░░░░░░░░░░░░░░░░░░░░░░░░  Phase 4a + 4b
                  RBAC/multi-tenancy, analytics dashboard

2027 Q2          ░░░░░░░░░░░░░░░░░░░░░░░░  Phase 4c
                  Integration hub (Jira, ServiceNow, PagerDuty, Teams)

2027 Q3          ░░░░░░░░░░░░░░░░░░░░░░░░  Phase 5a + 5b
                  Predictive alerting, natural language rule creation

2027 Q4          ░░░░░░░░░░░░░░░░░░░░░░░░  Phase 5c
                  Self-healing infrastructure
```

### Summary Table

| Phase | Name | Status | Target Quarter |
|-------|------|--------|----------------|
| 1 | Core Platform | Complete | — |
| 2a | Ansible AWX/AAP Integration | Complete | — |
| 2b | Claude AI Agent | Complete | — |
| 2c | RAG Knowledge Base | Complete | — |
| 2d | Human-in-the-Loop Approvals | Complete | — |
| 3a | Event Correlation & Deduplication | Planned | Q3 2026 |
| 3b | Scheduled/Time-Triggered Rules | Planned | Q3 2026 |
| 3c | Auto-Remediation Learning | Planned | Q4 2026 |
| 3d | Multi-Agent Workflows | Planned | Q4 2026 |
| 4a | RBAC + Multi-Tenancy | Planned | Q1 2027 |
| 4b | Analytics Dashboard | Planned | Q1 2027 |
| 4c | Integration Hub | Planned | Q2 2027 |
| 5a | Predictive Alerting | Planned | Q3 2027 |
| 5b | Natural Language Rule Creation | Planned | Q3 2027 |
| 5c | Self-Healing Infrastructure | Planned | Q4 2027 |

---

*Document maintained by the AEDA Engineering Team. Last updated: 2026-05-25.*
