from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import httpx

from ..action_executor import _ansible_action, _http_action, _slack_action
from ..models import AEDAEvent

logger = logging.getLogger(__name__)


async def execute_tool(
    tool_name: str,
    tool_input: Dict[str, Any],
    event: AEDAEvent,
    defaults: Optional[Dict[str, Dict[str, Any]]] = None,
) -> str:
    """Execute a named tool and return a plain-text result for Claude."""
    _defaults = defaults or {}

    # query_ansible_templates shares AWX connection details with run_ansible.
    # Fall back to run_ansible defaults so users don't have to duplicate credentials.
    if tool_name == "query_ansible_templates":
        base = {**_defaults.get("run_ansible", {}), **_defaults.get("query_ansible_templates", {})}
    else:
        base = _defaults.get(tool_name, {})

    merged: Dict[str, Any] = {**base, **tool_input}

    if tool_name == "request_approval":
        return await _request_approval(merged)
    elif tool_name == "search_knowledge":
        return await _search_knowledge(merged)
    elif tool_name == "query_ansible_templates":
        return await _query_ansible_templates(merged)
    elif tool_name == "run_ansible":
        merged = await _resolve_ansible_template(merged)
        result = await _ansible_action(merged, event)
    elif tool_name == "send_slack":
        result = await _slack_action(merged, event)
    elif tool_name == "send_http":
        result = await _http_action(merged, event)
    elif tool_name == "query_recent_events":
        return await _query_recent_events(merged)
    else:
        return f"Unknown tool: '{tool_name}'"

    if result.success:
        return result.output or "Action completed successfully."
    return f"Action failed: {result.error}"


async def _resolve_ansible_template(params: Dict[str, Any]) -> Dict[str, Any]:
    """If template_name is given instead of template_id, look it up via AWX API."""
    if params.get("template_id") or not params.get("template_name"):
        return params

    name = params["template_name"]
    base_url = (params.get("url") or "").rstrip("/")
    token = params.get("token", "")
    username = params.get("username", "")
    password = params.get("password", "")
    verify_ssl = bool(params.get("verify_ssl", True))

    if not base_url:
        return {**params, "error": "template_name given but AWX url not configured in tool_defaults"}

    headers: Dict[str, str] = {}
    auth = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    elif username and password:
        auth = (username, password)

    search_url = f"{base_url}/api/v2/job_templates/"
    async with httpx.AsyncClient(verify=verify_ssl, timeout=15) as client:
        resp = await client.get(
            search_url,
            params={"name": name},
            headers=headers,
            auth=auth,
        )
        resp.raise_for_status()
        results = resp.json().get("results", [])

    if not results:
        raise ValueError(f"No AWX job template found with name '{name}'")
    if len(results) > 1:
        names = ", ".join(r["name"] for r in results)
        raise ValueError(f"Multiple templates match '{name}': {names} — use template_id instead")

    resolved_id = results[0]["id"]
    logger.info("Resolved template_name '%s' → template_id %s", name, resolved_id)
    return {**params, "template_id": resolved_id}


async def _query_ansible_templates(params: Dict[str, Any]) -> str:
    """List AWX job templates, optionally filtered by a search term."""
    base_url = (params.get("url") or "").rstrip("/")
    token = params.get("token", "")
    username = params.get("username", "")
    password = params.get("password", "")
    verify_ssl = bool(params.get("verify_ssl", True))
    search = params.get("search", "")

    if not base_url:
        return "Cannot query templates: AWX url not configured in tool_defaults for run_ansible."

    headers: Dict[str, str] = {}
    auth = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    elif username and password:
        auth = (username, password)

    query_params: Dict[str, Any] = {"page_size": 50, "order_by": "name"}
    if search:
        query_params["search"] = search

    async with httpx.AsyncClient(verify=verify_ssl, timeout=15) as client:
        resp = await client.get(
            f"{base_url}/api/v2/job_templates/",
            params=query_params,
            headers=headers,
            auth=auth,
        )
        resp.raise_for_status()
        results = resp.json().get("results", [])

    if not results:
        return f"No job templates found{' matching ' + repr(search) if search else ''}."

    lines = [
        f"- ID={t['id']}  name={t['name']!r}"
        + (f"  playbook={t.get('playbook', '')!r}" if t.get("playbook") else "")
        + (f"  — {t['description']}" if t.get("description") else "")
        for t in results
    ]
    header = f"Found {len(results)} job template(s):\n"
    return header + "\n".join(lines)


async def _query_recent_events(params: Dict[str, Any]) -> str:
    from sqlalchemy import func, select

    from ..db.orm import Event as EventORM
    from ..db.session import AsyncSessionLocal

    limit = min(int(params.get("limit", 10)), 50)
    source = params.get("source") or ""
    event_type = params.get("event_type") or ""
    severity = params.get("severity") or ""

    async with AsyncSessionLocal() as db:
        # Build filtered query
        q = select(EventORM).order_by(EventORM.timestamp.desc()).limit(limit)
        if source:
            q = q.where(EventORM.source == source)
        if event_type:
            q = q.where(EventORM.event_type == event_type)
        if severity:
            q = q.where(EventORM.severity == severity)

        rows = (await db.execute(q)).scalars().all()

        # If filters produced nothing, fall back to unfiltered so Claude still gets context
        filters_applied = bool(source or event_type or severity)
        fallback = False
        if not rows and filters_applied:
            q_all = select(EventORM).order_by(EventORM.timestamp.desc()).limit(limit)
            rows = (await db.execute(q_all)).scalars().all()
            fallback = True

        total = (await db.execute(select(func.count()).select_from(EventORM))).scalar() or 0

    filter_desc = ", ".join(
        f"{k}={v!r}" for k, v in [("source", source), ("event_type", event_type), ("severity", severity)] if v
    )

    if not rows:
        return f"No events found in the database at all (total={total}). Filters tried: {filter_desc or 'none'}."

    lines = [
        f"- [{e.severity.upper()}] {e.title}  "
        f"(source={e.source}, type={e.event_type}, at={e.timestamp.isoformat()})"
        for e in rows
    ]
    header_parts = [f"Found {len(rows)} event(s) (total in DB: {total})"]
    if fallback:
        header_parts.append(f"NOTE: no results for filters [{filter_desc}] — showing unfiltered results instead")
    elif filter_desc:
        header_parts.append(f"filters: {filter_desc}")
    return "\n".join(header_parts) + "\n" + "\n".join(lines)


async def _search_knowledge(params: Dict[str, Any]) -> str:
    """Semantic search over the SOP knowledge base using pgvector."""
    from ..db.orm import KnowledgeDoc as KnowledgeDocORM
    from ..db.session import AsyncSessionLocal
    from ..embeddings import embed_text
    from ..repositories.knowledge_repo import search_similar

    query = (params.get("query") or "").strip()
    if not query:
        return "search_knowledge requires a 'query' parameter."

    limit = min(int(params.get("limit", 3)), 10)

    try:
        query_embedding = embed_text(query)
    except Exception as exc:
        return f"Embedding error: {exc}"

    async with AsyncSessionLocal() as db:
        # Check if any docs exist at all
        from sqlalchemy import func, select
        total = (await db.execute(select(func.count()).select_from(KnowledgeDocORM))).scalar() or 0
        if total == 0:
            return "The knowledge base is empty. Add SOPs via the Knowledge Base UI to enable SOP-guided automation."

        results = await search_similar(db, query_embedding, limit=limit)

    if not results:
        return "No SOPs found with embeddings. Try re-saving existing documents to generate embeddings."

    parts = [f"Found {len(results)} relevant SOP(s) for: {query!r}\n"]
    for i, (doc, dist) in enumerate(results, 1):
        similarity_pct = round((1 - dist) * 100, 1)
        tags_str = ", ".join(doc.tags) if doc.tags else "none"
        parts.append(f"[{i}] {doc.title}  (relevance: {similarity_pct}%)")
        parts.append(f"    Tags: {tags_str}")
        parts.append(f"    Procedure:\n{doc.content}")
        if doc.action_hints:
            hints_lines = "\n".join(f"      {k}: {v!r}" for k, v in doc.action_hints.items())
            parts.append(f"    Action hints (USE THESE for tool calls):\n{hints_lines}")
        parts.append("")

    return "\n".join(parts)


async def _request_approval(params: Dict[str, Any]) -> str:
    """Store a pending approval record and return a holding message to Claude."""
    import uuid as _uuid
    from ..db.orm import Approval as ApprovalORM
    from ..db.session import AsyncSessionLocal

    tool_name   = params.get("tool_name", "")
    tool_params = params.get("tool_params") or {}
    reason      = params.get("reason", "")

    # _meta is injected by _claude_action so credentials survive into the approval record
    meta         = params.get("_meta") or {}
    rule_name    = meta.get("rule_name", "unknown")
    all_defaults = meta.get("all_defaults") or {}
    event_id     = meta.get("event_id", "")
    event_title  = meta.get("event_title", "")

    # Store only the defaults for the target tool (keeps credentials minimal)
    target_defaults = all_defaults.get(tool_name, {})

    async with AsyncSessionLocal() as db:
        approval = ApprovalORM(
            id=_uuid.uuid4(),
            event_id=event_id,
            event_title=event_title,
            rule_name=rule_name,
            tool_name=tool_name,
            tool_params=tool_params,
            tool_defaults=target_defaults,
            reason=reason,
            status="pending",
        )
        db.add(approval)
        await db.commit()

    logger.info(
        "Approval request created: tool=%s rule=%s event=%s",
        tool_name, rule_name, event_id,
    )
    return (
        f"Approval request submitted for '{tool_name}'. "
        f"Reason: {reason}. "
        f"An operator will review this in the AEDA Approvals tab. "
        f"Do not attempt to call {tool_name} directly."
    )
