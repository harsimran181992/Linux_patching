from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..models import AEDAEvent
from .executor import execute_tool
from .tools import get_tool_schemas

logger = logging.getLogger(__name__)


@dataclass
class AgentResult:
    success: bool
    output: str = ""
    error: str = ""
    turns: List[Dict[str, Any]] = field(default_factory=list)


def _serialize_content(content: list) -> List[Dict[str, Any]]:
    """Convert SDK content blocks to plain dicts for JSON storage."""
    out = []
    for block in content:
        if hasattr(block, "model_dump"):
            out.append(block.model_dump())
        elif isinstance(block, dict):
            out.append(block)
    return out


async def run_agent(
    system_prompt: str,
    user_prompt: str,
    event: AEDAEvent,
    model: str = "claude-opus-4-7",
    allowed_tools: Optional[List[str]] = None,
    tool_defaults: Optional[Dict[str, Dict[str, Any]]] = None,
    max_iterations: int = 8,
    max_tokens: int = 4096,
) -> AgentResult:
    """
    Run the Claude agentic loop using the Anthropic SDK.

    Works with both the direct Anthropic API and Azure AI Foundry's
    Anthropic-compatible endpoint — configure via env vars:

      Direct Anthropic:
        ANTHROPIC_API_KEY=sk-ant-...

      Azure AI Foundry (Anthropic-compatible endpoint):
        ANTHROPIC_API_KEY=<azure-api-key>
        ANTHROPIC_BASE_URL=https://<resource>.services.ai.azure.com/anthropic
        ANTHROPIC_MODEL=claude-sonnet-4-6
    """
    import anthropic
    from config import settings

    if not settings.ANTHROPIC_API_KEY:
        return AgentResult(success=False, error="ANTHROPIC_API_KEY is not configured")

    client_kwargs: Dict[str, Any] = {"api_key": settings.ANTHROPIC_API_KEY}
    if settings.ANTHROPIC_BASE_URL:
        client_kwargs["base_url"] = settings.ANTHROPIC_BASE_URL
        logger.info("Using Azure AI Foundry endpoint: %s", settings.ANTHROPIC_BASE_URL)

    tool_schemas = get_tool_schemas(allowed_tools or [])

    client = anthropic.AsyncAnthropic(**client_kwargs)

    # messages is the live conversation sent to the API each iteration.
    # turns is a serialisable copy kept for the audit log.
    messages: List[Dict[str, Any]] = [{"role": "user", "content": user_prompt}]
    turns: List[Dict[str, Any]] = [{"role": "user", "content": user_prompt}]

    for iteration in range(max_iterations):
        logger.debug("Agent iteration %d/%d [event %s]", iteration + 1, max_iterations, event.id)

        api_kwargs: Dict[str, Any] = dict(
            model=model,
            max_tokens=max_tokens,
            system=system_prompt,
            messages=messages,
        )
        if tool_schemas:
            api_kwargs["tools"] = tool_schemas

        response = await client.messages.create(**api_kwargs)

        turns.append({
            "role": "assistant",
            "stop_reason": response.stop_reason,
            "content": _serialize_content(response.content),
        })

        # ── End of conversation ────────────────────────────────────────────────
        if response.stop_reason == "end_turn":
            final_text = next(
                (b.text for b in response.content if hasattr(b, "text")), ""
            )
            logger.info("Agent done in %d iteration(s) [event %s]", iteration + 1, event.id)
            return AgentResult(success=True, output=final_text, turns=turns)

        # ── Tool use ──────────────────────────────────────────────────────────
        if response.stop_reason != "tool_use":
            return AgentResult(
                success=False,
                error=f"Unexpected stop_reason: '{response.stop_reason}'",
                turns=turns,
            )

        messages.append({"role": "assistant", "content": response.content})

        tool_results = []
        for block in response.content:
            if not hasattr(block, "type") or block.type != "tool_use":
                continue

            logger.info("Tool call '%s' input=%s [event %s]", block.name, block.input, event.id)
            result_str = await execute_tool(block.name, block.input, event, tool_defaults)
            logger.info("Tool '%s' → %s", block.name, result_str[:300])

            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": result_str,
            })
            turns.append({
                "role": "tool_result",
                "tool_use_id": block.id,
                "name": block.name,
                "input": block.input,
                "result": result_str,
            })

        messages.append({"role": "user", "content": tool_results})

    return AgentResult(
        success=False,
        error=f"Agent reached max_iterations ({max_iterations}) without a final response",
        turns=turns,
    )
