from __future__ import annotations

from typing import Any, Dict, List

TOOL_SCHEMAS: Dict[str, Dict[str, Any]] = {
    "request_approval": {
        "name": "request_approval",
        "description": (
            "Request human approval before executing a tool. "
            "Use this INSTEAD of run_ansible when human approval is required. "
            "An operator will review the request in the AEDA UI and approve or deny it. "
            "Do NOT call run_ansible directly when this tool is available."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "tool_name": {
                    "type": "string",
                    "description": "The tool to run after approval — must be 'run_ansible'",
                },
                "tool_params": {
                    "type": "object",
                    "description": "The exact parameters to pass to the tool when approved (e.g. template_name, extra_vars, limit)",
                },
                "reason": {
                    "type": "string",
                    "description": "Clear explanation of why this action is needed, what it will do, and what the expected outcome is",
                },
            },
            "required": ["tool_name", "tool_params", "reason"],
        },
    },
    "search_knowledge": {
        "name": "search_knowledge",
        "description": (
            "Search the SOP knowledge base for procedures relevant to this alert. "
            "ALWAYS call this first before taking any action. "
            "Returns matching documents with action_hints (ansible_template, slack_channel, "
            "http_url, etc.) that you MUST use when calling other tools — "
            "do not guess tool parameters when the SOP provides them."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Alert description or problem summary to search for. Include the alert name, severity, and key symptoms.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of SOPs to return (default 3)",
                    "default": 3,
                },
            },
            "required": ["query"],
        },
    },
    "query_ansible_templates": {
        "name": "query_ansible_templates",
        "description": (
            "List available Ansible AWX / AAP job templates. "
            "Call this first to discover which playbooks exist and find the right "
            "template_id or template_name to pass to run_ansible. "
            "Optionally filter by a search term."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "search": {
                    "type": "string",
                    "description": "Optional keyword to filter templates by name or description",
                },
            },
        },
    },
    "run_ansible": {
        "name": "run_ansible",
        "description": (
            "Launch an Ansible AWX / AAP job template via the REST API. "
            "IMPORTANT: Always call query_ansible_templates first to get the real template names "
            "from AWX — do NOT guess or invent a template_name. "
            "template_name must be an exact AWX job template name returned by query_ansible_templates, "
            "NOT the name of any tool. "
            "You may identify the template by template_id (numeric) OR template_name (string)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "template_id": {
                    "type": "integer",
                    "description": "Numeric AWX job template ID returned by query_ansible_templates (use this OR template_name)",
                },
                "template_name": {
                    "type": "string",
                    "description": "Exact AWX job template name returned by query_ansible_templates (use this OR template_id). Must be a real template name from AWX, not a tool name.",
                },
                "extra_vars": {
                    "type": "object",
                    "description": "Extra variables to pass to the playbook",
                },
                "limit": {
                    "type": "string",
                    "description": "Inventory host-pattern limit (e.g. 'web-01')",
                },
                "wait": {
                    "type": "boolean",
                    "description": "Whether to wait for the job to finish before returning",
                    "default": False,
                },
            },
        },
    },
    "send_slack": {
        "name": "send_slack",
        "description": (
            "Post a message to a Slack channel. "
            "Use for notifications, incident updates, and status summaries."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "Message text to post",
                },
                "channel": {
                    "type": "string",
                    "description": "Target Slack channel (optional, uses webhook default if omitted)",
                },
            },
            "required": ["message"],
        },
    },
    "send_http": {
        "name": "send_http",
        "description": (
            "Make an outbound HTTP request to any URL. "
            "Use to call external REST APIs, webhooks, or management endpoints."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "Target URL",
                },
                "method": {
                    "type": "string",
                    "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                    "default": "POST",
                    "description": "HTTP method",
                },
                "body": {
                    "type": "object",
                    "description": "JSON request body",
                },
                "headers": {
                    "type": "object",
                    "description": "Additional HTTP headers as key/value strings",
                },
            },
            "required": ["url"],
        },
    },
    "query_recent_events": {
        "name": "query_recent_events",
        "description": (
            "Query recent AEDA events for situational context. "
            "Use this before acting to check if similar alerts have fired recently."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "description": "Filter by event source name",
                },
                "event_type": {
                    "type": "string",
                    "description": "Filter by event type",
                },
                "severity": {
                    "type": "string",
                    "description": "Filter by severity (info / warning / critical)",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of events to return (default 10)",
                    "default": 10,
                },
            },
        },
    },
}


def get_tool_schemas(allowed_tools: List[str]) -> List[Dict[str, Any]]:
    """Return tool schemas, filtered to allowed_tools (all if list is empty)."""
    if not allowed_tools:
        return list(TOOL_SCHEMAS.values())
    return [TOOL_SCHEMAS[name] for name in allowed_tools if name in TOOL_SCHEMAS]
