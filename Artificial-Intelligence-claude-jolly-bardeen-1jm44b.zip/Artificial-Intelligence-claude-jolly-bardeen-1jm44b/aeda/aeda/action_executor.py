from __future__ import annotations

import asyncio
import json as _json
import logging
import os
from string import Template
from typing import Any, Dict

import httpx

from .models import AEDAEvent, ActionResult

logger = logging.getLogger(__name__)


def _render(value: Any, event: AEDAEvent) -> Any:
    """Render $variable / ${variable} placeholders using event fields."""
    if isinstance(value, str):
        ctx = {
            "event_id": event.id,
            "event_title": event.title,
            "event_source": event.source,
            "event_type": event.event_type,
            "event_severity": event.severity,
            "event_timestamp": str(event.timestamp),
            "payload_raw": _json.dumps(event.payload),
            "labels_raw": _json.dumps(event.labels),
            **{f"payload_{k}": str(v) for k, v in event.payload.items()},
            **{f"label_{k}": v for k, v in event.labels.items()},
        }
        return Template(value).safe_substitute(ctx)
    if isinstance(value, dict):
        return {k: _render(v, event) for k, v in value.items()}
    if isinstance(value, list):
        return [_render(v, event) for v in value]
    return value


async def execute_action(action_config: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    action_type = action_config.get("type", "").lower()
    params = {k: _render(v, event) for k, v in action_config.items() if k != "type"}

    dispatch = {
        "http": _http_action,
        "shell": _shell_action,
        "slack": _slack_action,
        "log": _log_action,
        "ansible": _ansible_action,
        "claude": _claude_action,
    }

    handler = dispatch.get(action_type)
    if handler is None:
        return ActionResult(success=False, error=f"Unknown action type: '{action_type}'")

    try:
        return await handler(params, event)
    except Exception as exc:
        logger.exception("Unhandled error in action '%s'", action_type)
        return ActionResult(success=False, error=str(exc))


async def _http_action(params: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    url = params.get("url")
    if not url:
        return ActionResult(success=False, error="http action requires 'url'")

    method = params.get("method", "POST").upper()
    headers = params.get("headers", {})
    body = params.get("body")
    timeout = int(params.get("timeout", 30))

    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.request(
            method=method,
            url=url,
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return ActionResult(
            success=True,
            output=f"HTTP {response.status_code}: {response.text[:300]}",
        )


async def _shell_action(params: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    command = params.get("command")
    if not command:
        return ActionResult(success=False, error="shell action requires 'command'")

    timeout = int(params.get("timeout", 60))
    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return ActionResult(success=False, error=f"Command timed out after {timeout}s")

    if proc.returncode == 0:
        return ActionResult(success=True, output=stdout.decode().strip()[:500])
    return ActionResult(success=False, error=stderr.decode().strip()[:500])


async def _slack_action(params: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    webhook_url = params.get("webhook_url") or os.getenv("SLACK_WEBHOOK_URL", "")
    if not webhook_url:
        return ActionResult(
            success=False,
            error="slack action requires 'webhook_url' or SLACK_WEBHOOK_URL env var",
        )

    message = params.get("message", f"[AEDA] {event.title}")
    payload: Dict[str, Any] = {"text": message}
    if channel := params.get("channel"):
        payload["channel"] = channel

    async with httpx.AsyncClient(timeout=10) as client:
        response = await client.post(webhook_url, json=payload)
        response.raise_for_status()
        return ActionResult(success=True, output="Slack message sent")


async def _log_action(params: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    message = params.get("message", f"[AEDA] Event triggered: {event.title}")
    level = params.get("level", "info").lower()
    log_fn = getattr(logger, level, logger.info)
    log_fn("[LOG ACTION] %s", message)
    return ActionResult(success=True, output=message)


# ─── Ansible AWX / AAP action ────────────────────────────────────────────────
# Launches an AWX/AAP job template via the v2 REST API.
#
# Minimal rule action config:
#   type: ansible
#   url: https://awx.example.com        # AWX/AAP base URL (no trailing slash)
#   token: <OAuth2 token>               # preferred; mutually exclusive with username/password
#   template_id: 42                     # numeric job template ID
#
# Optional:
#   username / password                 # basic-auth alternative to token
#   workflow: true                      # launch a workflow job template instead
#   extra_vars:                         # dict passed as extra_vars to the job
#     env: production
#     event_title: $event_title         # $-placeholders are already rendered by the time
#     severity: $event_severity         #   this handler runs
#   limit: "webservers"                 # inventory limit (host pattern)
#   wait: true                          # poll until job finishes (default: false)
#   poll_interval: 5                    # seconds between status polls (default: 5)
#   timeout: 300                        # max total wait time in seconds (default: 300)
#   verify_ssl: true                    # set false to skip TLS verification (default: true)

_ANSIBLE_TERMINAL_STATES = {"successful", "failed", "error", "canceled"}


async def _ansible_action(params: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    base_url = (params.get("url") or "").rstrip("/")
    if not base_url:
        return ActionResult(success=False, error="ansible action requires 'url'")

    template_id = params.get("template_id")
    if not template_id:
        return ActionResult(success=False, error="ansible action requires 'template_id'")

    token = params.get("token", "")
    username = params.get("username", "")
    password = params.get("password", "")

    if not token and not (username and password):
        return ActionResult(
            success=False,
            error="ansible action requires 'token' or 'username'+'password'",
        )

    is_workflow = bool(params.get("workflow", False))
    extra_vars = params.get("extra_vars") or {}
    limit = params.get("limit", "")
    do_wait = bool(params.get("wait", False))
    poll_interval = int(params.get("poll_interval", 5))
    timeout = int(params.get("timeout", 300))
    verify_ssl = bool(params.get("verify_ssl", True))

    template_kind = "workflow_job_templates" if is_workflow else "job_templates"
    launch_url = f"{base_url}/api/v2/{template_kind}/{template_id}/launch/"

    headers: Dict[str, str] = {"Content-Type": "application/json"}
    auth = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    else:
        auth = (username, password)

    body: Dict[str, Any] = {}
    if extra_vars:
        body["extra_vars"] = extra_vars
    if limit:
        body["limit"] = limit

    async with httpx.AsyncClient(verify=verify_ssl, timeout=30) as client:
        # Launch the job
        launch_resp = await client.post(launch_url, json=body, headers=headers, auth=auth)
        if launch_resp.status_code not in (200, 201):
            return ActionResult(
                success=False,
                error=f"Launch failed: HTTP {launch_resp.status_code} — {launch_resp.text[:300]}",
            )

        data = launch_resp.json()
        job_id = data.get("id")
        job_url = data.get("url", f"/api/v2/{'workflow_jobs' if is_workflow else 'jobs'}/{job_id}/")
        logger.info("Ansible job %s launched: %s%s", job_id, base_url, job_url)

        if not do_wait:
            return ActionResult(
                success=True,
                output=f"Job {job_id} launched (not waiting for completion). Status URL: {base_url}{job_url}",
            )

        # Poll until terminal state or timeout
        deadline = asyncio.get_event_loop().time() + timeout
        status_url = f"{base_url}{job_url}"

        while True:
            await asyncio.sleep(poll_interval)

            if asyncio.get_event_loop().time() > deadline:
                return ActionResult(
                    success=False,
                    error=f"Job {job_id} timed out after {timeout}s. Last status URL: {status_url}",
                )

            status_resp = await client.get(status_url, headers=headers, auth=auth)
            if status_resp.status_code != 200:
                logger.warning("Ansible status check HTTP %s", status_resp.status_code)
                continue

            job_data = status_resp.json()
            job_status = job_data.get("status", "")

            if job_status not in _ANSIBLE_TERMINAL_STATES:
                logger.debug("Ansible job %s status: %s — waiting…", job_id, job_status)
                continue

            success = job_status == "successful"
            summary = (
                f"Job {job_id} finished with status '{job_status}'. "
                f"Details: {base_url}{job_url}"
            )
            return ActionResult(
                success=success,
                output=summary if success else None,
                error=None if success else summary,
            )


# ─── Claude AI agent action ───────────────────────────────────────────────────
# Runs an agentic loop: sends the event to Claude with a set of tools and lets
# it decide what actions to take (run_ansible, send_slack, send_http, etc.).
#
# Minimal rule action config:
#   type: claude
#   system_prompt: "You are an SRE. Diagnose the alert and remediate."
#   user_prompt:   "Alert: $event_title\nSeverity: $event_severity"
#
# Optional:
#   model: claude-opus-4-7            # default
#   allowed_tools: [run_ansible, send_slack]   # empty = all tools
#   tool_defaults:                    # credentials merged into every tool call
#     run_ansible: {url: "https://awx.example.com", token: "abc"}
#     send_slack:  {webhook_url: "https://hooks.slack.com/..."}
#   max_iterations: 5                 # tool-use loop cap (default 5)
#   max_tokens: 1024

_DEFAULT_SYSTEM_NO_KB = (
    "You are an intelligent SRE automation agent for an event-driven platform.\n\n"
    "When an alert fires:\n"
    "1. Call query_ansible_templates to see all available playbooks.\n"
    "2. Choose the playbook whose name best matches the alert type "
    "(e.g. 'cpu' alert → cpu template, 'disk' alert → disk template).\n"
    "3. Call run_ansible with the chosen template_name.\n"
    "4. Summarize: which alert fired, which template you chose and why, and the job outcome."
)

_DEFAULT_SYSTEM_WITH_KB = (
    "You are an intelligent SRE automation agent for an event-driven platform.\n\n"
    "When an alert fires, follow these steps IN ORDER and do not skip any:\n"
    "1. Call search_knowledge with the alert name and symptoms to find the matching SOP.\n"
    "2. If a SOP is found, read its action_hints carefully:\n"
    "   - If action_hints contains 'ansible_template', call run_ansible with EXACTLY that "
    "template_name. Do NOT call query_ansible_templates — the SOP already tells you which template to use.\n"
    "   - If action_hints contains 'slack_channel', use that channel in send_slack.\n"
    "   - Follow any other action_hints keys as additional instructions.\n"
    "3. If no SOP is found or the SOP has no ansible_template hint, THEN call "
    "query_ansible_templates to discover available playbooks and pick the best match.\n"
    "4. Summarize: which alert fired, which SOP matched, which actions were taken, and the outcome."
)

_DEFAULT_USER = (
    "Alert fired:\n"
    "Title:     $event_title\n"
    "Severity:  $event_severity\n"
    "Source:    $event_source\n"
    "Type:      $event_type\n"
    "Timestamp: $event_timestamp\n"
    "Labels:    $labels_raw\n"
    "Payload:   $payload_raw"
)


_APPROVAL_INSTRUCTIONS = (
    "\n\nIMPORTANT — Human approval required for Ansible actions:\n"
    "Do NOT call run_ansible or query_ansible_templates directly.\n"
    "For any Ansible remediation, call request_approval with:\n"
    "  tool_name: 'run_ansible'\n"
    "  tool_params: the exact parameters you would pass (template_name, extra_vars, limit, etc.)\n"
    "  reason: a clear explanation of what the playbook will do and why it is needed\n"
    "After calling request_approval, summarize what you requested and why."
)


async def _claude_action(params: Dict[str, Any], event: AEDAEvent) -> ActionResult:
    from .agent.runner import run_agent

    use_kb          = bool(params.get("use_knowledge_base", False))
    require_approval = bool(params.get("require_approval", False))
    rule_name       = params.get("_rule_name", "unknown")

    default_system = _DEFAULT_SYSTEM_WITH_KB if use_kb else _DEFAULT_SYSTEM_NO_KB
    if require_approval:
        default_system = default_system + _APPROVAL_INSTRUCTIONS
    system_prompt = params.get("system_prompt") or default_system
    user_prompt   = params.get("user_prompt") or _DEFAULT_USER

    from config import settings as _settings
    model = params.get("model") or _settings.ANTHROPIC_MODEL or "claude-opus-4-7"

    allowed_tools = list(params.get("allowed_tools") or [])

    if require_approval:
        # Replace run_ansible + query_ansible_templates with request_approval
        allowed_tools = [t for t in allowed_tools if t not in ("run_ansible", "query_ansible_templates")]
        if "request_approval" not in allowed_tools:
            allowed_tools.append("request_approval")
    else:
        # Normal flow: ensure query_ansible_templates accompanies run_ansible
        if "run_ansible" in allowed_tools and "query_ansible_templates" not in allowed_tools:
            allowed_tools.insert(0, "query_ansible_templates")

    if use_kb and "search_knowledge" not in allowed_tools:
        allowed_tools.insert(0, "search_knowledge")
    if not use_kb and "search_knowledge" in allowed_tools:
        allowed_tools = [t for t in allowed_tools if t != "search_knowledge"]

    tool_defaults = params.get("tool_defaults") or {}

    # Inject meta so request_approval can store rule/event context and credentials
    if require_approval:
        tool_defaults = {
            **tool_defaults,
            "request_approval": {
                "_meta": {
                    "rule_name": rule_name,
                    "all_defaults": dict(tool_defaults),
                    "event_id": str(event.id),
                    "event_title": event.title,
                }
            },
        }

    max_iterations = int(params.get("max_iterations", 8))
    max_tokens     = int(params.get("max_tokens", 4096))

    result = await run_agent(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        event=event,
        model=model,
        allowed_tools=allowed_tools or None,
        tool_defaults=tool_defaults,
        max_iterations=max_iterations,
        max_tokens=max_tokens,
    )

    return ActionResult(
        success=result.success,
        output=result.output or None,
        error=result.error or None,
        reasoning=result.turns or None,
    )
