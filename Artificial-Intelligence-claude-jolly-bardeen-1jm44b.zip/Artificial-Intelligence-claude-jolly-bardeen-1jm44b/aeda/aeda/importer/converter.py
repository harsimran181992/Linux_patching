from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict

logger = logging.getLogger(__name__)

_SYSTEM = (
    "You convert raw SOP (Standard Operating Procedure) documents into structured "
    "knowledge base entries for AEDA, an AI-driven IT automation platform. "
    "Claude reads these entries at incident time to decide what remediation actions to take."
)

_USER_TMPL = """\
Convert the document below into a JSON knowledge base entry.

Return ONLY a valid JSON object — no markdown fences, no explanation — with exactly these fields:
{{
  "title":        "<short descriptive title, max 80 chars>",
  "content":      "<actionable summary, 2–5 paragraphs — cover: trigger conditions, step-by-step procedure, tools/systems involved, escalation path>",
  "tags":         ["<3–8 lowercase tags: alert types, systems, teams, environments>"],
  "action_hints": {{
    "<key>": "<value>"
  }}
}}

For action_hints include ONLY keys that are clearly referenced in the document:
  ansible_template  — exact AWX job template / playbook name
  slack_channel     — e.g. "#ops-alerts"
  http_url          — relevant API or webhook endpoint
  escalation_contact — email address or on-call team name
  runbook_url       — URL to an external runbook

Document text:
---
{raw_text}
---
"""


async def convert_to_kb(raw_text: str) -> Dict[str, Any]:
    """
    Call Claude with raw extracted text and return a structured KB entry dict.
    Keys: title, content, tags, action_hints.
    Raises RuntimeError on configuration errors or Claude response issues.
    """
    from config import settings
    import anthropic

    if not settings.ANTHROPIC_API_KEY:
        raise RuntimeError("ANTHROPIC_API_KEY is not configured in settings")

    client_kwargs: Dict[str, Any] = {"api_key": settings.ANTHROPIC_API_KEY}
    if settings.ANTHROPIC_BASE_URL:
        client_kwargs["base_url"] = settings.ANTHROPIC_BASE_URL

    client = anthropic.AsyncAnthropic(**client_kwargs)

    response = await client.messages.create(
        model=settings.ANTHROPIC_MODEL,
        max_tokens=2048,
        system=_SYSTEM,
        messages=[
            {"role": "user", "content": _USER_TMPL.format(raw_text=raw_text)}
        ],
    )

    raw_json = response.content[0].text.strip()

    # Strip accidental markdown fences
    raw_json = re.sub(r"^```(?:json)?\s*", "", raw_json)
    raw_json = re.sub(r"\s*```$", "", raw_json.strip())

    try:
        entry = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        logger.error("Claude returned non-JSON: %.500s", raw_json)
        raise RuntimeError(f"Claude returned malformed JSON: {exc}") from exc

    return {
        "title": str(entry.get("title", "Untitled SOP"))[:256],
        "content": str(entry.get("content", raw_text[:2000])),
        "tags": [str(t) for t in (entry.get("tags") or []) if t][:20],
        "action_hints": {
            str(k): v
            for k, v in (entry.get("action_hints") or {}).items()
        },
    }
