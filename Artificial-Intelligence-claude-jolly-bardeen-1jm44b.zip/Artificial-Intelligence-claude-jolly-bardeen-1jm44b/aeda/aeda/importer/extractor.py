from __future__ import annotations

import io
from typing import Tuple

# Maximum characters sent to Claude — guards against huge API calls
_MAX_CHARS = 60_000

SUPPORTED_EXTENSIONS = {"pdf", "docx", "doc", "txt", "md", "markdown", "rst"}


def extract_text(filename: str, data: bytes) -> Tuple[str, str | None]:
    """
    Extract plain text from an uploaded file.
    Returns (text, warning_or_None).
    Raises ValueError for unsupported file types.
    Raises RuntimeError if a required library is missing.
    """
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file type '.{ext}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )
    if ext == "pdf":
        return _from_pdf(data)
    if ext in ("docx", "doc"):
        return _from_docx(data)
    return _from_text(data), None


def _from_pdf(data: bytes) -> Tuple[str, str | None]:
    try:
        import fitz  # pymupdf
    except ImportError:
        raise RuntimeError(
            "pymupdf is not installed. Add 'pymupdf' to requirements.txt."
        )

    doc = fitz.open(stream=data, filetype="pdf")
    pages = [page.get_text() for page in doc]
    doc.close()

    raw = "\n".join(pages).strip()
    warning: str | None = None

    if not raw:
        warning = (
            "No extractable text found — document may be a scanned image. "
            "Consider OCR pre-processing before importing."
        )
    elif len(raw) < 200:
        warning = "Very little text extracted — document may be mostly images or tables."

    return _truncate(raw), warning


def _from_docx(data: bytes) -> Tuple[str, str | None]:
    try:
        from docx import Document
    except ImportError:
        raise RuntimeError(
            "python-docx is not installed. Add 'python-docx' to requirements.txt."
        )

    doc = Document(io.BytesIO(data))
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    raw = "\n".join(paragraphs).strip()
    warning = None if raw else "No text found in document."
    return _truncate(raw), warning


def _from_text(data: bytes) -> str:
    try:
        return _truncate(data.decode("utf-8").strip())
    except UnicodeDecodeError:
        return _truncate(data.decode("latin-1", errors="replace").strip())


def _truncate(text: str) -> str:
    if len(text) > _MAX_CHARS:
        return (
            text[:_MAX_CHARS]
            + "\n\n[Document truncated — remaining content was not processed]"
        )
    return text
