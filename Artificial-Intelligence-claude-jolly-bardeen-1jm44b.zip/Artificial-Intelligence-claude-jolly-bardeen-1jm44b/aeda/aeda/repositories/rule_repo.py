from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.orm import Rule


async def list_rules(db: AsyncSession, enabled_only: bool = False) -> List[Rule]:
    stmt = select(Rule)
    if enabled_only:
        stmt = stmt.where(Rule.enabled == True)  # noqa: E712
    stmt = stmt.order_by(Rule.priority, Rule.name)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_rule(db: AsyncSession, rule_id: uuid.UUID) -> Optional[Rule]:
    result = await db.execute(select(Rule).where(Rule.id == rule_id))
    return result.scalar_one_or_none()


async def get_rule_by_name(db: AsyncSession, name: str) -> Optional[Rule]:
    result = await db.execute(select(Rule).where(Rule.name == name))
    return result.scalar_one_or_none()


async def create_rule(db: AsyncSession, data: Dict[str, Any]) -> Rule:
    rule = Rule(**data)
    db.add(rule)
    await db.commit()
    await db.refresh(rule)
    return rule


async def update_rule(db: AsyncSession, rule: Rule, data: Dict[str, Any]) -> Rule:
    for key, value in data.items():
        setattr(rule, key, value)
    await db.commit()
    await db.refresh(rule)
    return rule


async def delete_rule(db: AsyncSession, rule: Rule) -> None:
    await db.delete(rule)
    await db.commit()
