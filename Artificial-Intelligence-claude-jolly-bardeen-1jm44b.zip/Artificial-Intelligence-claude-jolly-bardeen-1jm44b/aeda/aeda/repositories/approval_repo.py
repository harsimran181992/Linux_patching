from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.orm import Approval


async def create(db: AsyncSession, data: Dict[str, Any]) -> Approval:
    a = Approval(**data)
    db.add(a)
    await db.commit()
    await db.refresh(a)
    return a


async def list_approvals(
    db: AsyncSession,
    status: Optional[str] = None,
    limit: int = 100,
) -> List[Approval]:
    q = select(Approval).order_by(Approval.created_at.desc()).limit(limit)
    if status:
        q = q.where(Approval.status == status)
    return list((await db.execute(q)).scalars().all())


async def get(db: AsyncSession, approval_id: uuid.UUID) -> Optional[Approval]:
    return (await db.execute(select(Approval).where(Approval.id == approval_id))).scalar_one_or_none()


async def resolve(
    db: AsyncSession,
    approval_id: uuid.UUID,
    status: str,
    result: Optional[str] = None,
) -> Optional[Approval]:
    a = await get(db, approval_id)
    if a is None:
        return None
    a.status = status
    a.result = result
    a.resolved_at = datetime.utcnow()
    await db.commit()
    await db.refresh(a)
    return a


async def count_pending(db: AsyncSession) -> int:
    from sqlalchemy import func
    result = await db.execute(
        select(func.count()).select_from(Approval).where(Approval.status == "pending")
    )
    return result.scalar() or 0
