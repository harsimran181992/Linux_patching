from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.orm import KnowledgeDoc


async def save_doc(db: AsyncSession, data: Dict[str, Any]) -> KnowledgeDoc:
    doc = KnowledgeDoc(**data)
    db.add(doc)
    await db.commit()
    await db.refresh(doc)
    return doc


async def list_docs(db: AsyncSession, limit: int = 100) -> List[KnowledgeDoc]:
    result = await db.execute(
        select(KnowledgeDoc).order_by(KnowledgeDoc.created_at.desc()).limit(limit)
    )
    return list(result.scalars().all())


async def get_doc(db: AsyncSession, doc_id: uuid.UUID) -> Optional[KnowledgeDoc]:
    result = await db.execute(select(KnowledgeDoc).where(KnowledgeDoc.id == doc_id))
    return result.scalar_one_or_none()


async def delete_doc(db: AsyncSession, doc_id: uuid.UUID) -> bool:
    doc = await get_doc(db, doc_id)
    if doc is None:
        return False
    await db.delete(doc)
    await db.commit()
    return True


async def update_doc(db: AsyncSession, doc_id: uuid.UUID, updates: Dict[str, Any]) -> Optional[KnowledgeDoc]:
    doc = await get_doc(db, doc_id)
    if doc is None:
        return None
    for k, v in updates.items():
        setattr(doc, k, v)
    await db.commit()
    await db.refresh(doc)
    return doc


async def search_similar(
    db: AsyncSession,
    query_embedding: List[float],
    limit: int = 3,
) -> List[Tuple[KnowledgeDoc, float]]:
    """Return (doc, cosine_distance) pairs ordered by relevance."""
    dist_col = KnowledgeDoc.embedding.cosine_distance(query_embedding).label("dist")
    stmt = (
        select(KnowledgeDoc, dist_col)
        .where(KnowledgeDoc.embedding.isnot(None))
        .order_by(dist_col)
        .limit(limit)
    )
    rows = (await db.execute(stmt)).all()
    return [(row[0], float(row[1])) for row in rows]
