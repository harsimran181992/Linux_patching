from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.orm import Source


async def list_sources(db: AsyncSession, enabled_only: bool = False) -> List[Source]:
    stmt = select(Source).order_by(Source.name)
    if enabled_only:
        stmt = stmt.where(Source.enabled == True)  # noqa: E712
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def get_source(db: AsyncSession, source_id: uuid.UUID) -> Optional[Source]:
    result = await db.execute(select(Source).where(Source.id == source_id))
    return result.scalar_one_or_none()


async def get_source_by_name(db: AsyncSession, name: str) -> Optional[Source]:
    result = await db.execute(select(Source).where(Source.name == name))
    return result.scalar_one_or_none()


async def create_source(db: AsyncSession, data: Dict[str, Any]) -> Source:
    source = Source(**data)
    db.add(source)
    await db.commit()
    await db.refresh(source)
    return source


async def update_source(db: AsyncSession, source: Source, data: Dict[str, Any]) -> Source:
    for key, value in data.items():
        setattr(source, key, value)
    await db.commit()
    await db.refresh(source)
    return source


async def delete_source(db: AsyncSession, source: Source) -> None:
    await db.delete(source)
    await db.commit()
