from __future__ import annotations

from typing import List, Optional

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.orm import AuditEntry


async def list_audit(
    db: AsyncSession,
    limit: int = 50,
    rule_name: Optional[str] = None,
    status: Optional[str] = None,
) -> List[AuditEntry]:
    stmt = select(AuditEntry).order_by(desc(AuditEntry.timestamp)).limit(limit)
    if rule_name:
        stmt = stmt.where(AuditEntry.rule_name == rule_name)
    if status:
        stmt = stmt.where(AuditEntry.status == status)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def count_by_status(db: AsyncSession) -> dict:
    from sqlalchemy import func
    result = await db.execute(
        select(AuditEntry.status, func.count().label("n"))
        .group_by(AuditEntry.status)
    )
    return {row.status: row.n for row in result}
