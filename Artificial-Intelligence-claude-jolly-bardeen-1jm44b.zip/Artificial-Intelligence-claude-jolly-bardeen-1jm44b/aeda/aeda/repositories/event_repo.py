from __future__ import annotations

import uuid
from typing import List, Optional

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.orm import Event


async def save_event(db: AsyncSession, data: dict) -> Event:
    event = Event(**data)
    db.add(event)
    await db.commit()
    return event


async def list_recent(
    db: AsyncSession,
    limit: int = 50,
    source: Optional[str] = None,
    severity: Optional[str] = None,
) -> List[Event]:
    stmt = select(Event).order_by(desc(Event.timestamp)).limit(limit)
    if source:
        stmt = stmt.where(Event.source == source)
    if severity:
        stmt = stmt.where(Event.severity == severity)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def mark_processed(db: AsyncSession, event_id: uuid.UUID) -> None:
    from datetime import datetime
    from sqlalchemy import update
    await db.execute(
        update(Event).where(Event.id == event_id).values(processed_at=datetime.utcnow())
    )
    await db.commit()
