from __future__ import annotations

import asyncio
import logging
from collections import deque
from typing import Deque, List, Optional

from .action_executor import execute_action
from .models import AEDAEvent, AuditEntry, Rule
from .rule_engine import find_matching_rules, load_rules

logger = logging.getLogger(__name__)

# Max items kept in memory for audit log and recent events
_AUDIT_CAP = 1000
_EVENTS_CAP = 200


class EventPipeline:
    def __init__(self, rules_dir: str) -> None:
        self.rules_dir = rules_dir
        self.rules: List[Rule] = []
        self.audit_log: Deque[AuditEntry] = deque(maxlen=_AUDIT_CAP)
        self.recent_events: Deque[AEDAEvent] = deque(maxlen=_EVENTS_CAP)
        self._queue: asyncio.Queue[AEDAEvent] = asyncio.Queue()
        self._running = False
        self._worker_task: Optional[asyncio.Task] = None  # type: ignore[type-arg]

    def reload_rules(self) -> int:
        self.rules = load_rules(self.rules_dir)
        logger.info("Loaded %d rule(s) from %s", len(self.rules), self.rules_dir)
        return len(self.rules)

    async def ingest(self, event: AEDAEvent) -> None:
        self.recent_events.append(event)
        await self._queue.put(event)
        logger.info("Ingested event [%s] '%s' from '%s'", event.id, event.title, event.source)

    async def start(self) -> None:
        self._running = True
        self.reload_rules()
        self._worker_task = asyncio.create_task(self._worker(), name="aeda-worker")
        logger.info("Event pipeline started")

    async def stop(self) -> None:
        self._running = False
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        logger.info("Event pipeline stopped")

    async def _worker(self) -> None:
        while self._running:
            try:
                event = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                await self._process(event)
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("Pipeline worker error: %s", exc, exc_info=True)

    async def _process(self, event: AEDAEvent) -> None:
        matching = find_matching_rules(self.rules, event)

        if not matching:
            logger.debug("No rules matched event [%s]", event.id)
            return

        for rule in matching:
            logger.info("Rule '%s' matched event [%s]", rule.name, event.id)
            for action_config in rule.actions:
                result = await execute_action(action_config, event)
                entry = AuditEntry(
                    event_id=event.id,
                    event_title=event.title,
                    rule_name=rule.name,
                    action_type=action_config.get("type", "unknown"),
                    status="success" if result.success else "failed",
                    output=result.output,
                    error=result.error,
                )
                self.audit_log.append(entry)
                log_fn = logger.info if result.success else logger.error
                log_fn(
                    "  [%s] action '%s' → %s",
                    rule.name,
                    action_config.get("type"),
                    "OK" if result.success else f"FAILED: {result.error}",
                )
