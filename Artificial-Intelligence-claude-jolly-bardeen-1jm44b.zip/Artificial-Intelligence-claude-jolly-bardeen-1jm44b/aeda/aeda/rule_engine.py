from __future__ import annotations

import logging
from typing import Any, Dict, List

from .models import AEDAEvent, RuleData

logger = logging.getLogger(__name__)

_SAFE_BUILTINS: Dict[str, Any] = {
    "__builtins__": {},
    "True": True, "False": False, "None": None,
    "len": len, "str": str, "int": int, "float": float,
    "list": list, "dict": dict, "any": any, "all": all,
    "isinstance": isinstance,
}


def _eval_condition(expression: str, context: Dict[str, Any]) -> bool:
    try:
        ns = {**_SAFE_BUILTINS, **context}
        return bool(eval(expression, ns))  # noqa: S307
    except Exception as exc:
        logger.warning("Condition eval failed '%s': %s", expression, exc)
        return False


def match_event(rule: RuleData, event: AEDAEvent) -> bool:
    if not rule.enabled:
        return False
    if "*" not in rule.sources and event.source not in rule.sources:
        return False
    ctx = event.to_eval_context()
    return all(_eval_condition(c, ctx) for c in rule.conditions)


def find_matching_rules(rules: List[RuleData], event: AEDAEvent) -> List[RuleData]:
    return [r for r in rules if match_event(r, event)]
