from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ─── Runtime event (flows through the pipeline) ───────────────────────────────

class AEDAEvent(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    source: str
    event_type: str
    severity: str = "info"
    title: str
    payload: Dict[str, Any] = {}
    labels: Dict[str, str] = {}
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    def to_eval_context(self) -> Dict[str, Any]:
        return {
            "event": self,
            "payload": self.payload,
            "labels": self.labels,
            "severity": self.severity,
            "source": self.source,
            "event_type": self.event_type,
            "title": self.title,
        }


# ─── Rule evaluated by the rule engine (loaded from DB by the worker) ─────────

@dataclass
class RuleData:
    name: str
    id: Optional[str] = None
    enabled: bool = True
    sources: List[str] = field(default_factory=lambda: ["*"])
    conditions: List[str] = field(default_factory=list)
    actions: List[Dict[str, Any]] = field(default_factory=list)
    priority: int = 0


# ─── Action result ─────────────────────────────────────────────────────────────

class ActionResult(BaseModel):
    success: bool
    output: Optional[str] = None
    error: Optional[str] = None
    reasoning: Optional[List[Dict[str, Any]]] = None
