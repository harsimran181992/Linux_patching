from __future__ import annotations

import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

_MODEL_NAME = "BAAI/bge-small-en-v1.5"
_model: Optional[object] = None


def _get_model():
    global _model
    if _model is None:
        try:
            from fastembed import TextEmbedding
            _model = TextEmbedding(_MODEL_NAME)
            logger.info("Embedding model '%s' loaded", _MODEL_NAME)
        except Exception as exc:
            raise RuntimeError(f"Failed to load embedding model '{_MODEL_NAME}': {exc}") from exc
    return _model


def embed_text(text: str) -> List[float]:
    """Return a 384-dim embedding vector for the given text."""
    model = _get_model()
    results = list(model.embed([text]))
    return results[0].tolist()
