from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import AEDAEvent
from ..repositories import event_repo

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sources/webhook", tags=["Webhook Sources"])


# ─── Normalizers ──────────────────────────────────────────────────────────────

def normalize_prometheus(payload: Dict[str, Any]) -> List[AEDAEvent]:
    _sev = {
        "critical": "critical", "error": "critical",
        "warning": "warning",   "warn": "warning",
        "info": "info",         "none": "info",
    }
    events: List[AEDAEvent] = []
    for alert in payload.get("alerts", []):
        labels = alert.get("labels", {})
        annotations = alert.get("annotations", {})
        status = alert.get("status", "firing")
        severity = _sev.get(str(labels.get("severity", "info")).lower(), "info")
        summary = annotations.get("summary") or labels.get("alertname", "Prometheus Alert")
        events.append(AEDAEvent(
            source="prometheus",
            event_type="alert",
            severity=severity,
            title=f"[{status.upper()}] {summary}",
            payload={"status": status, "annotations": annotations, "generatorURL": alert.get("generatorURL", "")},
            labels={k: str(v) for k, v in labels.items()},
        ))
    return events


def normalize_github(payload: Dict[str, Any], event_type: str) -> List[AEDAEvent]:
    repo = payload.get("repository", {}).get("full_name", "unknown/repo")
    if event_type == "push":
        branch = payload.get("ref", "").replace("refs/heads/", "")
        pusher = payload.get("pusher", {}).get("name", "unknown")
        n = len(payload.get("commits", []))
        title = f"Push to {repo}:{branch} by {pusher} ({n} commit{'s' if n != 1 else ''})"
    elif event_type == "pull_request":
        action = payload.get("action", "unknown")
        number = payload.get("number", "")
        pr_title = payload.get("pull_request", {}).get("title", "")
        title = f"PR #{number} {action}: {pr_title} [{repo}]"
    elif event_type in ("deployment", "deployment_status"):
        env = (payload.get("deployment") or payload.get("deployment_status", {})).get("environment", "unknown")
        state = payload.get("deployment_status", {}).get("state", "")
        title = f"Deployment{' ' + state if state else ''} on {env} in {repo}"
    elif event_type == "workflow_run":
        wf = payload.get("workflow_run", {})
        conclusion = wf.get("conclusion") or wf.get("status", "unknown")
        title = f"Workflow '{wf.get('name', '')}' {conclusion} in {repo}"
    else:
        title = f"GitHub {event_type} event in {repo}"
    return [AEDAEvent(source="github", event_type=event_type, severity="info", title=title,
                      payload=payload, labels={"repo": repo, "event": event_type})]


def normalize_uptime_kuma(payload: Dict[str, Any]) -> List[AEDAEvent]:
    """
    Uptime Kuma webhook payload:
      heartbeat.status  0 = DOWN, 1 = UP
      monitor.name      monitor display name  (use as title)
      monitor.tags      list of {name, value} — tag name="severity" sets AEDA severity
      msg               human-readable description
    """
    heartbeat = payload.get("heartbeat") or {}
    monitor   = payload.get("monitor") or {}
    status    = heartbeat.get("status", 0)       # 0=down, 1=up
    state     = "DOWN" if status == 0 else "UP"
    name      = monitor.get("name", "Unknown monitor")
    msg       = payload.get("msg") or heartbeat.get("msg", "")
    url       = monitor.get("url", "")

    # Severity from monitor tags (tag name="severity", value="critical"/"warning")
    # Falls back to: DOWN=warning, UP=info
    tag_sev = next(
        (t.get("value", "").lower() for t in (monitor.get("tags") or []) if t.get("name") == "severity"),
        None,
    )
    _sev_map = {"critical": "critical", "warning": "warning", "info": "info"}
    if tag_sev and tag_sev in _sev_map:
        severity = _sev_map[tag_sev]
    else:
        severity = "warning" if status == 0 else "info"

    labels: Dict[str, str] = {
        "monitor_id": str(monitor.get("id", "")),
        "monitor_type": monitor.get("type", ""),
        "state": state,
    }
    if url:
        labels["url"] = url

    # Add ALL monitor tags as labels so rule conditions and Claude can use them
    for tag in (monitor.get("tags") or []):
        tag_name = (tag.get("name") or "").strip()
        tag_value = str(tag.get("value") or "").strip()
        if tag_name:
            labels[tag_name] = tag_value

    return [AEDAEvent(
        source="uptime-kuma",
        event_type="monitor_alert",
        severity=severity,
        title=f"[{state}] {name}",
        payload={
            "msg": msg,
            "duration_seconds": heartbeat.get("duration"),
            "monitor_url": url,
            "monitor_type": monitor.get("type"),
        },
        labels=labels,
    )]


def normalize_generic(payload: Dict[str, Any], source_name: str) -> List[AEDAEvent]:
    def first(*keys: str, default: str = "") -> str:
        return next((str(payload[k]) for k in keys if payload.get(k)), default)

    title = first("title", "name", "message", "summary", "description", default=f"{source_name} event")
    raw_sev = first("severity", "level", "priority", "status", default="info").lower()
    event_type = first("event_type", "type", "kind", "action", default="event")
    sev_map = {
        "critical": "critical", "error": "critical", "high": "critical", "fatal": "critical",
        "warning": "warning",   "warn": "warning",   "medium": "warning",
        "info": "info",         "low": "info",       "debug": "info",    "ok": "info",
    }
    return [AEDAEvent(source=source_name, event_type=event_type,
                      severity=sev_map.get(raw_sev, "info"), title=title, payload=payload)]


# ─── Shared ingest helper ─────────────────────────────────────────────────────

async def _ingest_events(request: Request, events: List[AEDAEvent]) -> dict:
    from ..db.session import AsyncSessionLocal
    queue = request.app.state.queue
    async with AsyncSessionLocal() as db:
        for event in events:
            await event_repo.save_event(db, {
                "id": uuid.UUID(event.id),
                "source": event.source,
                "event_type": event.event_type,
                "severity": event.severity,
                "title": event.title,
                "payload": event.payload,
                "labels": event.labels,
                "timestamp": event.timestamp,
            })
            await queue.push(event.model_dump(mode="json"))
    return {"accepted": True, "events_queued": len(events)}


# ─── Routes ───────────────────────────────────────────────────────────────────

@router.post("/prometheus", status_code=202, summary="Prometheus Alertmanager webhook")
async def webhook_prometheus(request: Request):
    payload = await request.json()
    events = normalize_prometheus(payload)
    logger.info("Prometheus webhook: %d alert(s)", len(events))
    return await _ingest_events(request, events)


@router.post("/github", status_code=202, summary="GitHub webhook")
async def webhook_github(
    request: Request,
    x_github_event: Optional[str] = Header(default=None, alias="X-GitHub-Event"),
):
    payload = await request.json()
    event_type = x_github_event or payload.get("action", "unknown")
    events = normalize_github(payload, event_type)
    logger.info("GitHub webhook (%s): %d event(s)", event_type, len(events))
    return {**(await _ingest_events(request, events)), "event_type": event_type}


@router.post("/uptime-kuma", status_code=202, summary="Uptime Kuma webhook")
async def webhook_uptime_kuma(request: Request):
    payload = await request.json()
    events = normalize_uptime_kuma(payload)
    monitor_name = (payload.get("monitor") or {}).get("name", "unknown")
    status = (payload.get("heartbeat") or {}).get("status")
    logger.info("Uptime Kuma webhook: monitor=%r state=%s", monitor_name, status)
    return await _ingest_events(request, events)


@router.post("/{source_name}", status_code=202, summary="Generic webhook (any source)")
async def webhook_generic(source_name: str, request: Request):
    payload = await request.json()
    events = normalize_generic(payload, source_name)
    logger.info("Generic webhook (%s): %d event(s)", source_name, len(events))
    return {**(await _ingest_events(request, events)), "source": source_name}
