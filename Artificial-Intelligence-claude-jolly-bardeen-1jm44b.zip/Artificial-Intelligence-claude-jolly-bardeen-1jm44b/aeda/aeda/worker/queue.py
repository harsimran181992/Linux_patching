from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import redis.asyncio as aioredis

from config import settings

logger = logging.getLogger(__name__)

QUEUE_KEY = "aeda:event_queue"


class EventQueue:
    def __init__(self) -> None:
        self._redis: Optional[aioredis.Redis] = None  # type: ignore[type-arg]

    async def connect(self) -> None:
        self._redis = await aioredis.from_url(
            settings.REDIS_URL,
            decode_responses=True,
            max_connections=20,
        )
        logger.info("Redis connected: %s", settings.REDIS_URL)

    async def disconnect(self) -> None:
        if self._redis:
            await self._redis.aclose()

    async def push(self, event_data: Dict[str, Any]) -> None:
        await self._redis.lpush(QUEUE_KEY, json.dumps(event_data, default=str))

    async def pop(self, timeout: int = 1) -> Optional[Dict[str, Any]]:
        item = await self._redis.brpop(QUEUE_KEY, timeout=timeout)
        if item:
            _, data = item
            return json.loads(data)
        return None

    async def size(self) -> int:
        return await self._redis.llen(QUEUE_KEY)

    async def ping(self) -> bool:
        try:
            return bool(await self._redis.ping())
        except Exception:
            return False
