from __future__ import annotations

import asyncio
import logging
import time
import uuid
from datetime import datetime
from typing import List, Optional

from sqlalchemy import update

from ..db.orm import AuditEntry as AuditEntryORM
from ..db.orm import Event as EventORM
from ..db.orm import Rule as RuleORM
from ..db.session import AsyncSessionLocal
from ..models import AEDAEvent, RuleData
from ..rule_engine import find_matching_rules
from ..action_executor import execute_action
from .queue import EventQueue

logger = logging.getLogger(__name__)

_RULE_CACHE_TTL = 30  # seconds — reload rules from DB if cache is older than this


class EventProcessor:
    def __init__(self, queue: EventQueue) -> None:
        self.queue = queue
        self._rules: List[RuleData] = []
        self._rules_loaded_at: float = 0.0
        self._running = False
        self._task: Optional[asyncio.Task] = None  # type: ignore[type-arg]

    async def start(self) -> None:
        self._running = True
        await self._refresh_rules()
        self._task = asyncio.create_task(self._worker(), name="aeda-processor")
        logger.info("Event processor started")

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def invalidate_rules(self) -> None:
        """Force rule cache refresh on next worker tick (call after CRUD changes)."""
        self._rules_loaded_at = 0.0

    async def _refresh_rules(self) -> None:
        from sqlalchemy import select
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(RuleORM)
                .where(RuleORM.enabled == True)  # noqa: E712
                .order_by(RuleORM.priority, RuleORM.name)
            )
            db_rules = result.scalars().all()
            self._rules = [
                RuleData(
                    id=str(r.id),
                    name=r.name,
                    enabled=r.enabled,
                    sources=r.sources or ["*"],
                    conditions=r.conditions or [],
                    actions=r.actions or [],
                    priority=r.priority,
                )
                for r in db_rules
            ]
            self._rules_loaded_at = time.monotonic()
            logger.info("Rule cache refreshed: %d rule(s)", len(self._rules))

    async def _worker(self) -> None:
        while self._running:
            try:
                event_dict = await self.queue.pop(timeout=1)
                # Refresh AFTER the blocking pop so any invalidation that happened
                # while brpop was waiting is picked up before we process the event.
                if time.monotonic() - self._rules_loaded_at > _RULE_CACHE_TTL:
                    await self._refresh_rules()
                if event_dict:
                    await self._process(event_dict)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("Processor error: %s", exc, exc_info=True)

    async def _process(self, event_dict: dict) -> None:
        event = AEDAEvent(**event_dict)
        matching = find_matching_rules(self._rules, event)

        async with AsyncSessionLocal() as db:
            # Mark the event as processed
            await db.execute(
                update(EventORM)
                .where(EventORM.id == uuid.UUID(str(event.id)))
                .values(processed_at=datetime.utcnow())
            )

            if not matching:
                await db.commit()
                logger.debug("No rules matched event [%s]", event.id)
                return

            for rule in matching:
                logger.info("Rule '%s' matched event [%s]", rule.name, event.id)
                for action_config in rule.actions:
                    t0 = time.monotonic()
                    # Inject rule name so claude action can store it on approval records
                    enriched_action = {**action_config, "_rule_name": rule.name}
                    result = await execute_action(enriched_action, event)
                    duration_ms = int((time.monotonic() - t0) * 1000)

                    audit_data = {
                        "event_id": uuid.UUID(str(event.id)),
                        "event_title": event.title,
                        "rule_id": uuid.UUID(rule.id) if rule.id else None,
                        "rule_name": rule.name,
                        "action_type": action_config.get("type", "unknown"),
                        "status": "success" if result.success else "failed",
                        "output": result.output,
                        "error": result.error,
                        "duration_ms": duration_ms,
                    }
                    if result.reasoning is not None:
                        audit_data["reasoning"] = result.reasoning
                    audit = AuditEntryORM(**audit_data)
                    db.add(audit)

                    log_fn = logger.info if result.success else logger.error
                    log_fn(
                        "  [%s] %s → %s",
                        rule.name,
                        action_config.get("type"),
                        "OK" if result.success else f"FAILED: {result.error}",
                    )

            await db.commit()
