from __future__ import annotations

from fastapi import HTTPException, Request

from ..db.session import get_db  # re-export for routers
from ..worker.processor import EventProcessor
from ..worker.queue import EventQueue

__all__ = ["get_db", "get_queue", "get_processor"]


def get_queue(request: Request) -> EventQueue:
    return request.app.state.queue


def get_processor(request: Request) -> EventProcessor:
    return request.app.state.processor
