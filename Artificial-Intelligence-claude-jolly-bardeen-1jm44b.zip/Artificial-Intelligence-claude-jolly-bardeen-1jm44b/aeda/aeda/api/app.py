from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from ..db.session import engine
from ..worker.queue import EventQueue
from ..worker.processor import EventProcessor
from .routers import events, rules, sources, audit, health, knowledge, approvals
from ..sources.webhook import router as webhook_router

logger = logging.getLogger(__name__)

_UI_FILE = os.path.join(os.path.dirname(__file__), "..", "..", "ui", "index.html")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Boot
    queue = EventQueue()
    await queue.connect()
    app.state.queue = queue

    processor = EventProcessor(queue)
    await processor.start()
    app.state.processor = processor

    logger.info("AEDA started — DB=%s", engine.url)
    yield

    # Shutdown
    await processor.stop()
    await queue.disconnect()
    await engine.dispose()
    logger.info("AEDA stopped")


app = FastAPI(
    title="AEDA — AI-Enhanced Event-Driven Automation",
    version="0.2.0",
    description="Enterprise event-driven automation: persistent rules, Redis queue, PostgreSQL storage.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(events.router)
app.include_router(rules.router)
app.include_router(sources.router)
app.include_router(audit.router)
app.include_router(health.router)
app.include_router(knowledge.router)
app.include_router(approvals.router)
app.include_router(webhook_router)


@app.get("/", include_in_schema=False)
def serve_ui():
    return FileResponse(_UI_FILE)
