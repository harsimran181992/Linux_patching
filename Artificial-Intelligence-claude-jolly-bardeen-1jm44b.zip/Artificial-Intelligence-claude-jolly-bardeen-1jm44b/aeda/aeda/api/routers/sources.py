from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from ...repositories import source_repo
from ..deps import get_db

router = APIRouter(prefix="/sources", tags=["Sources"])

SOURCE_TYPES = [
    "webhook_generic",
    "webhook_prometheus",
    "webhook_github",
    "manual",
]


class SourceCreate(BaseModel):
    name: str
    display_name: str = ""
    source_type: str = "webhook_generic"
    description: str = ""
    enabled: bool = True
    config: Dict[str, Any] = {}


class SourceUpdate(BaseModel):
    display_name: Optional[str] = None
    source_type: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
    config: Optional[Dict[str, Any]] = None


def _src_out(s) -> Dict[str, Any]:
    return {
        "id": str(s.id),
        "name": s.name,
        "display_name": s.display_name,
        "source_type": s.source_type,
        "description": s.description,
        "enabled": s.enabled,
        "config": s.config,
        "created_at": s.created_at.isoformat(),
        "updated_at": s.updated_at.isoformat(),
        "webhook_url": f"/sources/webhook/{s.name}" if "webhook" in s.source_type else None,
    }


@router.get("")
async def list_sources(db: AsyncSession = Depends(get_db)) -> List[Dict[str, Any]]:
    sources = await source_repo.list_sources(db)
    return [_src_out(s) for s in sources]


@router.post("", status_code=201)
async def create_source(body: SourceCreate, db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    existing = await source_repo.get_source_by_name(db, body.name)
    if existing:
        raise HTTPException(status_code=409, detail=f"Source '{body.name}' already exists")
    if body.source_type not in SOURCE_TYPES:
        raise HTTPException(status_code=422, detail=f"source_type must be one of: {SOURCE_TYPES}")
    source = await source_repo.create_source(db, body.model_dump())
    return _src_out(source)


@router.get("/{source_id}")
async def get_source(source_id: uuid.UUID, db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    source = await source_repo.get_source(db, source_id)
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return _src_out(source)


@router.put("/{source_id}")
async def update_source(
    source_id: uuid.UUID,
    body: SourceUpdate,
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    source = await source_repo.get_source(db, source_id)
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    updates = body.model_dump(exclude_unset=True)
    source = await source_repo.update_source(db, source, updates)
    return _src_out(source)


@router.delete("/{source_id}", status_code=204)
async def delete_source(source_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    source = await source_repo.get_source(db, source_id)
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    await source_repo.delete_source(db, source)
