from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from ...repositories import rule_repo
from ..deps import get_db, get_processor

router = APIRouter(prefix="/rules", tags=["Rules"])


# ─── Schemas ──────────────────────────────────────────────────────────────────

class RuleCreate(BaseModel):
    name: str
    description: str = ""
    enabled: bool = True
    sources: List[str] = ["*"]
    conditions: List[str] = []
    actions: List[Dict[str, Any]] = []
    priority: int = 0


class RuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
    sources: Optional[List[str]] = None
    conditions: Optional[List[str]] = None
    actions: Optional[List[Dict[str, Any]]] = None
    priority: Optional[int] = None


def _rule_out(r) -> Dict[str, Any]:
    return {
        "id": str(r.id),
        "name": r.name,
        "description": r.description,
        "enabled": r.enabled,
        "sources": r.sources,
        "conditions": r.conditions,
        "actions": r.actions,
        "priority": r.priority,
        "created_at": r.created_at.isoformat(),
        "updated_at": r.updated_at.isoformat(),
    }


# ─── Routes ───────────────────────────────────────────────────────────────────

@router.get("")
async def list_rules(
    enabled_only: bool = Query(default=False),
    db: AsyncSession = Depends(get_db),
) -> List[Dict[str, Any]]:
    rules = await rule_repo.list_rules(db, enabled_only=enabled_only)
    return [_rule_out(r) for r in rules]


@router.post("", status_code=201)
async def create_rule(
    body: RuleCreate,
    db: AsyncSession = Depends(get_db),
    processor=Depends(get_processor),
) -> Dict[str, Any]:
    existing = await rule_repo.get_rule_by_name(db, body.name)
    if existing:
        raise HTTPException(status_code=409, detail=f"Rule '{body.name}' already exists")
    rule = await rule_repo.create_rule(db, body.model_dump())
    await processor.invalidate_rules()
    return _rule_out(rule)


@router.get("/{rule_id}")
async def get_rule(rule_id: uuid.UUID, db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    rule = await rule_repo.get_rule(db, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    return _rule_out(rule)


@router.put("/{rule_id}")
async def update_rule(
    rule_id: uuid.UUID,
    body: RuleUpdate,
    db: AsyncSession = Depends(get_db),
    processor=Depends(get_processor),
) -> Dict[str, Any]:
    rule = await rule_repo.get_rule(db, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    updates = body.model_dump(exclude_unset=True)
    rule = await rule_repo.update_rule(db, rule, updates)
    await processor.invalidate_rules()
    return _rule_out(rule)


@router.delete("/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    processor=Depends(get_processor),
):
    rule = await rule_repo.get_rule(db, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    await rule_repo.delete_rule(db, rule)
    await processor.invalidate_rules()
