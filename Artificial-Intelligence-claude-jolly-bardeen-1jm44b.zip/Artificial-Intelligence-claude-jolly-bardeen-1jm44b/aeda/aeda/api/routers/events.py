from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from ...db.orm import Event as EventORM
from ...models import AEDAEvent
from ...repositories import event_repo
from ..deps import get_db, get_processor, get_queue

router = APIRouter(prefix="/events", tags=["Events"])


@router.post("/ingest", status_code=202)
async def ingest_event(
    body: Dict[str, Any],
    db: AsyncSession = Depends(get_db),
    queue=Depends(get_queue),
):
    """Accept any event payload and queue it for rule evaluation."""
    event = AEDAEvent(
        source=body.get("source", "unknown"),
        event_type=body.get("event_type", "event"),
        severity=body.get("severity", "info"),
        title=body.get("title", "Untitled event"),
        payload=body.get("payload", {}),
        labels=body.get("labels", {}),
    )
    # Persist to DB
    await event_repo.save_event(db, {
        "id": uuid.UUID(event.id),
        "source": event.source,
        "event_type": event.event_type,
        "severity": event.severity,
        "title": event.title,
        "payload": event.payload,
        "labels": event.labels,
        "timestamp": event.timestamp,
    })
    # Push to Redis queue
    await queue.push(event.model_dump(mode="json"))
    return {"accepted": True, "event_id": event.id}


@router.get("/recent")
async def list_recent_events(
    limit: int = Query(default=50, le=500),
    source: Optional[str] = Query(default=None),
    severity: Optional[str] = Query(default=None),
    db: AsyncSession = Depends(get_db),
) -> List[Dict[str, Any]]:
    events = await event_repo.list_recent(db, limit=limit, source=source, severity=severity)
    return [
        {
            "id": str(e.id),
            "source": e.source,
            "event_type": e.event_type,
            "severity": e.severity,
            "title": e.title,
            "payload": e.payload,
            "labels": e.labels,
            "timestamp": e.timestamp.isoformat(),
            "processed": e.processed_at is not None,
        }
        for e in events
    ]
