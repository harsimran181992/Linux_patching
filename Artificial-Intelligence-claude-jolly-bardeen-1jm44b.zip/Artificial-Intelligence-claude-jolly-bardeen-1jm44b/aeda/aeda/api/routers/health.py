from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ..deps import get_db, get_queue

router = APIRouter(tags=["System"])


@router.get("/health")
async def health(
    request: Request,
    db: AsyncSession = Depends(get_db),
    queue=Depends(get_queue),
):
    # DB ping
    try:
        await db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False

    redis_ok = await queue.ping()
    queue_size = await queue.size() if redis_ok else -1

    return {
        "status": "ok" if (db_ok and redis_ok) else "degraded",
        "db": "ok" if db_ok else "error",
        "redis": "ok" if redis_ok else "error",
        "queue_size": queue_size,
    }
