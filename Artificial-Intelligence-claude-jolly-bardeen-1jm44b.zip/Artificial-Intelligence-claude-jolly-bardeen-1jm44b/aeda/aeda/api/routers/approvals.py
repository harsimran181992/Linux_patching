from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.ext.asyncio import AsyncSession

from ...repositories import approval_repo
from ..deps import get_db

router = APIRouter(prefix="/approvals", tags=["Approvals"])


def _serialize(a) -> Dict[str, Any]:
    return {
        "id": str(a.id),
        "event_id": a.event_id,
        "event_title": a.event_title,
        "rule_name": a.rule_name,
        "tool_name": a.tool_name,
        "tool_params": a.tool_params or {},
        "reason": a.reason,
        "status": a.status,
        "result": a.result,
        "created_at": a.created_at.isoformat(),
        "resolved_at": a.resolved_at.isoformat() if a.resolved_at else None,
    }


@router.get("")
async def list_approvals(
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
) -> List[Dict[str, Any]]:
    approvals = await approval_repo.list_approvals(db, status=status)
    return [_serialize(a) for a in approvals]


@router.get("/pending/count")
async def pending_count(db: AsyncSession = Depends(get_db)) -> Dict[str, int]:
    return {"count": await approval_repo.count_pending(db)}


@router.post("/{approval_id}/approve")
async def approve(approval_id: uuid.UUID, db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    a = await approval_repo.get(db, approval_id)
    if a is None:
        raise HTTPException(status_code=404, detail="Approval not found")
    if a.status != "pending":
        raise HTTPException(status_code=400, detail=f"Approval is already '{a.status}'")

    # Execute the stored tool call
    result_str = await _execute_approved(a)
    a = await approval_repo.resolve(db, approval_id, status="approved", result=result_str)
    return _serialize(a)


@router.post("/{approval_id}/deny")
async def deny(
    approval_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    a = await approval_repo.get(db, approval_id)
    if a is None:
        raise HTTPException(status_code=404, detail="Approval not found")
    if a.status != "pending":
        raise HTTPException(status_code=400, detail=f"Approval is already '{a.status}'")
    a = await approval_repo.resolve(db, approval_id, status="denied", result="Denied by operator")
    return _serialize(a)


async def _execute_approved(approval) -> str:
    """Run the tool that was approved, using stored params + credentials."""
    from ...agent.executor import execute_tool
    from ...models import AEDAEvent

    event = AEDAEvent(
        id=approval.event_id or str(uuid.uuid4()),
        source="approval",
        event_type="approved_action",
        severity="info",
        title=approval.event_title,
    )
    defaults = {approval.tool_name: approval.tool_defaults or {}}
    try:
        return await execute_tool(approval.tool_name, approval.tool_params or {}, event, defaults)
    except Exception as exc:
        return f"Execution failed: {exc}"
