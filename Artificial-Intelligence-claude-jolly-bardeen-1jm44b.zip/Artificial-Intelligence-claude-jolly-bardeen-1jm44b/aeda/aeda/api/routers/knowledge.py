from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Response, UploadFile
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from ...repositories import knowledge_repo
from ..deps import get_db

router = APIRouter(prefix="/knowledge", tags=["Knowledge Base"])

_MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB


class KnowledgeDocCreate(BaseModel):
    title: str
    content: str
    tags: List[str] = []
    action_hints: Dict[str, Any] = {}


class KnowledgeDocUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    tags: Optional[List[str]] = None
    action_hints: Optional[Dict[str, Any]] = None


def _serialize(doc) -> Dict[str, Any]:
    return {
        "id": str(doc.id),
        "title": doc.title,
        "content": doc.content,
        "tags": doc.tags or [],
        "action_hints": doc.action_hints or {},
        "has_embedding": doc.embedding is not None,
        "created_at": doc.created_at.isoformat(),
        "updated_at": doc.updated_at.isoformat(),
    }


@router.get("")
async def list_knowledge(db: AsyncSession = Depends(get_db)) -> List[Dict[str, Any]]:
    docs = await knowledge_repo.list_docs(db)
    return [_serialize(d) for d in docs]


@router.post("", status_code=201)
async def create_knowledge(body: KnowledgeDocCreate, db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    from ...embeddings import embed_text
    embedding = embed_text(f"{body.title}\n{body.content}")
    doc = await knowledge_repo.save_doc(db, {
        "id": uuid.uuid4(),
        "title": body.title,
        "content": body.content,
        "tags": body.tags,
        "action_hints": body.action_hints,
        "embedding": embedding,
    })
    return _serialize(doc)


@router.post("/import")
async def import_sop(file: UploadFile = File(...)) -> Dict[str, Any]:
    """
    Accept a PDF, DOCX, TXT or MD file, extract its text, and use Claude to
    convert it into a structured KB entry preview.  Nothing is saved to the
    database — the caller reviews and then POSTs to /knowledge to persist.
    """
    from ...importer.extractor import extract_text
    from ...importer.converter import convert_to_kb

    # ── Size guard ────────────────────────────────────────────────────────────
    data = await file.read()
    if len(data) > _MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Maximum allowed size is {_MAX_UPLOAD_BYTES // 1024 // 1024} MB.",
        )

    filename = file.filename or "upload"

    # ── Text extraction ───────────────────────────────────────────────────────
    try:
        raw_text, warning = extract_text(filename, data)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    if not raw_text.strip():
        raise HTTPException(
            status_code=422,
            detail="No text could be extracted from the file. It may be a scanned image.",
        )

    # ── Claude conversion ─────────────────────────────────────────────────────
    try:
        entry = await convert_to_kb(raw_text)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    return {
        "filename": filename,
        "extracted_chars": len(raw_text),
        "title": entry["title"],
        "content": entry["content"],
        "tags": entry["tags"],
        "action_hints": entry["action_hints"],
        "warning": warning,
    }


@router.get("/{doc_id}")
async def get_knowledge(doc_id: uuid.UUID, db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    doc = await knowledge_repo.get_doc(db, doc_id)
    if doc is None:
        raise HTTPException(status_code=404, detail="Document not found")
    return _serialize(doc)


@router.put("/{doc_id}")
async def update_knowledge(
    doc_id: uuid.UUID,
    body: KnowledgeDocUpdate,
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    updates = body.model_dump(exclude_unset=True)

    if "title" in updates or "content" in updates:
        from ...embeddings import embed_text
        doc = await knowledge_repo.get_doc(db, doc_id)
        if doc is None:
            raise HTTPException(status_code=404, detail="Document not found")
        new_title = updates.get("title", doc.title)
        new_content = updates.get("content", doc.content)
        updates["embedding"] = embed_text(f"{new_title}\n{new_content}")

    doc = await knowledge_repo.update_doc(db, doc_id, updates)
    if doc is None:
        raise HTTPException(status_code=404, detail="Document not found")
    return _serialize(doc)


@router.delete("/{doc_id}")
async def delete_knowledge(doc_id: uuid.UUID, db: AsyncSession = Depends(get_db)) -> Response:
    deleted = await knowledge_repo.delete_doc(db, doc_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Document not found")
    return Response(status_code=204)
