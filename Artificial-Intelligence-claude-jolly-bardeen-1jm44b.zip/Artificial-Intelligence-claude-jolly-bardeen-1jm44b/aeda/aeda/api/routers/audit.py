from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from ...repositories import audit_repo
from ..deps import get_db

router = APIRouter(prefix="/audit", tags=["Audit"])


@router.get("")
async def get_audit_log(
    limit: int = Query(default=50, le=500),
    rule_name: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default=None),
    db: AsyncSession = Depends(get_db),
) -> List[Dict[str, Any]]:
    entries = await audit_repo.list_audit(db, limit=limit, rule_name=rule_name, status=status)
    return [
        {
            "id": str(e.id),
            "timestamp": e.timestamp.isoformat(),
            "event_id": str(e.event_id) if e.event_id else None,
            "event_title": e.event_title,
            "rule_name": e.rule_name,
            "action_type": e.action_type,
            "status": e.status,
            "output": e.output,
            "error": e.error,
            "duration_ms": e.duration_ms,
            "reasoning": e.reasoning,
        }
        for e in entries
    ]


@router.get("/stats")
async def audit_stats(db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    counts = await audit_repo.count_by_status(db)
    return {
        "total": sum(counts.values()),
        "success": counts.get("success", 0),
        "failed": counts.get("failed", 0),
    }
